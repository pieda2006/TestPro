export const handlebarsTemplate = () => window.Handlebars
