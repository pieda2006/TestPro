export const swigTemplate = () => window.swig
