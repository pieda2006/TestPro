// import  { bootstrap2Iconlib } from  './bootstrap2.js'
import { bootstrap3Iconlib } from './bootstrap3.js'
import { fontawesome3Iconlib } from './fontawesome3.js'
import { fontawesome4Iconlib } from './fontawesome4.js'
import { fontawesome5Iconlib } from './fontawesome5.js'
// import  { foundation2Iconlib } from  './foundation2.js'
// import  { foundation3Iconlib } from  './foundation3.js'
import { jqueryuiIconlib } from './jqueryui.js'
// import  { materialiconsIconlib } from  './materialicons.js'
import { openiconicIconlib } from './openiconic.js'
import { spectreIconlib } from './spectre.js'

export const iconlibs = {
  // bootstrap2: bootstrap2Iconlib,
  bootstrap3: bootstrap3Iconlib,
  fontawesome3: fontawesome3Iconlib,
  fontawesome4: fontawesome4Iconlib,
  fontawesome5: fontawesome5Iconlib,
  // foundation2: foundation2Iconlib,
  // foundation3: foundation3Iconlib,
  jqueryui: jqueryuiIconlib,
  // materialicons: materialiconsIconlib,
  openiconic: openiconicIconlib,
  spectre: spectreIconlib
}
