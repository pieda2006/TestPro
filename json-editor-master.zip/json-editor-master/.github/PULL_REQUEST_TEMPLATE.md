| Q             | A
| ------------- | ---
| Is bugfix?    | ✔️❌
| New feature?  | ✔️❌
| Is backward-compatible?    | ✔️❌
| Tests pass?   | ✔️❌
| Fixed issues  | comma-separated list of tickets # fixed by the PR, if any
| Updated README/docs?   | ✔️❌
| Added CHANGELOG entry?   | ✔️❌
