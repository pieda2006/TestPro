package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyContextDataTraceReq
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyContextDataTraceReq   {
  @JsonProperty("traceRef")
  private String traceRef;

  /**
   * Gets or Sets traceDepth
   */
  public enum TraceDepthEnum {
    MINIMUM("MINIMUM"),
    
    MEDIUM("MEDIUM"),
    
    MAXIMUM("MAXIMUM"),
    
    MINIMUM_WO_VENDOR_EXTENSION("MINIMUM_WO_VENDOR_EXTENSION"),
    
    MEDIUM_WO_VENDOR_EXTENSION("MEDIUM_WO_VENDOR_EXTENSION"),
    
    MAXIMUM_WO_VENDOR_EXTENSION("MAXIMUM_WO_VENDOR_EXTENSION");

    private String value;

    TraceDepthEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static TraceDepthEnum fromValue(String value) {
      for (TraceDepthEnum b : TraceDepthEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("traceDepth")
  private TraceDepthEnum traceDepth;

  @JsonProperty("neTypeList")
  private String neTypeList;

  @JsonProperty("eventList")
  private String eventList;

  @JsonProperty("collectionEntityIpv4Addr")
  private String collectionEntityIpv4Addr;

  @JsonProperty("collectionEntityIpv6Addr")
  private String collectionEntityIpv6Addr;

  @JsonProperty("interfaceList")
  private String interfaceList;

  public SmPolicyContextDataTraceReq traceRef(String traceRef) {
    this.traceRef = traceRef;
    return this;
  }

  /**
   * Get traceRef
   * @return traceRef
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Pattern(regexp="^[0-9]{3}[0-9]{2,3}-[A-Fa-f0-9]{6}$") 
  public String getTraceRef() {
    return traceRef;
  }

  public void setTraceRef(String traceRef) {
    this.traceRef = traceRef;
  }

  public SmPolicyContextDataTraceReq traceDepth(TraceDepthEnum traceDepth) {
    this.traceDepth = traceDepth;
    return this;
  }

  /**
   * Get traceDepth
   * @return traceDepth
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public TraceDepthEnum getTraceDepth() {
    return traceDepth;
  }

  public void setTraceDepth(TraceDepthEnum traceDepth) {
    this.traceDepth = traceDepth;
  }

  public SmPolicyContextDataTraceReq neTypeList(String neTypeList) {
    this.neTypeList = neTypeList;
    return this;
  }

  /**
   * Get neTypeList
   * @return neTypeList
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Pattern(regexp="^[A-Fa-f0-9]+$") 
  public String getNeTypeList() {
    return neTypeList;
  }

  public void setNeTypeList(String neTypeList) {
    this.neTypeList = neTypeList;
  }

  public SmPolicyContextDataTraceReq eventList(String eventList) {
    this.eventList = eventList;
    return this;
  }

  /**
   * Get eventList
   * @return eventList
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Pattern(regexp="^[A-Fa-f0-9]+$") 
  public String getEventList() {
    return eventList;
  }

  public void setEventList(String eventList) {
    this.eventList = eventList;
  }

  public SmPolicyContextDataTraceReq collectionEntityIpv4Addr(String collectionEntityIpv4Addr) {
    this.collectionEntityIpv4Addr = collectionEntityIpv4Addr;
    return this;
  }

  /**
   * Get collectionEntityIpv4Addr
   * @return collectionEntityIpv4Addr
  */
  @ApiModelProperty(example = "198.51.100.1", value = "")

@Pattern(regexp="^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$") 
  public String getCollectionEntityIpv4Addr() {
    return collectionEntityIpv4Addr;
  }

  public void setCollectionEntityIpv4Addr(String collectionEntityIpv4Addr) {
    this.collectionEntityIpv4Addr = collectionEntityIpv4Addr;
  }

  public SmPolicyContextDataTraceReq collectionEntityIpv6Addr(String collectionEntityIpv6Addr) {
    this.collectionEntityIpv6Addr = collectionEntityIpv6Addr;
    return this;
  }

  /**
   * Get collectionEntityIpv6Addr
   * @return collectionEntityIpv6Addr
  */
  @ApiModelProperty(example = "2001:db8:85a3::8a2e:370:7334", value = "")


  public String getCollectionEntityIpv6Addr() {
    return collectionEntityIpv6Addr;
  }

  public void setCollectionEntityIpv6Addr(String collectionEntityIpv6Addr) {
    this.collectionEntityIpv6Addr = collectionEntityIpv6Addr;
  }

  public SmPolicyContextDataTraceReq interfaceList(String interfaceList) {
    this.interfaceList = interfaceList;
    return this;
  }

  /**
   * Get interfaceList
   * @return interfaceList
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^[A-Fa-f0-9]+$") 
  public String getInterfaceList() {
    return interfaceList;
  }

  public void setInterfaceList(String interfaceList) {
    this.interfaceList = interfaceList;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyContextDataTraceReq smPolicyContextDataTraceReq = (SmPolicyContextDataTraceReq) o;
    return Objects.equals(this.traceRef, smPolicyContextDataTraceReq.traceRef) &&
        Objects.equals(this.traceDepth, smPolicyContextDataTraceReq.traceDepth) &&
        Objects.equals(this.neTypeList, smPolicyContextDataTraceReq.neTypeList) &&
        Objects.equals(this.eventList, smPolicyContextDataTraceReq.eventList) &&
        Objects.equals(this.collectionEntityIpv4Addr, smPolicyContextDataTraceReq.collectionEntityIpv4Addr) &&
        Objects.equals(this.collectionEntityIpv6Addr, smPolicyContextDataTraceReq.collectionEntityIpv6Addr) &&
        Objects.equals(this.interfaceList, smPolicyContextDataTraceReq.interfaceList);
  }

  @Override
  public int hashCode() {
    return Objects.hash(traceRef, traceDepth, neTypeList, eventList, collectionEntityIpv4Addr, collectionEntityIpv6Addr, interfaceList);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyContextDataTraceReq {\n");
    
    sb.append("    traceRef: ").append(toIndentedString(traceRef)).append("\n");
    sb.append("    traceDepth: ").append(toIndentedString(traceDepth)).append("\n");
    sb.append("    neTypeList: ").append(toIndentedString(neTypeList)).append("\n");
    sb.append("    eventList: ").append(toIndentedString(eventList)).append("\n");
    sb.append("    collectionEntityIpv4Addr: ").append(toIndentedString(collectionEntityIpv4Addr)).append("\n");
    sb.append("    collectionEntityIpv6Addr: ").append(toIndentedString(collectionEntityIpv6Addr)).append("\n");
    sb.append("    interfaceList: ").append(toIndentedString(interfaceList)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

