package fivegc.pcf.smp.domain.service.api;


import java.util.HashMap;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.nio.charset.StandardCharsets;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.*;
import com.fasterxml.jackson.databind.JsonNode;

import org.springframework.stereotype.Repository;
import org.springframework.context.annotation.Scope;



@Scope("prototype")
@Repository
class ExecuteRedisAccess extends DataAcsessBase{

    private static final Logger log = LoggerFactory.getLogger(ExecuteRedisAccess.class);

    void executeAction(JsonNode reqJson, ObjectNode ansJson, ObjectNode distJson, JsonNode actionJson, JsonNode operationJson){

        RedisAPI datamanage = new RedisAPI();
        JsonNode opeJson;
        Object opetree;
        String opekey = null;
        String opedata = null;
        String opevalue = null;
        String opetable = null;

        opetable = getStringFromJson(tableName, tableKind, reqJson, actionJson, distJson, ansJson, operationJson);
        opevalue = getStringFromJson(value, valueKind, reqJson, actionJson, distJson, ansJson, operationJson);

        if(operationType != RGET && operationType != DELETE){
            opedata = getStringFromJson(dataJson, dataKind, reqJson, actionJson, distJson, ansJson, operationJson);
        }

        String result = null;
        String rediskey = opetable + ":" + opevalue;

        if(operationType == RGET){
            result = datamanage.Redis_Get(rediskey);

            ObjectMapper objectmapper = new ObjectMapper();

            try {
                JsonNode jsonresult = objectmapper.readTree(result);

                if(jsonresult instanceof ObjectNode){

                    setResultObject(jsonresult, dataKind, dataJson ,distJson, ansJson);
                }
            } catch (Exception e){
                //Error Actin
                log.error("readTree error Exception" , e );
            }
        }
        else if(operationType == SET){

            datamanage.Redis_Set(rediskey, opedata);
        }
        else if(operationType == DEL){
            datamanage.Redis_Del(rediskey);
        }
        else
        {
            //error
        }

    }

}

