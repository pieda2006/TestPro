package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.RanNasRelCauseNgApCause;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RanNasRelCause
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class RanNasRelCause   {
  @JsonProperty("ngApCause")
  private RanNasRelCauseNgApCause ngApCause = null;

  @JsonProperty("5gMmCause")
  private Integer _5gMmCause;

  @JsonProperty("5gSmCause")
  private Integer _5gSmCause;

  public RanNasRelCause ngApCause(RanNasRelCauseNgApCause ngApCause) {
    this.ngApCause = ngApCause;
    return this;
  }

  /**
   * Get ngApCause
   * @return ngApCause
  */
  @ApiModelProperty(value = "")

  @Valid

  public RanNasRelCauseNgApCause getNgApCause() {
    return ngApCause;
  }

  public void setNgApCause(RanNasRelCauseNgApCause ngApCause) {
    this.ngApCause = ngApCause;
  }

  public RanNasRelCause _5gMmCause(Integer _5gMmCause) {
    this._5gMmCause = _5gMmCause;
    return this;
  }

  /**
   * Get _5gMmCause
   * minimum: 0
   * @return _5gMmCause
  */
  @ApiModelProperty(value = "")

@Min(0)
  public Integer get5gMmCause() {
    return _5gMmCause;
  }

  public void set5gMmCause(Integer _5gMmCause) {
    this._5gMmCause = _5gMmCause;
  }

  public RanNasRelCause _5gSmCause(Integer _5gSmCause) {
    this._5gSmCause = _5gSmCause;
    return this;
  }

  /**
   * Get _5gSmCause
   * minimum: 0
   * @return _5gSmCause
  */
  @ApiModelProperty(value = "")

@Min(0)
  public Integer get5gSmCause() {
    return _5gSmCause;
  }

  public void set5gSmCause(Integer _5gSmCause) {
    this._5gSmCause = _5gSmCause;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RanNasRelCause ranNasRelCause = (RanNasRelCause) o;
    return Objects.equals(this.ngApCause, ranNasRelCause.ngApCause) &&
        Objects.equals(this._5gMmCause, ranNasRelCause._5gMmCause) &&
        Objects.equals(this._5gSmCause, ranNasRelCause._5gSmCause);
  }

  @Override
  public int hashCode() {
    return Objects.hash(ngApCause, _5gMmCause, _5gSmCause);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RanNasRelCause {\n");
    
    sb.append("    ngApCause: ").append(toIndentedString(ngApCause)).append("\n");
    sb.append("    _5gMmCause: ").append(toIndentedString(_5gMmCause)).append("\n");
    sb.append("    _5gSmCause: ").append(toIndentedString(_5gSmCause)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

