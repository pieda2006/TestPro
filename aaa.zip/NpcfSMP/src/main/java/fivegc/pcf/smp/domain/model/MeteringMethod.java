package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import io.swagger.annotations.ApiModel;
import com.fasterxml.jackson.annotation.JsonValue;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Possible values are - DURATION: Indicates that the duration of the service data flow traffic shall be metered. - VOLUME: Indicates that volume of the service data flow traffic shall be metered. - DURATION_VOLUME: Indicates that the duration and the volume of the service data flow traffic shall be metered. - EVENT: Indicates that events of the service data flow traffic shall be metered. 
 */
public enum MeteringMethod {
  
  DURATION("DURATION"),
  
  VOLUME("VOLUME"),
  
  DURATION_VOLUME("DURATION_VOLUME"),
  
  EVENT("EVENT");

  private String value;

  MeteringMethod(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static MeteringMethod fromValue(String value) {
    for (MeteringMethod b : MeteringMethod.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    return null;
  }
}

