package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoEutraLocationTai;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoNrLocationNcgi;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.OffsetDateTime;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyContextDataUserLocationInfoNrLocation
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyContextDataUserLocationInfoNrLocation   {
  @JsonProperty("tai")
  private SmPolicyContextDataUserLocationInfoEutraLocationTai tai = null;

  @JsonProperty("ncgi")
  private SmPolicyContextDataUserLocationInfoNrLocationNcgi ncgi = null;

  @JsonProperty("ageOfLocationInformation")
  private Integer ageOfLocationInformation;

  @JsonProperty("ueLocationTimestamp")
  private OffsetDateTime ueLocationTimestamp;

  @JsonProperty("geographicalInformation")
  private String geographicalInformation;

  @JsonProperty("geodeticInformation")
  private String geodeticInformation;

  @JsonProperty("globalGnbId")
  private SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId globalGnbId = null;

  public SmPolicyContextDataUserLocationInfoNrLocation tai(SmPolicyContextDataUserLocationInfoEutraLocationTai tai) {
    this.tai = tai;
    return this;
  }

  /**
   * Get tai
   * @return tai
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public SmPolicyContextDataUserLocationInfoEutraLocationTai getTai() {
    return tai;
  }

  public void setTai(SmPolicyContextDataUserLocationInfoEutraLocationTai tai) {
    this.tai = tai;
  }

  public SmPolicyContextDataUserLocationInfoNrLocation ncgi(SmPolicyContextDataUserLocationInfoNrLocationNcgi ncgi) {
    this.ncgi = ncgi;
    return this;
  }

  /**
   * Get ncgi
   * @return ncgi
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public SmPolicyContextDataUserLocationInfoNrLocationNcgi getNcgi() {
    return ncgi;
  }

  public void setNcgi(SmPolicyContextDataUserLocationInfoNrLocationNcgi ncgi) {
    this.ncgi = ncgi;
  }

  public SmPolicyContextDataUserLocationInfoNrLocation ageOfLocationInformation(Integer ageOfLocationInformation) {
    this.ageOfLocationInformation = ageOfLocationInformation;
    return this;
  }

  /**
   * Get ageOfLocationInformation
   * minimum: 0
   * maximum: 32767
   * @return ageOfLocationInformation
  */
  @ApiModelProperty(value = "")

@Min(0) @Max(32767) 
  public Integer getAgeOfLocationInformation() {
    return ageOfLocationInformation;
  }

  public void setAgeOfLocationInformation(Integer ageOfLocationInformation) {
    this.ageOfLocationInformation = ageOfLocationInformation;
  }

  public SmPolicyContextDataUserLocationInfoNrLocation ueLocationTimestamp(OffsetDateTime ueLocationTimestamp) {
    this.ueLocationTimestamp = ueLocationTimestamp;
    return this;
  }

  /**
   * Get ueLocationTimestamp
   * @return ueLocationTimestamp
  */
  @ApiModelProperty(value = "")

  @Valid

  public OffsetDateTime getUeLocationTimestamp() {
    return ueLocationTimestamp;
  }

  public void setUeLocationTimestamp(OffsetDateTime ueLocationTimestamp) {
    this.ueLocationTimestamp = ueLocationTimestamp;
  }

  public SmPolicyContextDataUserLocationInfoNrLocation geographicalInformation(String geographicalInformation) {
    this.geographicalInformation = geographicalInformation;
    return this;
  }

  /**
   * Get geographicalInformation
   * @return geographicalInformation
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^[0-9A-F]{16}$") 
  public String getGeographicalInformation() {
    return geographicalInformation;
  }

  public void setGeographicalInformation(String geographicalInformation) {
    this.geographicalInformation = geographicalInformation;
  }

  public SmPolicyContextDataUserLocationInfoNrLocation geodeticInformation(String geodeticInformation) {
    this.geodeticInformation = geodeticInformation;
    return this;
  }

  /**
   * Get geodeticInformation
   * @return geodeticInformation
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^[0-9A-F]{20}$") 
  public String getGeodeticInformation() {
    return geodeticInformation;
  }

  public void setGeodeticInformation(String geodeticInformation) {
    this.geodeticInformation = geodeticInformation;
  }

  public SmPolicyContextDataUserLocationInfoNrLocation globalGnbId(SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId globalGnbId) {
    this.globalGnbId = globalGnbId;
    return this;
  }

  /**
   * Get globalGnbId
   * @return globalGnbId
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId getGlobalGnbId() {
    return globalGnbId;
  }

  public void setGlobalGnbId(SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId globalGnbId) {
    this.globalGnbId = globalGnbId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyContextDataUserLocationInfoNrLocation smPolicyContextDataUserLocationInfoNrLocation = (SmPolicyContextDataUserLocationInfoNrLocation) o;
    return Objects.equals(this.tai, smPolicyContextDataUserLocationInfoNrLocation.tai) &&
        Objects.equals(this.ncgi, smPolicyContextDataUserLocationInfoNrLocation.ncgi) &&
        Objects.equals(this.ageOfLocationInformation, smPolicyContextDataUserLocationInfoNrLocation.ageOfLocationInformation) &&
        Objects.equals(this.ueLocationTimestamp, smPolicyContextDataUserLocationInfoNrLocation.ueLocationTimestamp) &&
        Objects.equals(this.geographicalInformation, smPolicyContextDataUserLocationInfoNrLocation.geographicalInformation) &&
        Objects.equals(this.geodeticInformation, smPolicyContextDataUserLocationInfoNrLocation.geodeticInformation) &&
        Objects.equals(this.globalGnbId, smPolicyContextDataUserLocationInfoNrLocation.globalGnbId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(tai, ncgi, ageOfLocationInformation, ueLocationTimestamp, geographicalInformation, geodeticInformation, globalGnbId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyContextDataUserLocationInfoNrLocation {\n");
    
    sb.append("    tai: ").append(toIndentedString(tai)).append("\n");
    sb.append("    ncgi: ").append(toIndentedString(ncgi)).append("\n");
    sb.append("    ageOfLocationInformation: ").append(toIndentedString(ageOfLocationInformation)).append("\n");
    sb.append("    ueLocationTimestamp: ").append(toIndentedString(ueLocationTimestamp)).append("\n");
    sb.append("    geographicalInformation: ").append(toIndentedString(geographicalInformation)).append("\n");
    sb.append("    geodeticInformation: ").append(toIndentedString(geodeticInformation)).append("\n");
    sb.append("    globalGnbId: ").append(toIndentedString(globalGnbId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

