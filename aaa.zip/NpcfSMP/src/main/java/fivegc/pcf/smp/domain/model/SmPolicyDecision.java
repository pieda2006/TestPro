package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.ChargingData;
import fivegc.pcf.smp.domain.model.ChargingInformation;
import fivegc.pcf.smp.domain.model.ConditionData;
import fivegc.pcf.smp.domain.model.PccRule;
import fivegc.pcf.smp.domain.model.PolicyControlRequestTrigger;
import fivegc.pcf.smp.domain.model.QosCharacteristics;
import fivegc.pcf.smp.domain.model.QosData;
import fivegc.pcf.smp.domain.model.QosFlowUsage;
import fivegc.pcf.smp.domain.model.RequestedRuleData;
import fivegc.pcf.smp.domain.model.RequestedUsageData;
import fivegc.pcf.smp.domain.model.SessionRule;
import fivegc.pcf.smp.domain.model.SmPolicyDecisionPraInfos;
import fivegc.pcf.smp.domain.model.TrafficControlData;
import fivegc.pcf.smp.domain.model.UsageMonitoringData;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyDecision
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyDecision   {
  @JsonProperty("sessRules")
  @Valid
  private Map<String, SessionRule> sessRules = null;

  @JsonProperty("pccRules")
  @Valid
  private JsonNullable<Map<String, PccRule>> pccRules = JsonNullable.undefined();

  @JsonProperty("pcscfRestIndication")
  private Boolean pcscfRestIndication;

  @JsonProperty("qosDecs")
  @Valid
  private Map<String, QosData> qosDecs = null;

  @JsonProperty("chgDecs")
  @Valid
  private JsonNullable<Map<String, ChargingData>> chgDecs = JsonNullable.undefined();

  @JsonProperty("chargingInfo")
  private ChargingInformation chargingInfo = null;

  @JsonProperty("traffContDecs")
  @Valid
  private Map<String, TrafficControlData> traffContDecs = null;

  @JsonProperty("umDecs")
  @Valid
  private JsonNullable<Map<String, UsageMonitoringData>> umDecs = JsonNullable.undefined();

  @JsonProperty("qosChars")
  @Valid
  private Map<String, QosCharacteristics> qosChars = null;

  @JsonProperty("reflectiveQoSTimer")
  private Integer reflectiveQoSTimer;

  @JsonProperty("conds")
  @Valid
  private JsonNullable<Map<String, ConditionData>> conds = JsonNullable.undefined();

  @JsonProperty("revalidationTime")
  private OffsetDateTime revalidationTime;

  @JsonProperty("offline")
  private Boolean offline;

  @JsonProperty("online")
  private Boolean online;

  @JsonProperty("policyCtrlReqTriggers")
  @Valid
  private JsonNullable<List<PolicyControlRequestTrigger>> policyCtrlReqTriggers = JsonNullable.undefined();

  @JsonProperty("lastReqRuleData")
  @Valid
  private List<RequestedRuleData> lastReqRuleData = null;

  @JsonProperty("lastReqUsageData")
  private RequestedUsageData lastReqUsageData = null;

  @JsonProperty("praInfos")
  @Valid
  private JsonNullable<Map<String, SmPolicyDecisionPraInfos>> praInfos = JsonNullable.undefined();

  @JsonProperty("ipv4Index")
  private Integer ipv4Index;

  @JsonProperty("ipv6Index")
  private Integer ipv6Index;

  @JsonProperty("qosFlowUsage")
  private QosFlowUsage qosFlowUsage;

  @JsonProperty("suppFeat")
  private String suppFeat;

  public SmPolicyDecision sessRules(Map<String, SessionRule> sessRules) {
    this.sessRules = sessRules;
    return this;
  }

  public SmPolicyDecision putSessRulesItem(String key, SessionRule sessRulesItem) {
    if (this.sessRules == null) {
      this.sessRules = new HashMap<>();
    }
    this.sessRules.put(key, sessRulesItem);
    return this;
  }

  /**
   * A map of Sessionrules with the content being the SessionRule as described in subclause 5.6.2.7.
   * @return sessRules
  */
  @ApiModelProperty(value = "A map of Sessionrules with the content being the SessionRule as described in subclause 5.6.2.7.")

  @Valid
@Size(min=1) 
  public Map<String, SessionRule> getSessRules() {
    return sessRules;
  }

  public void setSessRules(Map<String, SessionRule> sessRules) {
    this.sessRules = sessRules;
  }

  public SmPolicyDecision pccRules(Map<String, PccRule> pccRules) {
    this.pccRules = JsonNullable.of(pccRules);
    return this;
  }

  public SmPolicyDecision putPccRulesItem(String key, PccRule pccRulesItem) {
    if (this.pccRules == null) {
      this.pccRules = JsonNullable.of(new HashMap<>());
    }
    this.pccRules.get().put(key, pccRulesItem);
    return this;
  }

  /**
   * A map of PCC rules with the content being the PCCRule as described in subclause 5.6.2.6.
   * @return pccRules
  */
  @ApiModelProperty(value = "A map of PCC rules with the content being the PCCRule as described in subclause 5.6.2.6.")

  @Valid
@Size(min=1) 
  public JsonNullable<Map<String, PccRule>> getPccRules() {
    return pccRules;
  }

  public void setPccRules(JsonNullable<Map<String, PccRule>> pccRules) {
    this.pccRules = pccRules;
  }

  public SmPolicyDecision pcscfRestIndication(Boolean pcscfRestIndication) {
    this.pcscfRestIndication = pcscfRestIndication;
    return this;
  }

  /**
   * If it is included and set to true, it indicates the P-CSCF Restoration is requested.
   * @return pcscfRestIndication
  */
  @ApiModelProperty(value = "If it is included and set to true, it indicates the P-CSCF Restoration is requested.")


  public Boolean getPcscfRestIndication() {
    return pcscfRestIndication;
  }

  public void setPcscfRestIndication(Boolean pcscfRestIndication) {
    this.pcscfRestIndication = pcscfRestIndication;
  }

  public SmPolicyDecision qosDecs(Map<String, QosData> qosDecs) {
    this.qosDecs = qosDecs;
    return this;
  }

  public SmPolicyDecision putQosDecsItem(String key, QosData qosDecsItem) {
    if (this.qosDecs == null) {
      this.qosDecs = new HashMap<>();
    }
    this.qosDecs.put(key, qosDecsItem);
    return this;
  }

  /**
   * Map of QoS data policy decisions.
   * @return qosDecs
  */
  @ApiModelProperty(value = "Map of QoS data policy decisions.")

  @Valid
@Size(min=1) 
  public Map<String, QosData> getQosDecs() {
    return qosDecs;
  }

  public void setQosDecs(Map<String, QosData> qosDecs) {
    this.qosDecs = qosDecs;
  }

  public SmPolicyDecision chgDecs(Map<String, ChargingData> chgDecs) {
    this.chgDecs = JsonNullable.of(chgDecs);
    return this;
  }

  public SmPolicyDecision putChgDecsItem(String key, ChargingData chgDecsItem) {
    if (this.chgDecs == null) {
      this.chgDecs = JsonNullable.of(new HashMap<>());
    }
    this.chgDecs.get().put(key, chgDecsItem);
    return this;
  }

  /**
   * Map of Charging data policy decisions.
   * @return chgDecs
  */
  @ApiModelProperty(value = "Map of Charging data policy decisions.")

  @Valid
@Size(min=1) 
  public JsonNullable<Map<String, ChargingData>> getChgDecs() {
    return chgDecs;
  }

  public void setChgDecs(JsonNullable<Map<String, ChargingData>> chgDecs) {
    this.chgDecs = chgDecs;
  }

  public SmPolicyDecision chargingInfo(ChargingInformation chargingInfo) {
    this.chargingInfo = chargingInfo;
    return this;
  }

  /**
   * Get chargingInfo
   * @return chargingInfo
  */
  @ApiModelProperty(value = "")

  @Valid

  public ChargingInformation getChargingInfo() {
    return chargingInfo;
  }

  public void setChargingInfo(ChargingInformation chargingInfo) {
    this.chargingInfo = chargingInfo;
  }

  public SmPolicyDecision traffContDecs(Map<String, TrafficControlData> traffContDecs) {
    this.traffContDecs = traffContDecs;
    return this;
  }

  public SmPolicyDecision putTraffContDecsItem(String key, TrafficControlData traffContDecsItem) {
    if (this.traffContDecs == null) {
      this.traffContDecs = new HashMap<>();
    }
    this.traffContDecs.put(key, traffContDecsItem);
    return this;
  }

  /**
   * Map of Traffic Control data policy decisions.
   * @return traffContDecs
  */
  @ApiModelProperty(value = "Map of Traffic Control data policy decisions.")

  @Valid
@Size(min=1) 
  public Map<String, TrafficControlData> getTraffContDecs() {
    return traffContDecs;
  }

  public void setTraffContDecs(Map<String, TrafficControlData> traffContDecs) {
    this.traffContDecs = traffContDecs;
  }

  public SmPolicyDecision umDecs(Map<String, UsageMonitoringData> umDecs) {
    this.umDecs = JsonNullable.of(umDecs);
    return this;
  }

  public SmPolicyDecision putUmDecsItem(String key, UsageMonitoringData umDecsItem) {
    if (this.umDecs == null) {
      this.umDecs = JsonNullable.of(new HashMap<>());
    }
    this.umDecs.get().put(key, umDecsItem);
    return this;
  }

  /**
   * Map of Usage Monitoring data policy decisions.
   * @return umDecs
  */
  @ApiModelProperty(value = "Map of Usage Monitoring data policy decisions.")

  @Valid
@Size(min=1) 
  public JsonNullable<Map<String, UsageMonitoringData>> getUmDecs() {
    return umDecs;
  }

  public void setUmDecs(JsonNullable<Map<String, UsageMonitoringData>> umDecs) {
    this.umDecs = umDecs;
  }

  public SmPolicyDecision qosChars(Map<String, QosCharacteristics> qosChars) {
    this.qosChars = qosChars;
    return this;
  }

  public SmPolicyDecision putQosCharsItem(String key, QosCharacteristics qosCharsItem) {
    if (this.qosChars == null) {
      this.qosChars = new HashMap<>();
    }
    this.qosChars.put(key, qosCharsItem);
    return this;
  }

  /**
   * Map of QoS characteristics for non standard 5QIs. This map uses the 5QI values as keys.
   * @return qosChars
  */
  @ApiModelProperty(value = "Map of QoS characteristics for non standard 5QIs. This map uses the 5QI values as keys.")

  @Valid
@Size(min=1) 
  public Map<String, QosCharacteristics> getQosChars() {
    return qosChars;
  }

  public void setQosChars(Map<String, QosCharacteristics> qosChars) {
    this.qosChars = qosChars;
  }

  public SmPolicyDecision reflectiveQoSTimer(Integer reflectiveQoSTimer) {
    this.reflectiveQoSTimer = reflectiveQoSTimer;
    return this;
  }

  /**
   * Get reflectiveQoSTimer
   * @return reflectiveQoSTimer
  */
  @ApiModelProperty(value = "")


  public Integer getReflectiveQoSTimer() {
    return reflectiveQoSTimer;
  }

  public void setReflectiveQoSTimer(Integer reflectiveQoSTimer) {
    this.reflectiveQoSTimer = reflectiveQoSTimer;
  }

  public SmPolicyDecision conds(Map<String, ConditionData> conds) {
    this.conds = JsonNullable.of(conds);
    return this;
  }

  public SmPolicyDecision putCondsItem(String key, ConditionData condsItem) {
    if (this.conds == null) {
      this.conds = JsonNullable.of(new HashMap<>());
    }
    this.conds.get().put(key, condsItem);
    return this;
  }

  /**
   * A map of condition data with the content being as described in subclause 5.6.2.9.
   * @return conds
  */
  @ApiModelProperty(value = "A map of condition data with the content being as described in subclause 5.6.2.9.")

  @Valid
@Size(min=1) 
  public JsonNullable<Map<String, ConditionData>> getConds() {
    return conds;
  }

  public void setConds(JsonNullable<Map<String, ConditionData>> conds) {
    this.conds = conds;
  }

  public SmPolicyDecision revalidationTime(OffsetDateTime revalidationTime) {
    this.revalidationTime = revalidationTime;
    return this;
  }

  /**
   * Get revalidationTime
   * @return revalidationTime
  */
  @ApiModelProperty(value = "")

  @Valid

  public OffsetDateTime getRevalidationTime() {
    return revalidationTime;
  }

  public void setRevalidationTime(OffsetDateTime revalidationTime) {
    this.revalidationTime = revalidationTime;
  }

  public SmPolicyDecision offline(Boolean offline) {
    this.offline = offline;
    return this;
  }

  /**
   * Indicates the offline charging is applicable to the PDU session or PCC rule.
   * @return offline
  */
  @ApiModelProperty(value = "Indicates the offline charging is applicable to the PDU session or PCC rule.")


  public Boolean getOffline() {
    return offline;
  }

  public void setOffline(Boolean offline) {
    this.offline = offline;
  }

  public SmPolicyDecision online(Boolean online) {
    this.online = online;
    return this;
  }

  /**
   * Indicates the online charging is applicable to the PDU session or PCC rule.
   * @return online
  */
  @ApiModelProperty(value = "Indicates the online charging is applicable to the PDU session or PCC rule.")


  public Boolean getOnline() {
    return online;
  }

  public void setOnline(Boolean online) {
    this.online = online;
  }

  public SmPolicyDecision policyCtrlReqTriggers(List<PolicyControlRequestTrigger> policyCtrlReqTriggers) {
    this.policyCtrlReqTriggers = JsonNullable.of(policyCtrlReqTriggers);
    return this;
  }

  public SmPolicyDecision addPolicyCtrlReqTriggersItem(PolicyControlRequestTrigger policyCtrlReqTriggersItem) {
    if (this.policyCtrlReqTriggers == null || !this.policyCtrlReqTriggers.isPresent()) {
      this.policyCtrlReqTriggers = JsonNullable.of(new ArrayList<>());
    }
    this.policyCtrlReqTriggers.get().add(policyCtrlReqTriggersItem);
    return this;
  }

  /**
   * Defines the policy control request triggers subscribed by the PCF.
   * @return policyCtrlReqTriggers
  */
  @ApiModelProperty(value = "Defines the policy control request triggers subscribed by the PCF.")

  @Valid
@Size(min=1) 
  public JsonNullable<List<PolicyControlRequestTrigger>> getPolicyCtrlReqTriggers() {
    return policyCtrlReqTriggers;
  }

  public void setPolicyCtrlReqTriggers(JsonNullable<List<PolicyControlRequestTrigger>> policyCtrlReqTriggers) {
    this.policyCtrlReqTriggers = policyCtrlReqTriggers;
  }

  public SmPolicyDecision lastReqRuleData(List<RequestedRuleData> lastReqRuleData) {
    this.lastReqRuleData = lastReqRuleData;
    return this;
  }

  public SmPolicyDecision addLastReqRuleDataItem(RequestedRuleData lastReqRuleDataItem) {
    if (this.lastReqRuleData == null) {
      this.lastReqRuleData = new ArrayList<>();
    }
    this.lastReqRuleData.add(lastReqRuleDataItem);
    return this;
  }

  /**
   * Defines the last list of rule control data requested by the PCF.
   * @return lastReqRuleData
  */
  @ApiModelProperty(value = "Defines the last list of rule control data requested by the PCF.")

  @Valid
@Size(min=1) 
  public List<RequestedRuleData> getLastReqRuleData() {
    return lastReqRuleData;
  }

  public void setLastReqRuleData(List<RequestedRuleData> lastReqRuleData) {
    this.lastReqRuleData = lastReqRuleData;
  }

  public SmPolicyDecision lastReqUsageData(RequestedUsageData lastReqUsageData) {
    this.lastReqUsageData = lastReqUsageData;
    return this;
  }

  /**
   * Get lastReqUsageData
   * @return lastReqUsageData
  */
  @ApiModelProperty(value = "")

  @Valid

  public RequestedUsageData getLastReqUsageData() {
    return lastReqUsageData;
  }

  public void setLastReqUsageData(RequestedUsageData lastReqUsageData) {
    this.lastReqUsageData = lastReqUsageData;
  }

  public SmPolicyDecision praInfos(Map<String, SmPolicyDecisionPraInfos> praInfos) {
    this.praInfos = JsonNullable.of(praInfos);
    return this;
  }

  public SmPolicyDecision putPraInfosItem(String key, SmPolicyDecisionPraInfos praInfosItem) {
    if (this.praInfos == null) {
      this.praInfos = JsonNullable.of(new HashMap<>());
    }
    this.praInfos.get().put(key, praInfosItem);
    return this;
  }

  /**
   * Map of PRA information.
   * @return praInfos
  */
  @ApiModelProperty(value = "Map of PRA information.")

  @Valid
@Size(min=1) 
  public JsonNullable<Map<String, SmPolicyDecisionPraInfos>> getPraInfos() {
    return praInfos;
  }

  public void setPraInfos(JsonNullable<Map<String, SmPolicyDecisionPraInfos>> praInfos) {
    this.praInfos = praInfos;
  }

  public SmPolicyDecision ipv4Index(Integer ipv4Index) {
    this.ipv4Index = ipv4Index;
    return this;
  }

  /**
   * Get ipv4Index
   * @return ipv4Index
  */
  @ApiModelProperty(value = "")


  public Integer getIpv4Index() {
    return ipv4Index;
  }

  public void setIpv4Index(Integer ipv4Index) {
    this.ipv4Index = ipv4Index;
  }

  public SmPolicyDecision ipv6Index(Integer ipv6Index) {
    this.ipv6Index = ipv6Index;
    return this;
  }

  /**
   * Get ipv6Index
   * @return ipv6Index
  */
  @ApiModelProperty(value = "")


  public Integer getIpv6Index() {
    return ipv6Index;
  }

  public void setIpv6Index(Integer ipv6Index) {
    this.ipv6Index = ipv6Index;
  }

  public SmPolicyDecision qosFlowUsage(QosFlowUsage qosFlowUsage) {
    this.qosFlowUsage = qosFlowUsage;
    return this;
  }

  /**
   * Get qosFlowUsage
   * @return qosFlowUsage
  */
  @ApiModelProperty(value = "")

  @Valid

  public QosFlowUsage getQosFlowUsage() {
    return qosFlowUsage;
  }

  public void setQosFlowUsage(QosFlowUsage qosFlowUsage) {
    this.qosFlowUsage = qosFlowUsage;
  }

  public SmPolicyDecision suppFeat(String suppFeat) {
    this.suppFeat = suppFeat;
    return this;
  }

  /**
   * Get suppFeat
   * @return suppFeat
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^[A-Fa-f0-9]*$") 
  public String getSuppFeat() {
    return suppFeat;
  }

  public void setSuppFeat(String suppFeat) {
    this.suppFeat = suppFeat;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyDecision smPolicyDecision = (SmPolicyDecision) o;
    return Objects.equals(this.sessRules, smPolicyDecision.sessRules) &&
        Objects.equals(this.pccRules, smPolicyDecision.pccRules) &&
        Objects.equals(this.pcscfRestIndication, smPolicyDecision.pcscfRestIndication) &&
        Objects.equals(this.qosDecs, smPolicyDecision.qosDecs) &&
        Objects.equals(this.chgDecs, smPolicyDecision.chgDecs) &&
        Objects.equals(this.chargingInfo, smPolicyDecision.chargingInfo) &&
        Objects.equals(this.traffContDecs, smPolicyDecision.traffContDecs) &&
        Objects.equals(this.umDecs, smPolicyDecision.umDecs) &&
        Objects.equals(this.qosChars, smPolicyDecision.qosChars) &&
        Objects.equals(this.reflectiveQoSTimer, smPolicyDecision.reflectiveQoSTimer) &&
        Objects.equals(this.conds, smPolicyDecision.conds) &&
        Objects.equals(this.revalidationTime, smPolicyDecision.revalidationTime) &&
        Objects.equals(this.offline, smPolicyDecision.offline) &&
        Objects.equals(this.online, smPolicyDecision.online) &&
        Objects.equals(this.policyCtrlReqTriggers, smPolicyDecision.policyCtrlReqTriggers) &&
        Objects.equals(this.lastReqRuleData, smPolicyDecision.lastReqRuleData) &&
        Objects.equals(this.lastReqUsageData, smPolicyDecision.lastReqUsageData) &&
        Objects.equals(this.praInfos, smPolicyDecision.praInfos) &&
        Objects.equals(this.ipv4Index, smPolicyDecision.ipv4Index) &&
        Objects.equals(this.ipv6Index, smPolicyDecision.ipv6Index) &&
        Objects.equals(this.qosFlowUsage, smPolicyDecision.qosFlowUsage) &&
        Objects.equals(this.suppFeat, smPolicyDecision.suppFeat);
  }

  @Override
  public int hashCode() {
    return Objects.hash(sessRules, pccRules, pcscfRestIndication, qosDecs, chgDecs, chargingInfo, traffContDecs, umDecs, qosChars, reflectiveQoSTimer, conds, revalidationTime, offline, online, policyCtrlReqTriggers, lastReqRuleData, lastReqUsageData, praInfos, ipv4Index, ipv6Index, qosFlowUsage, suppFeat);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyDecision {\n");
    
    sb.append("    sessRules: ").append(toIndentedString(sessRules)).append("\n");
    sb.append("    pccRules: ").append(toIndentedString(pccRules)).append("\n");
    sb.append("    pcscfRestIndication: ").append(toIndentedString(pcscfRestIndication)).append("\n");
    sb.append("    qosDecs: ").append(toIndentedString(qosDecs)).append("\n");
    sb.append("    chgDecs: ").append(toIndentedString(chgDecs)).append("\n");
    sb.append("    chargingInfo: ").append(toIndentedString(chargingInfo)).append("\n");
    sb.append("    traffContDecs: ").append(toIndentedString(traffContDecs)).append("\n");
    sb.append("    umDecs: ").append(toIndentedString(umDecs)).append("\n");
    sb.append("    qosChars: ").append(toIndentedString(qosChars)).append("\n");
    sb.append("    reflectiveQoSTimer: ").append(toIndentedString(reflectiveQoSTimer)).append("\n");
    sb.append("    conds: ").append(toIndentedString(conds)).append("\n");
    sb.append("    revalidationTime: ").append(toIndentedString(revalidationTime)).append("\n");
    sb.append("    offline: ").append(toIndentedString(offline)).append("\n");
    sb.append("    online: ").append(toIndentedString(online)).append("\n");
    sb.append("    policyCtrlReqTriggers: ").append(toIndentedString(policyCtrlReqTriggers)).append("\n");
    sb.append("    lastReqRuleData: ").append(toIndentedString(lastReqRuleData)).append("\n");
    sb.append("    lastReqUsageData: ").append(toIndentedString(lastReqUsageData)).append("\n");
    sb.append("    praInfos: ").append(toIndentedString(praInfos)).append("\n");
    sb.append("    ipv4Index: ").append(toIndentedString(ipv4Index)).append("\n");
    sb.append("    ipv6Index: ").append(toIndentedString(ipv6Index)).append("\n");
    sb.append("    qosFlowUsage: ").append(toIndentedString(qosFlowUsage)).append("\n");
    sb.append("    suppFeat: ").append(toIndentedString(suppFeat)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

