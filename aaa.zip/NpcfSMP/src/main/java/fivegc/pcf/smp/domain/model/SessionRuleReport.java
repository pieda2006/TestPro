package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.RuleStatus;
import fivegc.pcf.smp.domain.model.SessionRuleFailureCode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SessionRuleReport
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SessionRuleReport   {
  @JsonProperty("ruleIds")
  @Valid
  private List<String> ruleIds = new ArrayList<>();

  @JsonProperty("ruleStatus")
  private RuleStatus ruleStatus;

  @JsonProperty("sessRuleFailureCode")
  private SessionRuleFailureCode sessRuleFailureCode;

  public SessionRuleReport ruleIds(List<String> ruleIds) {
    this.ruleIds = ruleIds;
    return this;
  }

  public SessionRuleReport addRuleIdsItem(String ruleIdsItem) {
    this.ruleIds.add(ruleIdsItem);
    return this;
  }

  /**
   * Contains the identifier of the affected session rule(s).
   * @return ruleIds
  */
  @ApiModelProperty(required = true, value = "Contains the identifier of the affected session rule(s).")
  @NotNull

@Size(min=1) 
  public List<String> getRuleIds() {
    return ruleIds;
  }

  public void setRuleIds(List<String> ruleIds) {
    this.ruleIds = ruleIds;
  }

  public SessionRuleReport ruleStatus(RuleStatus ruleStatus) {
    this.ruleStatus = ruleStatus;
    return this;
  }

  /**
   * Get ruleStatus
   * @return ruleStatus
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public RuleStatus getRuleStatus() {
    return ruleStatus;
  }

  public void setRuleStatus(RuleStatus ruleStatus) {
    this.ruleStatus = ruleStatus;
  }

  public SessionRuleReport sessRuleFailureCode(SessionRuleFailureCode sessRuleFailureCode) {
    this.sessRuleFailureCode = sessRuleFailureCode;
    return this;
  }

  /**
   * Get sessRuleFailureCode
   * @return sessRuleFailureCode
  */
  @ApiModelProperty(value = "")

  @Valid

  public SessionRuleFailureCode getSessRuleFailureCode() {
    return sessRuleFailureCode;
  }

  public void setSessRuleFailureCode(SessionRuleFailureCode sessRuleFailureCode) {
    this.sessRuleFailureCode = sessRuleFailureCode;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SessionRuleReport sessionRuleReport = (SessionRuleReport) o;
    return Objects.equals(this.ruleIds, sessionRuleReport.ruleIds) &&
        Objects.equals(this.ruleStatus, sessionRuleReport.ruleStatus) &&
        Objects.equals(this.sessRuleFailureCode, sessionRuleReport.sessRuleFailureCode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(ruleIds, ruleStatus, sessRuleFailureCode);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SessionRuleReport {\n");
    
    sb.append("    ruleIds: ").append(toIndentedString(ruleIds)).append("\n");
    sb.append("    ruleStatus: ").append(toIndentedString(ruleStatus)).append("\n");
    sb.append("    sessRuleFailureCode: ").append(toIndentedString(sessRuleFailureCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

