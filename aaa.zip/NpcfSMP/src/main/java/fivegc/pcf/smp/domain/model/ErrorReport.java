package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.InlineResponse400;
import fivegc.pcf.smp.domain.model.RuleReport;
import fivegc.pcf.smp.domain.model.SessionRuleReport;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ErrorReport
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class ErrorReport   {
  @JsonProperty("error")
  private InlineResponse400 error = null;

  @JsonProperty("ruleReports")
  @Valid
  private List<RuleReport> ruleReports = null;

  @JsonProperty("sessRuleReports")
  @Valid
  private List<SessionRuleReport> sessRuleReports = null;

  public ErrorReport error(InlineResponse400 error) {
    this.error = error;
    return this;
  }

  /**
   * Get error
   * @return error
  */
  @ApiModelProperty(value = "")

  @Valid

  public InlineResponse400 getError() {
    return error;
  }

  public void setError(InlineResponse400 error) {
    this.error = error;
  }

  public ErrorReport ruleReports(List<RuleReport> ruleReports) {
    this.ruleReports = ruleReports;
    return this;
  }

  public ErrorReport addRuleReportsItem(RuleReport ruleReportsItem) {
    if (this.ruleReports == null) {
      this.ruleReports = new ArrayList<>();
    }
    this.ruleReports.add(ruleReportsItem);
    return this;
  }

  /**
   * Used to report the PCC rule failure.
   * @return ruleReports
  */
  @ApiModelProperty(value = "Used to report the PCC rule failure.")

  @Valid
@Size(min=1) 
  public List<RuleReport> getRuleReports() {
    return ruleReports;
  }

  public void setRuleReports(List<RuleReport> ruleReports) {
    this.ruleReports = ruleReports;
  }

  public ErrorReport sessRuleReports(List<SessionRuleReport> sessRuleReports) {
    this.sessRuleReports = sessRuleReports;
    return this;
  }

  public ErrorReport addSessRuleReportsItem(SessionRuleReport sessRuleReportsItem) {
    if (this.sessRuleReports == null) {
      this.sessRuleReports = new ArrayList<>();
    }
    this.sessRuleReports.add(sessRuleReportsItem);
    return this;
  }

  /**
   * Used to report the session rule failure.
   * @return sessRuleReports
  */
  @ApiModelProperty(value = "Used to report the session rule failure.")

  @Valid
@Size(min=1) 
  public List<SessionRuleReport> getSessRuleReports() {
    return sessRuleReports;
  }

  public void setSessRuleReports(List<SessionRuleReport> sessRuleReports) {
    this.sessRuleReports = sessRuleReports;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ErrorReport errorReport = (ErrorReport) o;
    return Objects.equals(this.error, errorReport.error) &&
        Objects.equals(this.ruleReports, errorReport.ruleReports) &&
        Objects.equals(this.sessRuleReports, errorReport.sessRuleReports);
  }

  @Override
  public int hashCode() {
    return Objects.hash(error, ruleReports, sessRuleReports);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ErrorReport {\n");
    
    sb.append("    error: ").append(toIndentedString(error)).append("\n");
    sb.append("    ruleReports: ").append(toIndentedString(ruleReports)).append("\n");
    sb.append("    sessRuleReports: ").append(toIndentedString(sessRuleReports)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

