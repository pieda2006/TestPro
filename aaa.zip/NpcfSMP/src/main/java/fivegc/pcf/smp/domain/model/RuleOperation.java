package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import io.swagger.annotations.ApiModel;
import com.fasterxml.jackson.annotation.JsonValue;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Possible values are - CREATE_PCC_RULE: Indicates to create a new PCC rule to reserve the resource requested by the UE.  - DELETE_PCC_RULE: Indicates to delete a PCC rule corresponding to reserve the resource requested by the UE.. - MODIFY_PCC_RULE_AND_ADD_PACKET_FILTERS: Indicates to modify the PCC rule by adding new packet filter(s). - MODIFY_ PCC_RULE_AND_REPLACE_PACKET_FILTERS: Indicates to modify the PCC rule by replacing the existing packet filter(s). - MODIFY_ PCC_RULE_AND_DELETE_PACKET_FILTERS: Indicates to modify the PCC rule by deleting the existing packet filter(s). - MODIFY_PCC_RULE_WITHOUT_MODIFY_PACKET_FILTERS: Indicates to modify the PCC rule by modifying the QoS of the PCC rule. 
 */
public enum RuleOperation {
  
  CREATE_PCC_RULE("CREATE_PCC_RULE"),
  
  DELETE_PCC_RULE("DELETE_PCC_RULE"),
  
  MODIFY_PCC_RULE_AND_ADD_PACKET_FILTERS("MODIFY_PCC_RULE_AND_ADD_PACKET_FILTERS"),
  
  MODIFY__PCC_RULE_AND_REPLACE_PACKET_FILTERS("MODIFY_ PCC_RULE_AND_REPLACE_PACKET_FILTERS"),
  
  MODIFY__PCC_RULE_AND_DELETE_PACKET_FILTERS("MODIFY_ PCC_RULE_AND_DELETE_PACKET_FILTERS"),
  
  MODIFY_PCC_RULE_WITHOUT_MODIFY_PACKET_FILTERS("MODIFY_PCC_RULE_WITHOUT_MODIFY_PACKET_FILTERS");

  private String value;

  RuleOperation(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static RuleOperation fromValue(String value) {
    for (RuleOperation b : RuleOperation.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + value + "'");
  }
}

