package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ChargingInformation
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class ChargingInformation   {
  @JsonProperty("primaryChfAddress")
  private String primaryChfAddress;

  @JsonProperty("secondaryChfAddress")
  private String secondaryChfAddress;

  public ChargingInformation primaryChfAddress(String primaryChfAddress) {
    this.primaryChfAddress = primaryChfAddress;
    return this;
  }

  /**
   * Get primaryChfAddress
   * @return primaryChfAddress
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getPrimaryChfAddress() {
    return primaryChfAddress;
  }

  public void setPrimaryChfAddress(String primaryChfAddress) {
    this.primaryChfAddress = primaryChfAddress;
  }

  public ChargingInformation secondaryChfAddress(String secondaryChfAddress) {
    this.secondaryChfAddress = secondaryChfAddress;
    return this;
  }

  /**
   * Get secondaryChfAddress
   * @return secondaryChfAddress
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getSecondaryChfAddress() {
    return secondaryChfAddress;
  }

  public void setSecondaryChfAddress(String secondaryChfAddress) {
    this.secondaryChfAddress = secondaryChfAddress;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ChargingInformation chargingInformation = (ChargingInformation) o;
    return Objects.equals(this.primaryChfAddress, chargingInformation.primaryChfAddress) &&
        Objects.equals(this.secondaryChfAddress, chargingInformation.secondaryChfAddress);
  }

  @Override
  public int hashCode() {
    return Objects.hash(primaryChfAddress, secondaryChfAddress);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ChargingInformation {\n");
    
    sb.append("    primaryChfAddress: ").append(toIndentedString(primaryChfAddress)).append("\n");
    sb.append("    secondaryChfAddress: ").append(toIndentedString(secondaryChfAddress)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

