package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.AuthorizedDefaultQos;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataSubsSessAmbr;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SessionRule
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SessionRule   {
  @JsonProperty("authSessAmbr")
  private SmPolicyContextDataSubsSessAmbr authSessAmbr = null;

  @JsonProperty("authDefQos")
  private AuthorizedDefaultQos authDefQos = null;

  @JsonProperty("sessRuleId")
  private String sessRuleId;

  @JsonProperty("refUmData")
  private JsonNullable<String> refUmData = JsonNullable.undefined();

  @JsonProperty("refUmN3gData")
  private JsonNullable<String> refUmN3gData = JsonNullable.undefined();

  @JsonProperty("refCondData")
  private JsonNullable<String> refCondData = JsonNullable.undefined();

  public SessionRule authSessAmbr(SmPolicyContextDataSubsSessAmbr authSessAmbr) {
    this.authSessAmbr = authSessAmbr;
    return this;
  }

  /**
   * Get authSessAmbr
   * @return authSessAmbr
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataSubsSessAmbr getAuthSessAmbr() {
    return authSessAmbr;
  }

  public void setAuthSessAmbr(SmPolicyContextDataSubsSessAmbr authSessAmbr) {
    this.authSessAmbr = authSessAmbr;
  }

  public SessionRule authDefQos(AuthorizedDefaultQos authDefQos) {
    this.authDefQos = authDefQos;
    return this;
  }

  /**
   * Get authDefQos
   * @return authDefQos
  */
  @ApiModelProperty(value = "")

  @Valid

  public AuthorizedDefaultQos getAuthDefQos() {
    return authDefQos;
  }

  public void setAuthDefQos(AuthorizedDefaultQos authDefQos) {
    this.authDefQos = authDefQos;
  }

  public SessionRule sessRuleId(String sessRuleId) {
    this.sessRuleId = sessRuleId;
    return this;
  }

  /**
   * Univocally identifies the session rule within a PDU session.
   * @return sessRuleId
  */
  @ApiModelProperty(required = true, value = "Univocally identifies the session rule within a PDU session.")
  @NotNull


  public String getSessRuleId() {
    return sessRuleId;
  }

  public void setSessRuleId(String sessRuleId) {
    this.sessRuleId = sessRuleId;
  }

  public SessionRule refUmData(String refUmData) {
    this.refUmData = JsonNullable.of(refUmData);
    return this;
  }

  /**
   * A reference to UsageMonitoringData policy decision type. It is the umId described in subclause 5.6.2.12.
   * @return refUmData
  */
  @ApiModelProperty(value = "A reference to UsageMonitoringData policy decision type. It is the umId described in subclause 5.6.2.12.")


  public JsonNullable<String> getRefUmData() {
    return refUmData;
  }

  public void setRefUmData(JsonNullable<String> refUmData) {
    this.refUmData = refUmData;
  }

  public SessionRule refUmN3gData(String refUmN3gData) {
    this.refUmN3gData = JsonNullable.of(refUmN3gData);
    return this;
  }

  /**
   * A reference to UsageMonitoringData policy decision type to apply for Non-3GPP access. It is the umId described in subclause 5.6.2.12.
   * @return refUmN3gData
  */
  @ApiModelProperty(value = "A reference to UsageMonitoringData policy decision type to apply for Non-3GPP access. It is the umId described in subclause 5.6.2.12.")


  public JsonNullable<String> getRefUmN3gData() {
    return refUmN3gData;
  }

  public void setRefUmN3gData(JsonNullable<String> refUmN3gData) {
    this.refUmN3gData = refUmN3gData;
  }

  public SessionRule refCondData(String refCondData) {
    this.refCondData = JsonNullable.of(refCondData);
    return this;
  }

  /**
   * A reference to the condition data. It is the condId described in subclause 5.6.2.9.
   * @return refCondData
  */
  @ApiModelProperty(value = "A reference to the condition data. It is the condId described in subclause 5.6.2.9.")


  public JsonNullable<String> getRefCondData() {
    return refCondData;
  }

  public void setRefCondData(JsonNullable<String> refCondData) {
    this.refCondData = refCondData;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SessionRule sessionRule = (SessionRule) o;
    return Objects.equals(this.authSessAmbr, sessionRule.authSessAmbr) &&
        Objects.equals(this.authDefQos, sessionRule.authDefQos) &&
        Objects.equals(this.sessRuleId, sessionRule.sessRuleId) &&
        Objects.equals(this.refUmData, sessionRule.refUmData) &&
        Objects.equals(this.refUmN3gData, sessionRule.refUmN3gData) &&
        Objects.equals(this.refCondData, sessionRule.refCondData);
  }

  @Override
  public int hashCode() {
    return Objects.hash(authSessAmbr, authDefQos, sessRuleId, refUmData, refUmN3gData, refCondData);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SessionRule {\n");
    
    sb.append("    authSessAmbr: ").append(toIndentedString(authSessAmbr)).append("\n");
    sb.append("    authDefQos: ").append(toIndentedString(authDefQos)).append("\n");
    sb.append("    sessRuleId: ").append(toIndentedString(sessRuleId)).append("\n");
    sb.append("    refUmData: ").append(toIndentedString(refUmData)).append("\n");
    sb.append("    refUmN3gData: ").append(toIndentedString(refUmN3gData)).append("\n");
    sb.append("    refCondData: ").append(toIndentedString(refCondData)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

