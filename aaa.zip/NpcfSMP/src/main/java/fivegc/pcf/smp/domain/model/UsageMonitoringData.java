package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * UsageMonitoringData
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class UsageMonitoringData   {
  @JsonProperty("umId")
  private String umId;

  @JsonProperty("volumeThreshold")
  private JsonNullable<Long> volumeThreshold = JsonNullable.undefined();

  @JsonProperty("volumeThresholdUplink")
  private JsonNullable<Long> volumeThresholdUplink = JsonNullable.undefined();

  @JsonProperty("volumeThresholdDownlink")
  private JsonNullable<Long> volumeThresholdDownlink = JsonNullable.undefined();

  @JsonProperty("timeThreshold")
  private JsonNullable<Integer> timeThreshold = JsonNullable.undefined();

  @JsonProperty("monitoringTime")
  private JsonNullable<OffsetDateTime> monitoringTime = JsonNullable.undefined();

  @JsonProperty("nextVolThreshold")
  private JsonNullable<Long> nextVolThreshold = JsonNullable.undefined();

  @JsonProperty("nextVolThresholdUplink")
  private JsonNullable<Long> nextVolThresholdUplink = JsonNullable.undefined();

  @JsonProperty("nextVolThresholdDownlink")
  private JsonNullable<Long> nextVolThresholdDownlink = JsonNullable.undefined();

  @JsonProperty("nextTimeThreshold")
  private JsonNullable<Integer> nextTimeThreshold = JsonNullable.undefined();

  @JsonProperty("inactivityTime")
  private JsonNullable<Integer> inactivityTime = JsonNullable.undefined();

  @JsonProperty("exUsagePccRuleIds")
  @Valid
  private JsonNullable<List<String>> exUsagePccRuleIds = JsonNullable.undefined();

  public UsageMonitoringData umId(String umId) {
    this.umId = umId;
    return this;
  }

  /**
   * Univocally identifies the usage monitoring policy data within a PDU session.
   * @return umId
  */
  @ApiModelProperty(required = true, value = "Univocally identifies the usage monitoring policy data within a PDU session.")
  @NotNull


  public String getUmId() {
    return umId;
  }

  public void setUmId(String umId) {
    this.umId = umId;
  }

  public UsageMonitoringData volumeThreshold(Long volumeThreshold) {
    this.volumeThreshold = JsonNullable.of(volumeThreshold);
    return this;
  }

  /**
   * Unsigned integer identifying a volume in units of bytes with \"nullable=true\" property.
   * minimum: 0
   * @return volumeThreshold
  */
  @ApiModelProperty(value = "Unsigned integer identifying a volume in units of bytes with \"nullable=true\" property.")

@Min(0L)
  public JsonNullable<Long> getVolumeThreshold() {
    return volumeThreshold;
  }

  public void setVolumeThreshold(JsonNullable<Long> volumeThreshold) {
    this.volumeThreshold = volumeThreshold;
  }

  public UsageMonitoringData volumeThresholdUplink(Long volumeThresholdUplink) {
    this.volumeThresholdUplink = JsonNullable.of(volumeThresholdUplink);
    return this;
  }

  /**
   * Unsigned integer identifying a volume in units of bytes with \"nullable=true\" property.
   * minimum: 0
   * @return volumeThresholdUplink
  */
  @ApiModelProperty(value = "Unsigned integer identifying a volume in units of bytes with \"nullable=true\" property.")

@Min(0L)
  public JsonNullable<Long> getVolumeThresholdUplink() {
    return volumeThresholdUplink;
  }

  public void setVolumeThresholdUplink(JsonNullable<Long> volumeThresholdUplink) {
    this.volumeThresholdUplink = volumeThresholdUplink;
  }

  public UsageMonitoringData volumeThresholdDownlink(Long volumeThresholdDownlink) {
    this.volumeThresholdDownlink = JsonNullable.of(volumeThresholdDownlink);
    return this;
  }

  /**
   * Unsigned integer identifying a volume in units of bytes with \"nullable=true\" property.
   * minimum: 0
   * @return volumeThresholdDownlink
  */
  @ApiModelProperty(value = "Unsigned integer identifying a volume in units of bytes with \"nullable=true\" property.")

@Min(0L)
  public JsonNullable<Long> getVolumeThresholdDownlink() {
    return volumeThresholdDownlink;
  }

  public void setVolumeThresholdDownlink(JsonNullable<Long> volumeThresholdDownlink) {
    this.volumeThresholdDownlink = volumeThresholdDownlink;
  }

  public UsageMonitoringData timeThreshold(Integer timeThreshold) {
    this.timeThreshold = JsonNullable.of(timeThreshold);
    return this;
  }

  /**
   * Get timeThreshold
   * @return timeThreshold
  */
  @ApiModelProperty(value = "")


  public JsonNullable<Integer> getTimeThreshold() {
    return timeThreshold;
  }

  public void setTimeThreshold(JsonNullable<Integer> timeThreshold) {
    this.timeThreshold = timeThreshold;
  }

  public UsageMonitoringData monitoringTime(OffsetDateTime monitoringTime) {
    this.monitoringTime = JsonNullable.of(monitoringTime);
    return this;
  }

  /**
   * Get monitoringTime
   * @return monitoringTime
  */
  @ApiModelProperty(value = "")

  @Valid

  public JsonNullable<OffsetDateTime> getMonitoringTime() {
    return monitoringTime;
  }

  public void setMonitoringTime(JsonNullable<OffsetDateTime> monitoringTime) {
    this.monitoringTime = monitoringTime;
  }

  public UsageMonitoringData nextVolThreshold(Long nextVolThreshold) {
    this.nextVolThreshold = JsonNullable.of(nextVolThreshold);
    return this;
  }

  /**
   * Unsigned integer identifying a volume in units of bytes with \"nullable=true\" property.
   * minimum: 0
   * @return nextVolThreshold
  */
  @ApiModelProperty(value = "Unsigned integer identifying a volume in units of bytes with \"nullable=true\" property.")

@Min(0L)
  public JsonNullable<Long> getNextVolThreshold() {
    return nextVolThreshold;
  }

  public void setNextVolThreshold(JsonNullable<Long> nextVolThreshold) {
    this.nextVolThreshold = nextVolThreshold;
  }

  public UsageMonitoringData nextVolThresholdUplink(Long nextVolThresholdUplink) {
    this.nextVolThresholdUplink = JsonNullable.of(nextVolThresholdUplink);
    return this;
  }

  /**
   * Unsigned integer identifying a volume in units of bytes with \"nullable=true\" property.
   * minimum: 0
   * @return nextVolThresholdUplink
  */
  @ApiModelProperty(value = "Unsigned integer identifying a volume in units of bytes with \"nullable=true\" property.")

@Min(0L)
  public JsonNullable<Long> getNextVolThresholdUplink() {
    return nextVolThresholdUplink;
  }

  public void setNextVolThresholdUplink(JsonNullable<Long> nextVolThresholdUplink) {
    this.nextVolThresholdUplink = nextVolThresholdUplink;
  }

  public UsageMonitoringData nextVolThresholdDownlink(Long nextVolThresholdDownlink) {
    this.nextVolThresholdDownlink = JsonNullable.of(nextVolThresholdDownlink);
    return this;
  }

  /**
   * Unsigned integer identifying a volume in units of bytes with \"nullable=true\" property.
   * minimum: 0
   * @return nextVolThresholdDownlink
  */
  @ApiModelProperty(value = "Unsigned integer identifying a volume in units of bytes with \"nullable=true\" property.")

@Min(0L)
  public JsonNullable<Long> getNextVolThresholdDownlink() {
    return nextVolThresholdDownlink;
  }

  public void setNextVolThresholdDownlink(JsonNullable<Long> nextVolThresholdDownlink) {
    this.nextVolThresholdDownlink = nextVolThresholdDownlink;
  }

  public UsageMonitoringData nextTimeThreshold(Integer nextTimeThreshold) {
    this.nextTimeThreshold = JsonNullable.of(nextTimeThreshold);
    return this;
  }

  /**
   * Get nextTimeThreshold
   * @return nextTimeThreshold
  */
  @ApiModelProperty(value = "")


  public JsonNullable<Integer> getNextTimeThreshold() {
    return nextTimeThreshold;
  }

  public void setNextTimeThreshold(JsonNullable<Integer> nextTimeThreshold) {
    this.nextTimeThreshold = nextTimeThreshold;
  }

  public UsageMonitoringData inactivityTime(Integer inactivityTime) {
    this.inactivityTime = JsonNullable.of(inactivityTime);
    return this;
  }

  /**
   * Get inactivityTime
   * @return inactivityTime
  */
  @ApiModelProperty(value = "")


  public JsonNullable<Integer> getInactivityTime() {
    return inactivityTime;
  }

  public void setInactivityTime(JsonNullable<Integer> inactivityTime) {
    this.inactivityTime = inactivityTime;
  }

  public UsageMonitoringData exUsagePccRuleIds(List<String> exUsagePccRuleIds) {
    this.exUsagePccRuleIds = JsonNullable.of(exUsagePccRuleIds);
    return this;
  }

  public UsageMonitoringData addExUsagePccRuleIdsItem(String exUsagePccRuleIdsItem) {
    if (this.exUsagePccRuleIds == null || !this.exUsagePccRuleIds.isPresent()) {
      this.exUsagePccRuleIds = JsonNullable.of(new ArrayList<>());
    }
    this.exUsagePccRuleIds.get().add(exUsagePccRuleIdsItem);
    return this;
  }

  /**
   * Contains the PCC rule identifier(s) which corresponding service data flow(s) shall be excluded from PDU Session usage monitoring. It is only included in the UsageMonitoringData instance for session level usage monitoring.
   * @return exUsagePccRuleIds
  */
  @ApiModelProperty(value = "Contains the PCC rule identifier(s) which corresponding service data flow(s) shall be excluded from PDU Session usage monitoring. It is only included in the UsageMonitoringData instance for session level usage monitoring.")

@Size(min=1) 
  public JsonNullable<List<String>> getExUsagePccRuleIds() {
    return exUsagePccRuleIds;
  }

  public void setExUsagePccRuleIds(JsonNullable<List<String>> exUsagePccRuleIds) {
    this.exUsagePccRuleIds = exUsagePccRuleIds;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UsageMonitoringData usageMonitoringData = (UsageMonitoringData) o;
    return Objects.equals(this.umId, usageMonitoringData.umId) &&
        Objects.equals(this.volumeThreshold, usageMonitoringData.volumeThreshold) &&
        Objects.equals(this.volumeThresholdUplink, usageMonitoringData.volumeThresholdUplink) &&
        Objects.equals(this.volumeThresholdDownlink, usageMonitoringData.volumeThresholdDownlink) &&
        Objects.equals(this.timeThreshold, usageMonitoringData.timeThreshold) &&
        Objects.equals(this.monitoringTime, usageMonitoringData.monitoringTime) &&
        Objects.equals(this.nextVolThreshold, usageMonitoringData.nextVolThreshold) &&
        Objects.equals(this.nextVolThresholdUplink, usageMonitoringData.nextVolThresholdUplink) &&
        Objects.equals(this.nextVolThresholdDownlink, usageMonitoringData.nextVolThresholdDownlink) &&
        Objects.equals(this.nextTimeThreshold, usageMonitoringData.nextTimeThreshold) &&
        Objects.equals(this.inactivityTime, usageMonitoringData.inactivityTime) &&
        Objects.equals(this.exUsagePccRuleIds, usageMonitoringData.exUsagePccRuleIds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(umId, volumeThreshold, volumeThresholdUplink, volumeThresholdDownlink, timeThreshold, monitoringTime, nextVolThreshold, nextVolThresholdUplink, nextVolThresholdDownlink, nextTimeThreshold, inactivityTime, exUsagePccRuleIds);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UsageMonitoringData {\n");
    
    sb.append("    umId: ").append(toIndentedString(umId)).append("\n");
    sb.append("    volumeThreshold: ").append(toIndentedString(volumeThreshold)).append("\n");
    sb.append("    volumeThresholdUplink: ").append(toIndentedString(volumeThresholdUplink)).append("\n");
    sb.append("    volumeThresholdDownlink: ").append(toIndentedString(volumeThresholdDownlink)).append("\n");
    sb.append("    timeThreshold: ").append(toIndentedString(timeThreshold)).append("\n");
    sb.append("    monitoringTime: ").append(toIndentedString(monitoringTime)).append("\n");
    sb.append("    nextVolThreshold: ").append(toIndentedString(nextVolThreshold)).append("\n");
    sb.append("    nextVolThresholdUplink: ").append(toIndentedString(nextVolThresholdUplink)).append("\n");
    sb.append("    nextVolThresholdDownlink: ").append(toIndentedString(nextVolThresholdDownlink)).append("\n");
    sb.append("    nextTimeThreshold: ").append(toIndentedString(nextTimeThreshold)).append("\n");
    sb.append("    inactivityTime: ").append(toIndentedString(inactivityTime)).append("\n");
    sb.append("    exUsagePccRuleIds: ").append(toIndentedString(exUsagePccRuleIds)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

