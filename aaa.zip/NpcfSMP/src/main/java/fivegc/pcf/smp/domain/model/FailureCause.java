package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets FailureCause
 */
public enum FailureCause {
  
  PCC_RULE_EVENT("PCC_RULE_EVENT"),
  
  PCC_QOS_FLOW_EVENT("PCC_QOS_FLOW_EVENT"),
  
  RULE_PERMANENT_ERROR("RULE_PERMANENT_ERROR"),
  
  RULE_TEMPORARY_ERROR("RULE_TEMPORARY_ERROR");

  private String value;

  FailureCause(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static FailureCause fromValue(String value) {
    for (FailureCause b : FailureCause.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + value + "'");
  }
}

