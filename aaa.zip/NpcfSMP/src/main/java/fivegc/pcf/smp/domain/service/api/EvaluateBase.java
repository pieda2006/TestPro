package fivegc.pcf.smp.domain.service.api;
 
import java.util.*;
import com.fasterxml.jackson.databind.JsonNode;

class EvaluateBase {

    protected int operationType;
    protected ArrayList<EvaluateBase> evaluateObj = null;
    protected JsonNode opeJson = null;

    public EvaluateBase(){
        evaluateObj = new ArrayList<EvaluateBase>();
    }
    public void setOperationType(int opeType){
        operationType =opeType;
    }
    public ResultInfo evaluateCondition(JsonNode reqJson, JsonNode inputJson, JsonNode operationJson){
        ResultInfo resultinfo = new ResultInfo();
        resultinfo.setBoolResult(true);
        resultinfo.setResultType(ResultInfo.BOOLTYPE);
        return resultinfo;
    }
   
    /**
     * Operation動作用の設定の保持。
     * @author	ikeda_tss
     * @version sprint02
     * @since sprint02
     * @param JsonNode operationjson オペレーション実行時に必要なJsonデータ
     * @return 無
     */
     
    public void setParameterFromJson(JsonNode operationjson){
        opeJson = operationjson;
    }
    
    public void setEvaluateObj(EvaluateBase evaluate){
        evaluateObj.add(evaluate);
    }
}
