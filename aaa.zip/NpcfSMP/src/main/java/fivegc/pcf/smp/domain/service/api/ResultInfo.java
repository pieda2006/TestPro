package fivegc.pcf.smp.domain.service.api;

import com.fasterxml.jackson.databind.JsonNode;

class ResultInfo {

    private String stringResult;
    private int intResult;
    private boolean boolResult;
    private int resultType;
    private JsonNode jsonResult;
 
    public final static int INTTYPE = 0;
    public final static int STRINGTYPE = 1;
    public final static int BOOLTYPE = 2;
    public final static int NONTYPE = 3;
    public final static int JSONTYPE = 4;

    public ResultInfo(){
        resultType = NONTYPE;
    }
    public void setBoolResult(boolean boolRes){
        boolResult = boolRes;
    }
    public void setIntResult(int intRes){
        intResult = intRes;
    }
    public void setStringResult(String stringRes){
        stringResult = stringRes;
    }
    public void setJsonNode(JsonNode jsonRes){
        jsonResult = jsonRes;
    }
    public boolean getBoolResult(){
        return boolResult;
    }
    public int getIntResult(){
        return intResult;
    }
    public String getStringResult(){
        return stringResult;
    }
    public void setResultType(int type){
        resultType = type;
    }
    public int getResultType(){
        return resultType;
    }
    public JsonNode getJsonNode(){
        return jsonResult;
    }
}
