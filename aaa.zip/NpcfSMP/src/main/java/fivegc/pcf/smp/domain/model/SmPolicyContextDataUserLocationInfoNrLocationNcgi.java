package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoEutraLocationTaiPlmnId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyContextDataUserLocationInfoNrLocationNcgi
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyContextDataUserLocationInfoNrLocationNcgi   {
  @JsonProperty("plmnId")
  private SmPolicyContextDataUserLocationInfoEutraLocationTaiPlmnId plmnId = null;

  @JsonProperty("nrCellId")
  private String nrCellId;

  public SmPolicyContextDataUserLocationInfoNrLocationNcgi plmnId(SmPolicyContextDataUserLocationInfoEutraLocationTaiPlmnId plmnId) {
    this.plmnId = plmnId;
    return this;
  }

  /**
   * Get plmnId
   * @return plmnId
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public SmPolicyContextDataUserLocationInfoEutraLocationTaiPlmnId getPlmnId() {
    return plmnId;
  }

  public void setPlmnId(SmPolicyContextDataUserLocationInfoEutraLocationTaiPlmnId plmnId) {
    this.plmnId = plmnId;
  }

  public SmPolicyContextDataUserLocationInfoNrLocationNcgi nrCellId(String nrCellId) {
    this.nrCellId = nrCellId;
    return this;
  }

  /**
   * Get nrCellId
   * @return nrCellId
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Pattern(regexp="^[A-Fa-f0-9]{9}$") 
  public String getNrCellId() {
    return nrCellId;
  }

  public void setNrCellId(String nrCellId) {
    this.nrCellId = nrCellId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyContextDataUserLocationInfoNrLocationNcgi smPolicyContextDataUserLocationInfoNrLocationNcgi = (SmPolicyContextDataUserLocationInfoNrLocationNcgi) o;
    return Objects.equals(this.plmnId, smPolicyContextDataUserLocationInfoNrLocationNcgi.plmnId) &&
        Objects.equals(this.nrCellId, smPolicyContextDataUserLocationInfoNrLocationNcgi.nrCellId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(plmnId, nrCellId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyContextDataUserLocationInfoNrLocationNcgi {\n");
    
    sb.append("    plmnId: ").append(toIndentedString(plmnId)).append("\n");
    sb.append("    nrCellId: ").append(toIndentedString(nrCellId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

