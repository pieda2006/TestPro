package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * UpPathChgEvent
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class UpPathChgEvent   {
  @JsonProperty("notificationUri")
  private String notificationUri;

  @JsonProperty("notifCorreId")
  private String notifCorreId;

  /**
   * Possible values are - EARLY: Early notification of UP path reconfiguration. - EARLY_LATE: Early and late notification of UP path reconfiguration. This value shall only be present in the subscription to the DNAI change event. - LATE: Late notification of UP path reconfiguration. 
   */
  public enum DnaiChgTypeEnum {
    EARLY("EARLY"),
    
    EARLY_LATE("EARLY_LATE"),
    
    LATE("LATE");

    private String value;

    DnaiChgTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static DnaiChgTypeEnum fromValue(String value) {
      for (DnaiChgTypeEnum b : DnaiChgTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("dnaiChgType")
  private DnaiChgTypeEnum dnaiChgType;

  @JsonProperty("afAckInd")
  private Boolean afAckInd;

  public UpPathChgEvent notificationUri(String notificationUri) {
    this.notificationUri = notificationUri;
    return this;
  }

  /**
   * Get notificationUri
   * @return notificationUri
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getNotificationUri() {
    return notificationUri;
  }

  public void setNotificationUri(String notificationUri) {
    this.notificationUri = notificationUri;
  }

  public UpPathChgEvent notifCorreId(String notifCorreId) {
    this.notifCorreId = notifCorreId;
    return this;
  }

  /**
   * It is used to set the value of Notification Correlation ID in the notification sent by the SMF.
   * @return notifCorreId
  */
  @ApiModelProperty(required = true, value = "It is used to set the value of Notification Correlation ID in the notification sent by the SMF.")
  @NotNull


  public String getNotifCorreId() {
    return notifCorreId;
  }

  public void setNotifCorreId(String notifCorreId) {
    this.notifCorreId = notifCorreId;
  }

  public UpPathChgEvent dnaiChgType(DnaiChgTypeEnum dnaiChgType) {
    this.dnaiChgType = dnaiChgType;
    return this;
  }

  /**
   * Possible values are - EARLY: Early notification of UP path reconfiguration. - EARLY_LATE: Early and late notification of UP path reconfiguration. This value shall only be present in the subscription to the DNAI change event. - LATE: Late notification of UP path reconfiguration. 
   * @return dnaiChgType
  */
  @ApiModelProperty(required = true, value = "Possible values are - EARLY: Early notification of UP path reconfiguration. - EARLY_LATE: Early and late notification of UP path reconfiguration. This value shall only be present in the subscription to the DNAI change event. - LATE: Late notification of UP path reconfiguration. ")
  @NotNull


  public DnaiChgTypeEnum getDnaiChgType() {
    return dnaiChgType;
  }

  public void setDnaiChgType(DnaiChgTypeEnum dnaiChgType) {
    this.dnaiChgType = dnaiChgType;
  }

  public UpPathChgEvent afAckInd(Boolean afAckInd) {
    this.afAckInd = afAckInd;
    return this;
  }

  /**
   * Get afAckInd
   * @return afAckInd
  */
  @ApiModelProperty(value = "")


  public Boolean getAfAckInd() {
    return afAckInd;
  }

  public void setAfAckInd(Boolean afAckInd) {
    this.afAckInd = afAckInd;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UpPathChgEvent upPathChgEvent = (UpPathChgEvent) o;
    return Objects.equals(this.notificationUri, upPathChgEvent.notificationUri) &&
        Objects.equals(this.notifCorreId, upPathChgEvent.notifCorreId) &&
        Objects.equals(this.dnaiChgType, upPathChgEvent.dnaiChgType) &&
        Objects.equals(this.afAckInd, upPathChgEvent.afAckInd);
  }

  @Override
  public int hashCode() {
    return Objects.hash(notificationUri, notifCorreId, dnaiChgType, afAckInd);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UpPathChgEvent {\n");
    
    sb.append("    notificationUri: ").append(toIndentedString(notificationUri)).append("\n");
    sb.append("    notifCorreId: ").append(toIndentedString(notifCorreId)).append("\n");
    sb.append("    dnaiChgType: ").append(toIndentedString(dnaiChgType)).append("\n");
    sb.append("    afAckInd: ").append(toIndentedString(afAckInd)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

