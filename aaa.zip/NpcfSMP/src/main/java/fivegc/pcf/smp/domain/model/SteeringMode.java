package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import fivegc.pcf.smp.domain.model.SteerModeValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SteeringMode
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SteeringMode   {
  @JsonProperty("steerModeValue")
  private SteerModeValue steerModeValue;

  /**
   * Gets or Sets active
   */
  public enum ActiveEnum {
    _3GPP_ACCESS("3GPP_ACCESS"),
    
    NON_3GPP_ACCESS("NON_3GPP_ACCESS");

    private String value;

    ActiveEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ActiveEnum fromValue(String value) {
      for (ActiveEnum b : ActiveEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("active")
  private ActiveEnum active;

  /**
   * Gets or Sets standby
   */
  public enum StandbyEnum {
    _3GPP_ACCESS("3GPP_ACCESS"),
    
    NON_3GPP_ACCESS("NON_3GPP_ACCESS");

    private String value;

    StandbyEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static StandbyEnum fromValue(String value) {
      for (StandbyEnum b : StandbyEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("standby")
  private StandbyEnum standby;

  @JsonProperty("3gLoad")
  private Integer _3gLoad;

  /**
   * Gets or Sets prioAcc
   */
  public enum PrioAccEnum {
    _3GPP_ACCESS("3GPP_ACCESS"),
    
    NON_3GPP_ACCESS("NON_3GPP_ACCESS");

    private String value;

    PrioAccEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static PrioAccEnum fromValue(String value) {
      for (PrioAccEnum b : PrioAccEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("prioAcc")
  private PrioAccEnum prioAcc;

  public SteeringMode steerModeValue(SteerModeValue steerModeValue) {
    this.steerModeValue = steerModeValue;
    return this;
  }

  /**
   * Get steerModeValue
   * @return steerModeValue
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public SteerModeValue getSteerModeValue() {
    return steerModeValue;
  }

  public void setSteerModeValue(SteerModeValue steerModeValue) {
    this.steerModeValue = steerModeValue;
  }

  public SteeringMode active(ActiveEnum active) {
    this.active = active;
    return this;
  }

  /**
   * Get active
   * @return active
  */
  @ApiModelProperty(value = "")


  public ActiveEnum getActive() {
    return active;
  }

  public void setActive(ActiveEnum active) {
    this.active = active;
  }

  public SteeringMode standby(StandbyEnum standby) {
    this.standby = standby;
    return this;
  }

  /**
   * Get standby
   * @return standby
  */
  @ApiModelProperty(value = "")


  public StandbyEnum getStandby() {
    return standby;
  }

  public void setStandby(StandbyEnum standby) {
    this.standby = standby;
  }

  public SteeringMode _3gLoad(Integer _3gLoad) {
    this._3gLoad = _3gLoad;
    return this;
  }

  /**
   * Get _3gLoad
   * minimum: 0
   * @return _3gLoad
  */
  @ApiModelProperty(value = "")

@Min(0)
  public Integer get3gLoad() {
    return _3gLoad;
  }

  public void set3gLoad(Integer _3gLoad) {
    this._3gLoad = _3gLoad;
  }

  public SteeringMode prioAcc(PrioAccEnum prioAcc) {
    this.prioAcc = prioAcc;
    return this;
  }

  /**
   * Get prioAcc
   * @return prioAcc
  */
  @ApiModelProperty(value = "")


  public PrioAccEnum getPrioAcc() {
    return prioAcc;
  }

  public void setPrioAcc(PrioAccEnum prioAcc) {
    this.prioAcc = prioAcc;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SteeringMode steeringMode = (SteeringMode) o;
    return Objects.equals(this.steerModeValue, steeringMode.steerModeValue) &&
        Objects.equals(this.active, steeringMode.active) &&
        Objects.equals(this.standby, steeringMode.standby) &&
        Objects.equals(this._3gLoad, steeringMode._3gLoad) &&
        Objects.equals(this.prioAcc, steeringMode.prioAcc);
  }

  @Override
  public int hashCode() {
    return Objects.hash(steerModeValue, active, standby, _3gLoad, prioAcc);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SteeringMode {\n");
    
    sb.append("    steerModeValue: ").append(toIndentedString(steerModeValue)).append("\n");
    sb.append("    active: ").append(toIndentedString(active)).append("\n");
    sb.append("    standby: ").append(toIndentedString(standby)).append("\n");
    sb.append("    _3gLoad: ").append(toIndentedString(_3gLoad)).append("\n");
    sb.append("    prioAcc: ").append(toIndentedString(prioAcc)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

