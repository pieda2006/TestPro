package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.AccuUsageReport;
import fivegc.pcf.smp.domain.model.RanNasRelCause;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataServingNetwork;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyDeleteData
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyDeleteData   {
  @JsonProperty("userLocationInfo")
  private SmPolicyContextDataUserLocationInfo userLocationInfo = null;

  @JsonProperty("ueTimeZone")
  private String ueTimeZone;

  @JsonProperty("servingNetwork")
  private SmPolicyContextDataServingNetwork servingNetwork = null;

  @JsonProperty("userLocationInfoTime")
  private OffsetDateTime userLocationInfoTime;

  @JsonProperty("ranNasRelCauses")
  @Valid
  private List<RanNasRelCause> ranNasRelCauses = null;

  @JsonProperty("accuUsageReports")
  @Valid
  private List<AccuUsageReport> accuUsageReports = null;

  public SmPolicyDeleteData userLocationInfo(SmPolicyContextDataUserLocationInfo userLocationInfo) {
    this.userLocationInfo = userLocationInfo;
    return this;
  }

  /**
   * Get userLocationInfo
   * @return userLocationInfo
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataUserLocationInfo getUserLocationInfo() {
    return userLocationInfo;
  }

  public void setUserLocationInfo(SmPolicyContextDataUserLocationInfo userLocationInfo) {
    this.userLocationInfo = userLocationInfo;
  }

  public SmPolicyDeleteData ueTimeZone(String ueTimeZone) {
    this.ueTimeZone = ueTimeZone;
    return this;
  }

  /**
   * Get ueTimeZone
   * @return ueTimeZone
  */
  @ApiModelProperty(value = "")


  public String getUeTimeZone() {
    return ueTimeZone;
  }

  public void setUeTimeZone(String ueTimeZone) {
    this.ueTimeZone = ueTimeZone;
  }

  public SmPolicyDeleteData servingNetwork(SmPolicyContextDataServingNetwork servingNetwork) {
    this.servingNetwork = servingNetwork;
    return this;
  }

  /**
   * Get servingNetwork
   * @return servingNetwork
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataServingNetwork getServingNetwork() {
    return servingNetwork;
  }

  public void setServingNetwork(SmPolicyContextDataServingNetwork servingNetwork) {
    this.servingNetwork = servingNetwork;
  }

  public SmPolicyDeleteData userLocationInfoTime(OffsetDateTime userLocationInfoTime) {
    this.userLocationInfoTime = userLocationInfoTime;
    return this;
  }

  /**
   * Get userLocationInfoTime
   * @return userLocationInfoTime
  */
  @ApiModelProperty(value = "")

  @Valid

  public OffsetDateTime getUserLocationInfoTime() {
    return userLocationInfoTime;
  }

  public void setUserLocationInfoTime(OffsetDateTime userLocationInfoTime) {
    this.userLocationInfoTime = userLocationInfoTime;
  }

  public SmPolicyDeleteData ranNasRelCauses(List<RanNasRelCause> ranNasRelCauses) {
    this.ranNasRelCauses = ranNasRelCauses;
    return this;
  }

  public SmPolicyDeleteData addRanNasRelCausesItem(RanNasRelCause ranNasRelCausesItem) {
    if (this.ranNasRelCauses == null) {
      this.ranNasRelCauses = new ArrayList<>();
    }
    this.ranNasRelCauses.add(ranNasRelCausesItem);
    return this;
  }

  /**
   * Contains the RAN and/or NAS release cause.
   * @return ranNasRelCauses
  */
  @ApiModelProperty(value = "Contains the RAN and/or NAS release cause.")

  @Valid
@Size(min=1) 
  public List<RanNasRelCause> getRanNasRelCauses() {
    return ranNasRelCauses;
  }

  public void setRanNasRelCauses(List<RanNasRelCause> ranNasRelCauses) {
    this.ranNasRelCauses = ranNasRelCauses;
  }

  public SmPolicyDeleteData accuUsageReports(List<AccuUsageReport> accuUsageReports) {
    this.accuUsageReports = accuUsageReports;
    return this;
  }

  public SmPolicyDeleteData addAccuUsageReportsItem(AccuUsageReport accuUsageReportsItem) {
    if (this.accuUsageReports == null) {
      this.accuUsageReports = new ArrayList<>();
    }
    this.accuUsageReports.add(accuUsageReportsItem);
    return this;
  }

  /**
   * Contains the usage report
   * @return accuUsageReports
  */
  @ApiModelProperty(value = "Contains the usage report")

  @Valid
@Size(min=1) 
  public List<AccuUsageReport> getAccuUsageReports() {
    return accuUsageReports;
  }

  public void setAccuUsageReports(List<AccuUsageReport> accuUsageReports) {
    this.accuUsageReports = accuUsageReports;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyDeleteData smPolicyDeleteData = (SmPolicyDeleteData) o;
    return Objects.equals(this.userLocationInfo, smPolicyDeleteData.userLocationInfo) &&
        Objects.equals(this.ueTimeZone, smPolicyDeleteData.ueTimeZone) &&
        Objects.equals(this.servingNetwork, smPolicyDeleteData.servingNetwork) &&
        Objects.equals(this.userLocationInfoTime, smPolicyDeleteData.userLocationInfoTime) &&
        Objects.equals(this.ranNasRelCauses, smPolicyDeleteData.ranNasRelCauses) &&
        Objects.equals(this.accuUsageReports, smPolicyDeleteData.accuUsageReports);
  }

  @Override
  public int hashCode() {
    return Objects.hash(userLocationInfo, ueTimeZone, servingNetwork, userLocationInfoTime, ranNasRelCauses, accuUsageReports);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyDeleteData {\n");
    
    sb.append("    userLocationInfo: ").append(toIndentedString(userLocationInfo)).append("\n");
    sb.append("    ueTimeZone: ").append(toIndentedString(ueTimeZone)).append("\n");
    sb.append("    servingNetwork: ").append(toIndentedString(servingNetwork)).append("\n");
    sb.append("    userLocationInfoTime: ").append(toIndentedString(userLocationInfoTime)).append("\n");
    sb.append("    ranNasRelCauses: ").append(toIndentedString(ranNasRelCauses)).append("\n");
    sb.append("    accuUsageReports: ").append(toIndentedString(accuUsageReports)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

