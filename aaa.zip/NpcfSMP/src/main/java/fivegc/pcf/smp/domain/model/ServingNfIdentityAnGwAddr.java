package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * describes the address of the access network gateway control node
 */
@ApiModel(description = "describes the address of the access network gateway control node")
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class ServingNfIdentityAnGwAddr   {
  @JsonProperty("anGwIpv4Addr")
  private String anGwIpv4Addr;

  @JsonProperty("anGwIpv6Addr")
  private String anGwIpv6Addr;

  public ServingNfIdentityAnGwAddr anGwIpv4Addr(String anGwIpv4Addr) {
    this.anGwIpv4Addr = anGwIpv4Addr;
    return this;
  }

  /**
   * Get anGwIpv4Addr
   * @return anGwIpv4Addr
  */
  @ApiModelProperty(example = "198.51.100.1", value = "")

@Pattern(regexp="^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$") 
  public String getAnGwIpv4Addr() {
    return anGwIpv4Addr;
  }

  public void setAnGwIpv4Addr(String anGwIpv4Addr) {
    this.anGwIpv4Addr = anGwIpv4Addr;
  }

  public ServingNfIdentityAnGwAddr anGwIpv6Addr(String anGwIpv6Addr) {
    this.anGwIpv6Addr = anGwIpv6Addr;
    return this;
  }

  /**
   * Get anGwIpv6Addr
   * @return anGwIpv6Addr
  */
  @ApiModelProperty(example = "2001:db8:85a3::8a2e:370:7334", value = "")


  public String getAnGwIpv6Addr() {
    return anGwIpv6Addr;
  }

  public void setAnGwIpv6Addr(String anGwIpv6Addr) {
    this.anGwIpv6Addr = anGwIpv6Addr;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ServingNfIdentityAnGwAddr servingNfIdentityAnGwAddr = (ServingNfIdentityAnGwAddr) o;
    return Objects.equals(this.anGwIpv4Addr, servingNfIdentityAnGwAddr.anGwIpv4Addr) &&
        Objects.equals(this.anGwIpv6Addr, servingNfIdentityAnGwAddr.anGwIpv6Addr);
  }

  @Override
  public int hashCode() {
    return Objects.hash(anGwIpv4Addr, anGwIpv6Addr);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ServingNfIdentityAnGwAddr {\n");
    
    sb.append("    anGwIpv4Addr: ").append(toIndentedString(anGwIpv4Addr)).append("\n");
    sb.append("    anGwIpv6Addr: ").append(toIndentedString(anGwIpv6Addr)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

