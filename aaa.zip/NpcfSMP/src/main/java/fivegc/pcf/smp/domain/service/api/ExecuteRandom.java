package fivegc.pcf.smp.domain.service.api;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.security.SecureRandom;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class ExecuteRandom extends ExecuteBase {

    private JsonNode data;
    private int dataKind;
    private JsonNode maxJson;
    private int maxKind;
    private JsonNode minJson;
    private int minKind;
    private static final Logger log = LoggerFactory.getLogger(ExecuteRandom.class);

    public ExecuteRandom(){
    }

    void executeAction(JsonNode reqJson, ObjectNode ansJson, ObjectNode distJson, JsonNode actionJson, JsonNode operationJson) {


        int max = getIntFromJson(maxJson, maxKind, reqJson, actionJson, distJson, ansJson, operationJson);
        int min = getIntFromJson(minJson, minKind, reqJson, actionJson, distJson, ansJson, operationJson);
        int range = max - min;
        int randnum = 0;

        try {
            randnum = SecureRandom.getInstance("SHA1PRNG").nextInt(range) + min;
        } catch (Exception e) {
            log.error("Exception Ocurr");
            log.error(toString());
        }
        setResultObject(randnum, dataKind, data, distJson, ansJson);
    }

    public void setParameterFromJson(JsonNode operationjson){
        setResult(operationjson.path("Data"));
        setDataKind(operationjson.path("DataKind").asInt());
        setMin(operationjson.path("Min"));
        setMinKind(operationjson.path("MinKind").asInt());
        setMax(operationjson.path("Max"));
        setMaxKind(operationjson.path("MaxKind").asInt());
    } 

    void setResult(JsonNode inputjson){
        data = inputjson;
    }
    void setDataKind(int kind){
        dataKind = kind;
    }
    void setMin(JsonNode inputjson){
        minJson = inputjson;
    }
    void setMinKind(int kind){
        minKind = kind;
    }
    void setMax(JsonNode inputjson){
        maxJson = inputjson;
    }
    void setMaxKind(int kind){
        maxKind = kind;
    }
}
