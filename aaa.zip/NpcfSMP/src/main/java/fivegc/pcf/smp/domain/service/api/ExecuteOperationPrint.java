package fivegc.pcf.smp.domain.service.api;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class ExecuteOperationPrint extends ExecuteBase {

    private static final Logger log = LoggerFactory.getLogger(ExecuteOperationPrint.class);

    private JsonNode paramName;
    private int paramKind;

    public ExecuteOperationPrint(){
    }

    void executeAction(JsonNode reqJson, ObjectNode ansJson, ObjectNode distJson, JsonNode actionJson, JsonNode operationJson) {

        JsonNode dataObject = getObjectFromJson(paramName, paramKind, reqJson, actionJson, distJson, ansJson, operationJson);
        if(dataObject == null){
            log.error("Failed getObjectFromJson");
            return;
        }
        System.out.println(paramName.toString() + " = " + dataObject.toString());
        
    }

    public void setParameterFromJson(JsonNode operationjson){
        setParamName(operationjson.path("ParamName"));
        setParamKind(operationjson.path("ParamKind").asInt());
    }

    /*** getter setter ***/
    void setParamName(JsonNode name){
        paramName = name;
    }
    void setParamKind(int kind){
        paramKind = kind;
    }
}
