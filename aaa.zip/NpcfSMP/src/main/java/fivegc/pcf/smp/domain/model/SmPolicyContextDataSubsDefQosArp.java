package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyContextDataSubsDefQosArp
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyContextDataSubsDefQosArp   {
  @JsonProperty("priorityLevel")
  private JsonNullable<Integer> priorityLevel = JsonNullable.undefined();

  /**
   * Gets or Sets preemptCap
   */
  public enum PreemptCapEnum {
    NOT_PREEMPT("NOT_PREEMPT"),
    
    MAY_PREEMPT("MAY_PREEMPT");

    private String value;

    PreemptCapEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static PreemptCapEnum fromValue(String value) {
      for (PreemptCapEnum b : PreemptCapEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("preemptCap")
  private PreemptCapEnum preemptCap;

  /**
   * Gets or Sets preemptVuln
   */
  public enum PreemptVulnEnum {
    NOT_PREEMPTABLE("NOT_PREEMPTABLE"),
    
    PREEMPTABLE("PREEMPTABLE");

    private String value;

    PreemptVulnEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static PreemptVulnEnum fromValue(String value) {
      for (PreemptVulnEnum b : PreemptVulnEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("preemptVuln")
  private PreemptVulnEnum preemptVuln;

  public SmPolicyContextDataSubsDefQosArp priorityLevel(Integer priorityLevel) {
    this.priorityLevel = JsonNullable.of(priorityLevel);
    return this;
  }

  /**
   * nullable true shall not be used for this attribute
   * minimum: 1
   * maximum: 15
   * @return priorityLevel
  */
  @ApiModelProperty(required = true, value = "nullable true shall not be used for this attribute")
  @NotNull

@Min(1) @Max(15) 
  public JsonNullable<Integer> getPriorityLevel() {
    return priorityLevel;
  }

  public void setPriorityLevel(JsonNullable<Integer> priorityLevel) {
    this.priorityLevel = priorityLevel;
  }

  public SmPolicyContextDataSubsDefQosArp preemptCap(PreemptCapEnum preemptCap) {
    this.preemptCap = preemptCap;
    return this;
  }

  /**
   * Get preemptCap
   * @return preemptCap
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public PreemptCapEnum getPreemptCap() {
    return preemptCap;
  }

  public void setPreemptCap(PreemptCapEnum preemptCap) {
    this.preemptCap = preemptCap;
  }

  public SmPolicyContextDataSubsDefQosArp preemptVuln(PreemptVulnEnum preemptVuln) {
    this.preemptVuln = preemptVuln;
    return this;
  }

  /**
   * Get preemptVuln
   * @return preemptVuln
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public PreemptVulnEnum getPreemptVuln() {
    return preemptVuln;
  }

  public void setPreemptVuln(PreemptVulnEnum preemptVuln) {
    this.preemptVuln = preemptVuln;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyContextDataSubsDefQosArp smPolicyContextDataSubsDefQosArp = (SmPolicyContextDataSubsDefQosArp) o;
    return Objects.equals(this.priorityLevel, smPolicyContextDataSubsDefQosArp.priorityLevel) &&
        Objects.equals(this.preemptCap, smPolicyContextDataSubsDefQosArp.preemptCap) &&
        Objects.equals(this.preemptVuln, smPolicyContextDataSubsDefQosArp.preemptVuln);
  }

  @Override
  public int hashCode() {
    return Objects.hash(priorityLevel, preemptCap, preemptVuln);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyContextDataSubsDefQosArp {\n");
    
    sb.append("    priorityLevel: ").append(toIndentedString(priorityLevel)).append("\n");
    sb.append("    preemptCap: ").append(toIndentedString(preemptCap)).append("\n");
    sb.append("    preemptVuln: ").append(toIndentedString(preemptVuln)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

