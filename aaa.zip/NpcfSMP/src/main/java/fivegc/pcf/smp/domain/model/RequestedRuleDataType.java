package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import io.swagger.annotations.ApiModel;
import com.fasterxml.jackson.annotation.JsonValue;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Possible values are - CH_ID: Indicates that the requested rule data is the charging identifier.  - MS_TIME_ZONE: Indicates that the requested access network info type is the UE's timezone. - USER_LOC_INFO: Indicates that the requested access network info type is the UE's location. - RES_RELEASE: Indicates that the requested rule data is the result of the release of resource. - SUCC_RES_ALLO: Indicates that the requested rule data is the successful resource allocation. 
 */
public enum RequestedRuleDataType {
  
  CH_ID("CH_ID"),
  
  MS_TIME_ZONE("MS_TIME_ZONE"),
  
  USER_LOC_INFO("USER_LOC_INFO"),
  
  RES_RELEASE("RES_RELEASE"),
  
  SUCC_RES_ALLO("SUCC_RES_ALLO");

  private String value;

  RequestedRuleDataType(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static RequestedRuleDataType fromValue(String value) {
    for (RequestedRuleDataType b : RequestedRuleDataType.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + value + "'");
  }
}

