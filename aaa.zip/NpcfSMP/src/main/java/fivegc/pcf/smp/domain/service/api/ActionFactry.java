package fivegc.pcf.smp.domain.service.api;

import java.sql.ResultSet;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;

class ActionFactory {
    private static ActionFactory myinstance = null;
    private final static String actionTableName = "ACTION_TABLE";
    private final static String KeyParamName = "ACTIONID";
    private final static int ACTION_ID = 1;
    private final static int ACTION_JSON = 2;
    private HashMap<Integer,ActionBase> actionHash = null;

    private static final Logger log = LoggerFactory.getLogger(ActionFactory.class);

    public ActionFactory(){
        actionHash = new HashMap<Integer,ActionBase>();
    }
    public static ActionFactory getInstance(){
        if(myinstance == null){
            myinstance = new ActionFactory();
        }
        return myinstance;
    }
    /**
     * ActionのJson文から条件判定用のオペレーションを作成する関数。
     * ・Json文のフォーマット不正等によりアクション用オブジェクト作成ができなかった場合はnullが返却される。
     * @author	ikeda_tss
     * @version sprint02
     * @since sprint02
     * @param JsonNode actionJson アクション用のオペレーションが記載されているJson文
     * @return	ExecuteBase アクション用のオブジェクトを返却する
     */
    public ExecuteBase createOperation(JsonNode actionJson){

        ExecuteBase executeObj = null;
        int operationType = actionJson.path("OperationType").asInt();

        DataManager datamanage = DataManager.getInstance();
        JsonNode configjson = datamanage.getConfigValue();

        if(configjson == null){
            log.error("No Config setting");
            return null;
        }

        JsonNode classNameJson = configjson.path("ExecuteClass");
        JsonNode operationjson = null;
        ObjectMapper objmapper = new ObjectMapper();

        int counter = 0;
        try {
            while (classNameJson.has(counter)) {
                JsonNode name = classNameJson.path(counter);
                if(name.path("OperationType").asInt() == operationType){
                    Object eveObject = Class.forName(name.path("ClassName").asText()).newInstance();
                   if(eveObject instanceof ExecuteBase){
                        executeObj = (ExecuteBase)eveObject;
                        break;
                    } else {
                        return null;
                    }
                }
                counter++;
            }
        } catch (Exception e) {
            log.error(e.toString());
        }

        if(executeObj == null){
            log.error("ExecuteSubClass is not Createded");
            return null;
        }

        counter = 0;
        Map.Entry<String,JsonNode> jsonmap = null;
        TreeMap<String,Object> jsonentry = new TreeMap<String,Object>();
        Iterator<Map.Entry<String,JsonNode>> jsonIte = actionJson.fields();
        try {
            while(jsonIte.hasNext()){
                jsonmap = jsonIte.next();
                if(!jsonmap.getKey().equals("Operation")){
                    jsonentry.put(jsonmap.getKey(),jsonmap.getValue());
                }
            }
            operationjson = objmapper.readTree(objmapper.writeValueAsString(jsonentry));
        } catch(Exception e){
            log.error(e.toString());
            JsonNodeFactory jsonfactory=JsonNodeFactory.instance;
            operationjson = new ObjectNode(jsonfactory); 
        }
        log.debug("operationjson : " + operationjson);
        executeObj.setParameterFromJson(operationjson); 
        executeObj.setOperationType(operationType);
        return executeObj;
    }

    public ActionBase getAction(int actionType){
        ActionBase actionObj = actionHash.get(actionType);

        int actionID;

        if(actionObj == null){
            DataManager datamanage = DataManager.getInstance();
            ResultSet result = datamanage.getData(actionTableName,KeyParamName,actionType);
            try {
                ObjectMapper objmapper = new ObjectMapper();
                result.next();
                JsonNode paramJson = objmapper.readTree(result.getString(ACTION_JSON));
                JsonNode actionJson = paramJson.path("Operation");

                ActionBase action = new ActionBase();
                ExecuteBase executeObj = null;
                int count = 0;
                for(count = 0; actionJson.has(count); count++){
                    executeObj = createOperation(actionJson.get(count));
                    action.setOperation(executeObj);
                }

                JsonNode operationjson = null;
                Map.Entry<String,JsonNode> jsonmap = null;
                TreeMap<String,Object> jsonentry = new TreeMap<String,Object>();
                Iterator<Map.Entry<String,JsonNode>> jsonIte = paramJson.fields();

                while(jsonIte.hasNext()){
                    jsonmap = jsonIte.next();
                    if(!jsonmap.getKey().equals("Operation")){
                       jsonentry.put(jsonmap.getKey(),jsonmap.getValue());
                    }
                }
                operationjson = objmapper.readTree(objmapper.writeValueAsString(jsonentry));
                actionID = result.getInt(ACTION_ID);
                actionHash.put(actionID, action);
                actionObj = action;
                actionObj.setActionType(actionID);

                actionObj.setOperationJson(operationjson);

            } catch (Exception e) {
                log.error(e.getMessage(), e);
            } 
        }
        ActionBase retAction = new ActionBase(actionObj);
        return retAction;
    }
}
