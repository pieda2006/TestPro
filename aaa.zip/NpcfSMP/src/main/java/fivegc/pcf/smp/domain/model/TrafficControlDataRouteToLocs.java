package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.TrafficControlDataRouteInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TrafficControlDataRouteToLocs
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class TrafficControlDataRouteToLocs   {
  @JsonProperty("dnai")
  private String dnai;

  @JsonProperty("routeInfo")
  private JsonNullable<TrafficControlDataRouteInfo> routeInfo = JsonNullable.undefined();

  @JsonProperty("routeProfId")
  private JsonNullable<String> routeProfId = JsonNullable.undefined();

  public TrafficControlDataRouteToLocs dnai(String dnai) {
    this.dnai = dnai;
    return this;
  }

  /**
   * Get dnai
   * @return dnai
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getDnai() {
    return dnai;
  }

  public void setDnai(String dnai) {
    this.dnai = dnai;
  }

  public TrafficControlDataRouteToLocs routeInfo(TrafficControlDataRouteInfo routeInfo) {
    this.routeInfo = JsonNullable.of(routeInfo);
    return this;
  }

  /**
   * Get routeInfo
   * @return routeInfo
  */
  @ApiModelProperty(value = "")

  @Valid

  public JsonNullable<TrafficControlDataRouteInfo> getRouteInfo() {
    return routeInfo;
  }

  public void setRouteInfo(JsonNullable<TrafficControlDataRouteInfo> routeInfo) {
    this.routeInfo = routeInfo;
  }

  public TrafficControlDataRouteToLocs routeProfId(String routeProfId) {
    this.routeProfId = JsonNullable.of(routeProfId);
    return this;
  }

  /**
   * Get routeProfId
   * @return routeProfId
  */
  @ApiModelProperty(value = "")


  public JsonNullable<String> getRouteProfId() {
    return routeProfId;
  }

  public void setRouteProfId(JsonNullable<String> routeProfId) {
    this.routeProfId = routeProfId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TrafficControlDataRouteToLocs trafficControlDataRouteToLocs = (TrafficControlDataRouteToLocs) o;
    return Objects.equals(this.dnai, trafficControlDataRouteToLocs.dnai) &&
        Objects.equals(this.routeInfo, trafficControlDataRouteToLocs.routeInfo) &&
        Objects.equals(this.routeProfId, trafficControlDataRouteToLocs.routeProfId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(dnai, routeInfo, routeProfId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TrafficControlDataRouteToLocs {\n");
    
    sb.append("    dnai: ").append(toIndentedString(dnai)).append("\n");
    sb.append("    routeInfo: ").append(toIndentedString(routeInfo)).append("\n");
    sb.append("    routeProfId: ").append(toIndentedString(routeProfId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

