package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.ServingNfIdentityAnGwAddr;
import fivegc.pcf.smp.domain.model.ServingNfIdentityGuami;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.UUID;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ServingNfIdentity
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class ServingNfIdentity   {
  @JsonProperty("servNfInstId")
  private UUID servNfInstId;

  @JsonProperty("guami")
  private ServingNfIdentityGuami guami = null;

  @JsonProperty("anGwAddr")
  private ServingNfIdentityAnGwAddr anGwAddr = null;

  public ServingNfIdentity servNfInstId(UUID servNfInstId) {
    this.servNfInstId = servNfInstId;
    return this;
  }

  /**
   * Get servNfInstId
   * @return servNfInstId
  */
  @ApiModelProperty(value = "")

  @Valid

  public UUID getServNfInstId() {
    return servNfInstId;
  }

  public void setServNfInstId(UUID servNfInstId) {
    this.servNfInstId = servNfInstId;
  }

  public ServingNfIdentity guami(ServingNfIdentityGuami guami) {
    this.guami = guami;
    return this;
  }

  /**
   * Get guami
   * @return guami
  */
  @ApiModelProperty(value = "")

  @Valid

  public ServingNfIdentityGuami getGuami() {
    return guami;
  }

  public void setGuami(ServingNfIdentityGuami guami) {
    this.guami = guami;
  }

  public ServingNfIdentity anGwAddr(ServingNfIdentityAnGwAddr anGwAddr) {
    this.anGwAddr = anGwAddr;
    return this;
  }

  /**
   * Get anGwAddr
   * @return anGwAddr
  */
  @ApiModelProperty(value = "")

  @Valid

  public ServingNfIdentityAnGwAddr getAnGwAddr() {
    return anGwAddr;
  }

  public void setAnGwAddr(ServingNfIdentityAnGwAddr anGwAddr) {
    this.anGwAddr = anGwAddr;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ServingNfIdentity servingNfIdentity = (ServingNfIdentity) o;
    return Objects.equals(this.servNfInstId, servingNfIdentity.servNfInstId) &&
        Objects.equals(this.guami, servingNfIdentity.guami) &&
        Objects.equals(this.anGwAddr, servingNfIdentity.anGwAddr);
  }

  @Override
  public int hashCode() {
    return Objects.hash(servNfInstId, guami, anGwAddr);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ServingNfIdentity {\n");
    
    sb.append("    servNfInstId: ").append(toIndentedString(servNfInstId)).append("\n");
    sb.append("    guami: ").append(toIndentedString(guami)).append("\n");
    sb.append("    anGwAddr: ").append(toIndentedString(anGwAddr)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

