package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoEutraLocationEcgi;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbId;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoEutraLocationTai;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoNrLocationNcgi;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyDecisionPraInfos
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyDecisionPraInfos   {
  @JsonProperty("praId")
  private String praId;

  /**
   * Gets or Sets presenceState
   */
  public enum PresenceStateEnum {
    IN_AREA("IN_AREA"),
    
    OUT_OF_AREA("OUT_OF_AREA"),
    
    UNKNOWN("UNKNOWN"),
    
    INACTIVE("INACTIVE");

    private String value;

    PresenceStateEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static PresenceStateEnum fromValue(String value) {
      for (PresenceStateEnum b : PresenceStateEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("presenceState")
  private PresenceStateEnum presenceState;

  @JsonProperty("trackingAreaList")
  @Valid
  private List<SmPolicyContextDataUserLocationInfoEutraLocationTai> trackingAreaList = null;

  @JsonProperty("ecgiList")
  @Valid
  private List<SmPolicyContextDataUserLocationInfoEutraLocationEcgi> ecgiList = null;

  @JsonProperty("ncgiList")
  @Valid
  private List<SmPolicyContextDataUserLocationInfoNrLocationNcgi> ncgiList = null;

  @JsonProperty("globalRanNodeIdList")
  @Valid
  private List<SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbId> globalRanNodeIdList = null;

  public SmPolicyDecisionPraInfos praId(String praId) {
    this.praId = praId;
    return this;
  }

  /**
   * Get praId
   * @return praId
  */
  @ApiModelProperty(value = "")


  public String getPraId() {
    return praId;
  }

  public void setPraId(String praId) {
    this.praId = praId;
  }

  public SmPolicyDecisionPraInfos presenceState(PresenceStateEnum presenceState) {
    this.presenceState = presenceState;
    return this;
  }

  /**
   * Get presenceState
   * @return presenceState
  */
  @ApiModelProperty(value = "")


  public PresenceStateEnum getPresenceState() {
    return presenceState;
  }

  public void setPresenceState(PresenceStateEnum presenceState) {
    this.presenceState = presenceState;
  }

  public SmPolicyDecisionPraInfos trackingAreaList(List<SmPolicyContextDataUserLocationInfoEutraLocationTai> trackingAreaList) {
    this.trackingAreaList = trackingAreaList;
    return this;
  }

  public SmPolicyDecisionPraInfos addTrackingAreaListItem(SmPolicyContextDataUserLocationInfoEutraLocationTai trackingAreaListItem) {
    if (this.trackingAreaList == null) {
      this.trackingAreaList = new ArrayList<>();
    }
    this.trackingAreaList.add(trackingAreaListItem);
    return this;
  }

  /**
   * Get trackingAreaList
   * @return trackingAreaList
  */
  @ApiModelProperty(value = "")

  @Valid
@Size(min=0) 
  public List<SmPolicyContextDataUserLocationInfoEutraLocationTai> getTrackingAreaList() {
    return trackingAreaList;
  }

  public void setTrackingAreaList(List<SmPolicyContextDataUserLocationInfoEutraLocationTai> trackingAreaList) {
    this.trackingAreaList = trackingAreaList;
  }

  public SmPolicyDecisionPraInfos ecgiList(List<SmPolicyContextDataUserLocationInfoEutraLocationEcgi> ecgiList) {
    this.ecgiList = ecgiList;
    return this;
  }

  public SmPolicyDecisionPraInfos addEcgiListItem(SmPolicyContextDataUserLocationInfoEutraLocationEcgi ecgiListItem) {
    if (this.ecgiList == null) {
      this.ecgiList = new ArrayList<>();
    }
    this.ecgiList.add(ecgiListItem);
    return this;
  }

  /**
   * Get ecgiList
   * @return ecgiList
  */
  @ApiModelProperty(value = "")

  @Valid
@Size(min=0) 
  public List<SmPolicyContextDataUserLocationInfoEutraLocationEcgi> getEcgiList() {
    return ecgiList;
  }

  public void setEcgiList(List<SmPolicyContextDataUserLocationInfoEutraLocationEcgi> ecgiList) {
    this.ecgiList = ecgiList;
  }

  public SmPolicyDecisionPraInfos ncgiList(List<SmPolicyContextDataUserLocationInfoNrLocationNcgi> ncgiList) {
    this.ncgiList = ncgiList;
    return this;
  }

  public SmPolicyDecisionPraInfos addNcgiListItem(SmPolicyContextDataUserLocationInfoNrLocationNcgi ncgiListItem) {
    if (this.ncgiList == null) {
      this.ncgiList = new ArrayList<>();
    }
    this.ncgiList.add(ncgiListItem);
    return this;
  }

  /**
   * Get ncgiList
   * @return ncgiList
  */
  @ApiModelProperty(value = "")

  @Valid
@Size(min=0) 
  public List<SmPolicyContextDataUserLocationInfoNrLocationNcgi> getNcgiList() {
    return ncgiList;
  }

  public void setNcgiList(List<SmPolicyContextDataUserLocationInfoNrLocationNcgi> ncgiList) {
    this.ncgiList = ncgiList;
  }

  public SmPolicyDecisionPraInfos globalRanNodeIdList(List<SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbId> globalRanNodeIdList) {
    this.globalRanNodeIdList = globalRanNodeIdList;
    return this;
  }

  public SmPolicyDecisionPraInfos addGlobalRanNodeIdListItem(SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbId globalRanNodeIdListItem) {
    if (this.globalRanNodeIdList == null) {
      this.globalRanNodeIdList = new ArrayList<>();
    }
    this.globalRanNodeIdList.add(globalRanNodeIdListItem);
    return this;
  }

  /**
   * Get globalRanNodeIdList
   * @return globalRanNodeIdList
  */
  @ApiModelProperty(value = "")

  @Valid

  public List<SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbId> getGlobalRanNodeIdList() {
    return globalRanNodeIdList;
  }

  public void setGlobalRanNodeIdList(List<SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbId> globalRanNodeIdList) {
    this.globalRanNodeIdList = globalRanNodeIdList;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyDecisionPraInfos smPolicyDecisionPraInfos = (SmPolicyDecisionPraInfos) o;
    return Objects.equals(this.praId, smPolicyDecisionPraInfos.praId) &&
        Objects.equals(this.presenceState, smPolicyDecisionPraInfos.presenceState) &&
        Objects.equals(this.trackingAreaList, smPolicyDecisionPraInfos.trackingAreaList) &&
        Objects.equals(this.ecgiList, smPolicyDecisionPraInfos.ecgiList) &&
        Objects.equals(this.ncgiList, smPolicyDecisionPraInfos.ncgiList) &&
        Objects.equals(this.globalRanNodeIdList, smPolicyDecisionPraInfos.globalRanNodeIdList);
  }

  @Override
  public int hashCode() {
    return Objects.hash(praId, presenceState, trackingAreaList, ecgiList, ncgiList, globalRanNodeIdList);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyDecisionPraInfos {\n");
    
    sb.append("    praId: ").append(toIndentedString(praId)).append("\n");
    sb.append("    presenceState: ").append(toIndentedString(presenceState)).append("\n");
    sb.append("    trackingAreaList: ").append(toIndentedString(trackingAreaList)).append("\n");
    sb.append("    ecgiList: ").append(toIndentedString(ecgiList)).append("\n");
    sb.append("    ncgiList: ").append(toIndentedString(ncgiList)).append("\n");
    sb.append("    globalRanNodeIdList: ").append(toIndentedString(globalRanNodeIdList)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

