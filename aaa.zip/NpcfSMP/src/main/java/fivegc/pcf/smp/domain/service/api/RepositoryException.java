// parasoft-begin-suppress SECURITY.WSC.INIVF-4 "2019/5/24対処不要と整理"
package fivegc.pcf.smp.domain.service.api;

import java.io.IOException;
import java.io.ObjectInputStream;

public final class RepositoryException extends Exception {

    private static final long serialVersionUID = 1;

    private final transient ReposErrSts reposErrSts;

    static final String DESEIALIZED_ERR_MSG = "RepositoryException Object cannot be deserialized";

    public enum ReposErrSts {
        SOFTWARE_BUG(0),
        GENERAL_ERR(1),
        USER_NOT_FOUND(2),
        RESOURCE_BUSY(3),
        DATA_NOT_FOUND(4);

        private final int iStatus;

        private ReposErrSts(final int iStatus) {
            this.iStatus = iStatus;
        }

        public int getInt() {
            return this.iStatus;
        }
    }

    public RepositoryException( ReposErrSts p_reposErrSts ) {
        this.reposErrSts = p_reposErrSts;
    }

    public ReposErrSts getErrSts() {
        return this.reposErrSts;
    }

    private final void readObject(ObjectInputStream out) throws IOException {
        throw new IOException( DESEIALIZED_ERR_MSG );
    }

}

