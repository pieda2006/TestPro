// parasoft-begin-suppress SECURITY.WSC.SL "文字リテラルの使用は許可"
// parasoft-begin-suppress PORT.LNSP-3 "2019/5/24対処不要と整理"
// parasoft-begin-suppress SECURITY.WSC.DSER-5 "2019/5/24対処不要と整理"
// parasoft-begin-suppress SECURITY.WSC.MCNC-5 "2019/5/24対処不要と整理"
// parasoft-begin-suppress SECURITY.WSC.SER-5 "2019/5/24対処不要と整理"
package fivegc.pcf.smp.domain.service.api;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * DbAccessStatisticsInfo.java
 */

@Scope("prototype")
@Service
@JsonIgnoreProperties(ignoreUnknown=true)
public class DbAccessStatisticsInfo {

	@JsonProperty("service")
	private final String service = "udr-db-access";

	@JsonProperty("serviceTransactionId")
	private String serviceTransactionId = null;

	@JsonProperty("startTime")
	private String startTime = null;

	@JsonProperty("dbAccessLatency")
	private String dbAccessLatency = null;

	@JsonProperty("tableName")
	private String tableName = null;

	@JsonProperty("columnNames")
	private List<String> columnNames = null;

	@JsonProperty("supi")
	private String supi = null;

	@JsonProperty("ueId")
	private String ueId = null;

	@JsonProperty("pduSessionId")
	private String pduSessionId = null;

	@JsonProperty("operationType")
	private String operationType = null;

	@JsonProperty("operationResult")
	private String operationResult = null;

	@JsonProperty("sqlState")
	private String sqlState = null;

	/**
	 * @return ServiceTransactionId
	 */
	public String getServiceTransactionId() {
		return serviceTransactionId;
	}

	/**
	 * @param inServiceTransactionId
	 */
	public void setServiceTransactionId(String inServiceTransactionId) {
		this.serviceTransactionId = inServiceTransactionId;
	}

	/**
	 * @return startTime
	 */
	public String getStartTime() {
		return startTime;
	}

	/**
	 * @param inStartTime
	 */
	public void setStartTime(String inStartTime) {
		this.startTime = inStartTime;
	}

	/**
	 * @return dbAccessLatency
	 */
	public String getDbAccessLatency() {
		return dbAccessLatency;
	}

	/**
	 * @param inDbAccessLatency
	 */
	public void setDbAccessLatency(String inDbAccessLatency) {
		this.dbAccessLatency = inDbAccessLatency;
	}

	/**
	 * @return tableName
	 */
	public String getTableName() {
		return tableName;
	}

	/**
	 * @param inTableName
	 */
	public void setTableName(String inTableName) {
		this.tableName = inTableName;
	}

	/**
	 * @return columnNames
	 */
	public List<String> getColumnNames() {
		if (null == this.columnNames) return null;
		return( new ArrayList<>(this.columnNames) );
	}

	/**
	 * @param inColumnNames
	 */
	public void setColumnNames(List<String> inColumnNames) {
		this.columnNames = inColumnNames;
	}

	/**
	 * @param inColumnNames
	 */
	public void addColumnNames(String inColumnName) {
		if (null == this.columnNames) {
			this.columnNames = new ArrayList<>();
		}
		this.columnNames.add(inColumnName);
	}

	/**
	 *
	 */
	public void clearColumnNames() {
		this.columnNames = null;
	}

	/**
	 * @return supi
	*/
	public String getSupi() {
		return supi;
	}

	/**
	 * @param inSupi
	 */
	public void setSupi(String inSupi) {
		this.supi = inSupi;
	}

	/**
	 * @return ueId
	*/
	public String getUeId() {
		return ueId;
	}

	/**
	 * @param inUeId
	 */
	public void setUeId(String inUeId) {
		this.ueId = inUeId;
	}

	/**
	 * @return pduSessionId
	*/
	public String getPduSessionId() {
		return pduSessionId;
	}

	/**
	 * @param inPduSessionId
	 */
	public void setPduSessionId(String inPduSessionId) {
		this.pduSessionId = inPduSessionId;
	}

	/**
	 * @return operationType
	 */
	public String getOperationType() {
		return operationType;
	}

	/**
	 * @param inOperationType
	 */
	public void setOperationType(String inOperationType) {
		this.operationType = inOperationType;
	}

	/**
	 * @return operationResult
	 */
	public String getOperationResult() {
		return operationResult;
	}

	/**
	 * @param inOperationResultr
	 */
	public void setOperationResult(String inOperationResult) {
		this.operationResult = inOperationResult;
	}

	/**
	 * @return sqlState
	 */
	public String getSqlState() {
		return sqlState;
	}

	/**
	 * @param inSqlState
	 */
	public void setSqlState(String inSqlState) {
		this.sqlState = inSqlState;
	}

	/* (非 Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "class DbAccessStatisticsInfo {\n"
			 + "    service: " + service + "\n"
			 + "    serviceTransactionId: " + serviceTransactionId + "\n"
			 + "    startTime: " + startTime + "\n"
			 + "    dbAccessLatency: " + dbAccessLatency + "\n"
			 + "    tableName: " + tableName + "\n"
			 + "    columnNames: " + columnNames + "\n"
			 + "    supi: " + supi + "\n"
			 + "    ueId: " + ueId + "\n"
			 + "    pduSessionId: " + pduSessionId + "\n"
			 + "    operationType: " + operationType + "\n"
			 + "    operationResult: " + operationResult + "\n"
			 + "    sqlState: " + sqlState + "\n"
			 + "}";
	}

}
