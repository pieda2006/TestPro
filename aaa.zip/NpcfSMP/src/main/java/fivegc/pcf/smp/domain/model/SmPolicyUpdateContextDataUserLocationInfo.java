package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoEutraLocation;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoN3gaLocation;
import fivegc.pcf.smp.domain.model.SmPolicyUpdateContextDataUserLocationInfoNrLocation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyUpdateContextDataUserLocationInfo
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyUpdateContextDataUserLocationInfo   {
  @JsonProperty("eutraLocation")
  private SmPolicyContextDataUserLocationInfoEutraLocation eutraLocation = null;

  @JsonProperty("nrLocation")
  private SmPolicyUpdateContextDataUserLocationInfoNrLocation nrLocation = null;

  @JsonProperty("n3gaLocation")
  private SmPolicyContextDataUserLocationInfoN3gaLocation n3gaLocation = null;

  public SmPolicyUpdateContextDataUserLocationInfo eutraLocation(SmPolicyContextDataUserLocationInfoEutraLocation eutraLocation) {
    this.eutraLocation = eutraLocation;
    return this;
  }

  /**
   * Get eutraLocation
   * @return eutraLocation
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataUserLocationInfoEutraLocation getEutraLocation() {
    return eutraLocation;
  }

  public void setEutraLocation(SmPolicyContextDataUserLocationInfoEutraLocation eutraLocation) {
    this.eutraLocation = eutraLocation;
  }

  public SmPolicyUpdateContextDataUserLocationInfo nrLocation(SmPolicyUpdateContextDataUserLocationInfoNrLocation nrLocation) {
    this.nrLocation = nrLocation;
    return this;
  }

  /**
   * Get nrLocation
   * @return nrLocation
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyUpdateContextDataUserLocationInfoNrLocation getNrLocation() {
    return nrLocation;
  }

  public void setNrLocation(SmPolicyUpdateContextDataUserLocationInfoNrLocation nrLocation) {
    this.nrLocation = nrLocation;
  }

  public SmPolicyUpdateContextDataUserLocationInfo n3gaLocation(SmPolicyContextDataUserLocationInfoN3gaLocation n3gaLocation) {
    this.n3gaLocation = n3gaLocation;
    return this;
  }

  /**
   * Get n3gaLocation
   * @return n3gaLocation
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataUserLocationInfoN3gaLocation getN3gaLocation() {
    return n3gaLocation;
  }

  public void setN3gaLocation(SmPolicyContextDataUserLocationInfoN3gaLocation n3gaLocation) {
    this.n3gaLocation = n3gaLocation;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyUpdateContextDataUserLocationInfo smPolicyUpdateContextDataUserLocationInfo = (SmPolicyUpdateContextDataUserLocationInfo) o;
    return Objects.equals(this.eutraLocation, smPolicyUpdateContextDataUserLocationInfo.eutraLocation) &&
        Objects.equals(this.nrLocation, smPolicyUpdateContextDataUserLocationInfo.nrLocation) &&
        Objects.equals(this.n3gaLocation, smPolicyUpdateContextDataUserLocationInfo.n3gaLocation);
  }

  @Override
  public int hashCode() {
    return Objects.hash(eutraLocation, nrLocation, n3gaLocation);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyUpdateContextDataUserLocationInfo {\n");
    
    sb.append("    eutraLocation: ").append(toIndentedString(eutraLocation)).append("\n");
    sb.append("    nrLocation: ").append(toIndentedString(nrLocation)).append("\n");
    sb.append("    n3gaLocation: ").append(toIndentedString(n3gaLocation)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

