package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.PacketFilterInfo;
import fivegc.pcf.smp.domain.model.RequestedQos;
import fivegc.pcf.smp.domain.model.RuleOperation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * UeInitiatedResourceRequest
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class UeInitiatedResourceRequest   {
  @JsonProperty("pccRuleId")
  private String pccRuleId;

  @JsonProperty("ruleOp")
  private RuleOperation ruleOp;

  @JsonProperty("precedence")
  private Integer precedence;

  @JsonProperty("packFiltInfo")
  @Valid
  private List<PacketFilterInfo> packFiltInfo = new ArrayList<>();

  @JsonProperty("reqQos")
  private RequestedQos reqQos = null;

  public UeInitiatedResourceRequest pccRuleId(String pccRuleId) {
    this.pccRuleId = pccRuleId;
    return this;
  }

  /**
   * Get pccRuleId
   * @return pccRuleId
  */
  @ApiModelProperty(value = "")


  public String getPccRuleId() {
    return pccRuleId;
  }

  public void setPccRuleId(String pccRuleId) {
    this.pccRuleId = pccRuleId;
  }

  public UeInitiatedResourceRequest ruleOp(RuleOperation ruleOp) {
    this.ruleOp = ruleOp;
    return this;
  }

  /**
   * Get ruleOp
   * @return ruleOp
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public RuleOperation getRuleOp() {
    return ruleOp;
  }

  public void setRuleOp(RuleOperation ruleOp) {
    this.ruleOp = ruleOp;
  }

  public UeInitiatedResourceRequest precedence(Integer precedence) {
    this.precedence = precedence;
    return this;
  }

  /**
   * Get precedence
   * @return precedence
  */
  @ApiModelProperty(value = "")


  public Integer getPrecedence() {
    return precedence;
  }

  public void setPrecedence(Integer precedence) {
    this.precedence = precedence;
  }

  public UeInitiatedResourceRequest packFiltInfo(List<PacketFilterInfo> packFiltInfo) {
    this.packFiltInfo = packFiltInfo;
    return this;
  }

  public UeInitiatedResourceRequest addPackFiltInfoItem(PacketFilterInfo packFiltInfoItem) {
    this.packFiltInfo.add(packFiltInfoItem);
    return this;
  }

  /**
   * Get packFiltInfo
   * @return packFiltInfo
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid
@Size(min=1) 
  public List<PacketFilterInfo> getPackFiltInfo() {
    return packFiltInfo;
  }

  public void setPackFiltInfo(List<PacketFilterInfo> packFiltInfo) {
    this.packFiltInfo = packFiltInfo;
  }

  public UeInitiatedResourceRequest reqQos(RequestedQos reqQos) {
    this.reqQos = reqQos;
    return this;
  }

  /**
   * Get reqQos
   * @return reqQos
  */
  @ApiModelProperty(value = "")

  @Valid

  public RequestedQos getReqQos() {
    return reqQos;
  }

  public void setReqQos(RequestedQos reqQos) {
    this.reqQos = reqQos;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UeInitiatedResourceRequest ueInitiatedResourceRequest = (UeInitiatedResourceRequest) o;
    return Objects.equals(this.pccRuleId, ueInitiatedResourceRequest.pccRuleId) &&
        Objects.equals(this.ruleOp, ueInitiatedResourceRequest.ruleOp) &&
        Objects.equals(this.precedence, ueInitiatedResourceRequest.precedence) &&
        Objects.equals(this.packFiltInfo, ueInitiatedResourceRequest.packFiltInfo) &&
        Objects.equals(this.reqQos, ueInitiatedResourceRequest.reqQos);
  }

  @Override
  public int hashCode() {
    return Objects.hash(pccRuleId, ruleOp, precedence, packFiltInfo, reqQos);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UeInitiatedResourceRequest {\n");
    
    sb.append("    pccRuleId: ").append(toIndentedString(pccRuleId)).append("\n");
    sb.append("    ruleOp: ").append(toIndentedString(ruleOp)).append("\n");
    sb.append("    precedence: ").append(toIndentedString(precedence)).append("\n");
    sb.append("    packFiltInfo: ").append(toIndentedString(packFiltInfo)).append("\n");
    sb.append("    reqQos: ").append(toIndentedString(reqQos)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

