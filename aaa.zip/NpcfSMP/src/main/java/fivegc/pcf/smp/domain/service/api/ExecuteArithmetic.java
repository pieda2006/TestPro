package fivegc.pcf.smp.domain.service.api;

import java.util.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class ExecuteArithmetic extends ExecuteBase {

    private static final Logger log = LoggerFactory.getLogger(ExecuteArithmetic.class);

    private JsonNode right;
    private JsonNode left;
    private JsonNode result;
    private int rightKind;
    private int leftKind;
    private int valueKind;
    private int dataKind;

    public final static int ADD = 6;
    public final static int SUB = 7;
    public final static int MUL = 8;
    public final static int DIV = 9;
    public final static int INTKEY = 0;
    public final static int STRINGKEY = 1;

    public ExecuteArithmetic(){
    }

   void executeAction(JsonNode reqJson, ObjectNode ansJson, ObjectNode distJson, JsonNode actionJson, JsonNode operationJson) {

        int rightnum = getIntFromJson(right, rightKind, reqJson, actionJson, distJson, ansJson, operationJson);
        int leftnum = getIntFromJson(left, leftKind, reqJson, actionJson, distJson, ansJson, operationJson);

        int calcResult = 0;

        if(operationType == 6){
            calcResult = leftnum + rightnum;
        } else if(operationType == 7){
            calcResult = leftnum - rightnum;
        } else if(operationType == 8){
            calcResult = leftnum * rightnum;
        } else if(operationType == 9){
            if(rightnum != 0){
                calcResult = leftnum / rightnum;
            }
        }

        setResultObject(calcResult, dataKind , result, ansJson, distJson); 
    }

    public void setParameterFromJson(JsonNode operationjson){

        if(operationjson == null){
            log.error("operationjson is NULL");
            return;
        }

        setRight(operationjson.path("Right"));
        setRightKind(operationjson.path("RightType").asInt());
        setLeft(operationjson.path("Left"));
        setResult(operationjson.path("Result"));
        setLeftKind(operationjson.path("LeftType").asInt());
        setResultKind(operationjson.path("DataKind").asInt());
    }

    private void setRight(JsonNode inputjson){
        right = inputjson;
    }
    private void setLeft(JsonNode inputjson){
        left = inputjson;
    }
    private void setResult(JsonNode inputjson){
        result = inputjson;
    }
    private void setRightKind(int kind){
        rightKind = kind;
    }
    private void setLeftKind(int kind){
        leftKind = kind;
    }
    private void setResultKind(int kind){
        dataKind = kind;
    }
}
