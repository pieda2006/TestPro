package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyContextDataSliceInfo
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyContextDataSliceInfo   {
  @JsonProperty("sst")
  private Integer sst;

  @JsonProperty("sd")
  private String sd;

  public SmPolicyContextDataSliceInfo sst(Integer sst) {
    this.sst = sst;
    return this;
  }

  /**
   * Get sst
   * minimum: 0
   * maximum: 255
   * @return sst
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Min(0) @Max(255) 
  public Integer getSst() {
    return sst;
  }

  public void setSst(Integer sst) {
    this.sst = sst;
  }

  public SmPolicyContextDataSliceInfo sd(String sd) {
    this.sd = sd;
    return this;
  }

  /**
   * Get sd
   * @return sd
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^[A-Fa-f0-9]{6}$") 
  public String getSd() {
    return sd;
  }

  public void setSd(String sd) {
    this.sd = sd;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyContextDataSliceInfo smPolicyContextDataSliceInfo = (SmPolicyContextDataSliceInfo) o;
    return Objects.equals(this.sst, smPolicyContextDataSliceInfo.sst) &&
        Objects.equals(this.sd, smPolicyContextDataSliceInfo.sd);
  }

  @Override
  public int hashCode() {
    return Objects.hash(sst, sd);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyContextDataSliceInfo {\n");
    
    sb.append("    sst: ").append(toIndentedString(sst)).append("\n");
    sb.append("    sd: ").append(toIndentedString(sd)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

