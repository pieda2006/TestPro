package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets CreditManagementStatus
 */
public enum CreditManagementStatus {
  
  END_USER_SER_DENIED("END_USER_SER_DENIED"),
  
  CREDIT_CTRL_NOT_APP("CREDIT_CTRL_NOT_APP"),
  
  AUTH_REJECTED("AUTH_REJECTED"),
  
  USER_UNKNOWN("USER_UNKNOWN"),
  
  RATING_FAILED("RATING_FAILED");

  private String value;

  CreditManagementStatus(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static CreditManagementStatus fromValue(String value) {
    for (CreditManagementStatus b : CreditManagementStatus.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + value + "'");
  }
}

