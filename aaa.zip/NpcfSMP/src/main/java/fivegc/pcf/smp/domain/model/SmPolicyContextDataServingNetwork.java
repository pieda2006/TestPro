package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyContextDataServingNetwork
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyContextDataServingNetwork   {
  @JsonProperty("mnc")
  private String mnc;

  @JsonProperty("mcc")
  private String mcc;

  public SmPolicyContextDataServingNetwork mnc(String mnc) {
    this.mnc = mnc;
    return this;
  }

  /**
   * Get mnc
   * @return mnc
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^\\d{2,3}$") 
  public String getMnc() {
    return mnc;
  }

  public void setMnc(String mnc) {
    this.mnc = mnc;
  }

  public SmPolicyContextDataServingNetwork mcc(String mcc) {
    this.mcc = mcc;
    return this;
  }

  /**
   * Get mcc
   * @return mcc
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^\\d{3}$") 
  public String getMcc() {
    return mcc;
  }

  public void setMcc(String mcc) {
    this.mcc = mcc;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyContextDataServingNetwork smPolicyContextDataServingNetwork = (SmPolicyContextDataServingNetwork) o;
    return Objects.equals(this.mnc, smPolicyContextDataServingNetwork.mnc) &&
        Objects.equals(this.mcc, smPolicyContextDataServingNetwork.mcc);
  }

  @Override
  public int hashCode() {
    return Objects.hash(mnc, mcc);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyContextDataServingNetwork {\n");
    
    sb.append("    mnc: ").append(toIndentedString(mnc)).append("\n");
    sb.append("    mcc: ").append(toIndentedString(mcc)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

