package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoEutraLocationEcgi;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbId;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoEutraLocationTai;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.OffsetDateTime;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyContextDataUserLocationInfoEutraLocation
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyContextDataUserLocationInfoEutraLocation   {
  @JsonProperty("tai")
  private SmPolicyContextDataUserLocationInfoEutraLocationTai tai = null;

  @JsonProperty("ecgi")
  private SmPolicyContextDataUserLocationInfoEutraLocationEcgi ecgi = null;

  @JsonProperty("ageOfLocationInformation")
  private Integer ageOfLocationInformation;

  @JsonProperty("ueLocationTimestamp")
  private OffsetDateTime ueLocationTimestamp;

  @JsonProperty("geographicalInformation")
  private String geographicalInformation;

  @JsonProperty("geodeticInformation")
  private String geodeticInformation;

  @JsonProperty("globalNgenbId")
  private SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbId globalNgenbId = null;

  public SmPolicyContextDataUserLocationInfoEutraLocation tai(SmPolicyContextDataUserLocationInfoEutraLocationTai tai) {
    this.tai = tai;
    return this;
  }

  /**
   * Get tai
   * @return tai
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public SmPolicyContextDataUserLocationInfoEutraLocationTai getTai() {
    return tai;
  }

  public void setTai(SmPolicyContextDataUserLocationInfoEutraLocationTai tai) {
    this.tai = tai;
  }

  public SmPolicyContextDataUserLocationInfoEutraLocation ecgi(SmPolicyContextDataUserLocationInfoEutraLocationEcgi ecgi) {
    this.ecgi = ecgi;
    return this;
  }

  /**
   * Get ecgi
   * @return ecgi
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public SmPolicyContextDataUserLocationInfoEutraLocationEcgi getEcgi() {
    return ecgi;
  }

  public void setEcgi(SmPolicyContextDataUserLocationInfoEutraLocationEcgi ecgi) {
    this.ecgi = ecgi;
  }

  public SmPolicyContextDataUserLocationInfoEutraLocation ageOfLocationInformation(Integer ageOfLocationInformation) {
    this.ageOfLocationInformation = ageOfLocationInformation;
    return this;
  }

  /**
   * Get ageOfLocationInformation
   * minimum: 0
   * maximum: 32767
   * @return ageOfLocationInformation
  */
  @ApiModelProperty(value = "")

@Min(0) @Max(32767) 
  public Integer getAgeOfLocationInformation() {
    return ageOfLocationInformation;
  }

  public void setAgeOfLocationInformation(Integer ageOfLocationInformation) {
    this.ageOfLocationInformation = ageOfLocationInformation;
  }

  public SmPolicyContextDataUserLocationInfoEutraLocation ueLocationTimestamp(OffsetDateTime ueLocationTimestamp) {
    this.ueLocationTimestamp = ueLocationTimestamp;
    return this;
  }

  /**
   * Get ueLocationTimestamp
   * @return ueLocationTimestamp
  */
  @ApiModelProperty(value = "")

  @Valid

  public OffsetDateTime getUeLocationTimestamp() {
    return ueLocationTimestamp;
  }

  public void setUeLocationTimestamp(OffsetDateTime ueLocationTimestamp) {
    this.ueLocationTimestamp = ueLocationTimestamp;
  }

  public SmPolicyContextDataUserLocationInfoEutraLocation geographicalInformation(String geographicalInformation) {
    this.geographicalInformation = geographicalInformation;
    return this;
  }

  /**
   * Get geographicalInformation
   * @return geographicalInformation
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^[0-9A-F]{16}$") 
  public String getGeographicalInformation() {
    return geographicalInformation;
  }

  public void setGeographicalInformation(String geographicalInformation) {
    this.geographicalInformation = geographicalInformation;
  }

  public SmPolicyContextDataUserLocationInfoEutraLocation geodeticInformation(String geodeticInformation) {
    this.geodeticInformation = geodeticInformation;
    return this;
  }

  /**
   * Get geodeticInformation
   * @return geodeticInformation
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^[0-9A-F]{20}$") 
  public String getGeodeticInformation() {
    return geodeticInformation;
  }

  public void setGeodeticInformation(String geodeticInformation) {
    this.geodeticInformation = geodeticInformation;
  }

  public SmPolicyContextDataUserLocationInfoEutraLocation globalNgenbId(SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbId globalNgenbId) {
    this.globalNgenbId = globalNgenbId;
    return this;
  }

  /**
   * Get globalNgenbId
   * @return globalNgenbId
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbId getGlobalNgenbId() {
    return globalNgenbId;
  }

  public void setGlobalNgenbId(SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbId globalNgenbId) {
    this.globalNgenbId = globalNgenbId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyContextDataUserLocationInfoEutraLocation smPolicyContextDataUserLocationInfoEutraLocation = (SmPolicyContextDataUserLocationInfoEutraLocation) o;
    return Objects.equals(this.tai, smPolicyContextDataUserLocationInfoEutraLocation.tai) &&
        Objects.equals(this.ecgi, smPolicyContextDataUserLocationInfoEutraLocation.ecgi) &&
        Objects.equals(this.ageOfLocationInformation, smPolicyContextDataUserLocationInfoEutraLocation.ageOfLocationInformation) &&
        Objects.equals(this.ueLocationTimestamp, smPolicyContextDataUserLocationInfoEutraLocation.ueLocationTimestamp) &&
        Objects.equals(this.geographicalInformation, smPolicyContextDataUserLocationInfoEutraLocation.geographicalInformation) &&
        Objects.equals(this.geodeticInformation, smPolicyContextDataUserLocationInfoEutraLocation.geodeticInformation) &&
        Objects.equals(this.globalNgenbId, smPolicyContextDataUserLocationInfoEutraLocation.globalNgenbId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(tai, ecgi, ageOfLocationInformation, ueLocationTimestamp, geographicalInformation, geodeticInformation, globalNgenbId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyContextDataUserLocationInfoEutraLocation {\n");
    
    sb.append("    tai: ").append(toIndentedString(tai)).append("\n");
    sb.append("    ecgi: ").append(toIndentedString(ecgi)).append("\n");
    sb.append("    ageOfLocationInformation: ").append(toIndentedString(ageOfLocationInformation)).append("\n");
    sb.append("    ueLocationTimestamp: ").append(toIndentedString(ueLocationTimestamp)).append("\n");
    sb.append("    geographicalInformation: ").append(toIndentedString(geographicalInformation)).append("\n");
    sb.append("    geodeticInformation: ").append(toIndentedString(geodeticInformation)).append("\n");
    sb.append("    globalNgenbId: ").append(toIndentedString(globalNgenbId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

