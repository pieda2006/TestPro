package fivegc.pcf.smp.domain.service.api;

import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class EvaluateLogical extends EvaluateBase {

    private static final Logger log = LoggerFactory.getLogger(ExecuteBase.class);

    public final static int OR = 2;
    public final static int AND = 3;

    public EvaluateLogical(){
    }
    public ResultInfo evaluateCondition(JsonNode reqJson, JsonNode conditionJson, JsonNode operationJson){
        ResultInfo result = new ResultInfo();
        result.setResultType(ResultInfo.BOOLTYPE);

        result.setBoolResult(false);

        ResultInfo evalResult = null;

        for(int counter = 0; counter < evaluateObj.size(); counter++){
            evalResult = evaluateObj.get(counter).evaluateCondition(reqJson, conditionJson, operationJson);
            if(operationType == OR){
                if(evalResult.getBoolResult() == true){
                    result.setBoolResult(true);
                    return result;
                }
            } else {
                if(evalResult.getBoolResult() == false){
                    result.setBoolResult(false);
                    return result;
                }
            }
        }
        if(operationType == OR){
            result.setBoolResult(false);
            return result;
        } else {//AND
            result.setBoolResult(true);
            return result;
        }
    }
}
