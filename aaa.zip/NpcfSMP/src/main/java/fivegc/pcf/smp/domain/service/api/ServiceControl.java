package fivegc.pcf.smp.domain.service.api;

import java.util.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServiceControl {

    private static final Logger log = LoggerFactory.getLogger(ServiceControl.class);

    private static ServiceControl myinstance = null;

    /*** Constructer ***/

    public ServiceControl(){
    }

    public static ServiceControl getInstance(){
        if(myinstance == null){
            myinstance = new ServiceControl();
        }
        return myinstance;
    }
    /**
     * Input情報をもとにした条件判定、条件判定により導出されたアクションの実行を行う。
     * ・サービスプランが見つからなかった場合、応答にnullを返却する。
     * @author	ikeda_tss
     * @version sprint02
     * @since sprint02
     * @param String uri イベントを通知されたURI
     * @param JsonNode reqJson Requestのbody部に設定されていたJson文
     * @return	JsonNode Answer返却用のJson文
     */
    public JsonNode decideAction(String uri, JsonNode reqJson){
        ServicePlanFactory servicePlanfact = ServicePlanFactory.getInstance();

        ConditionBase conditionObj = servicePlanfact.getCondition(uri);

        ArrayList<ActionBase> actionList = new ArrayList<ActionBase>();


        while(conditionObj != null) {
            conditionObj = conditionObj.evaluateCondition(reqJson, actionList);
        }

        JsonNodeFactory jsonfactory=JsonNodeFactory.instance;

        ObjectNode ansJson = new ObjectNode(jsonfactory);
        ObjectNode actionJson = new ObjectNode(jsonfactory);

        for(int count = 0; count < actionList.size(); count++){
            actionList.get(count).executeAction(reqJson, ansJson, actionJson);
        }

        return ansJson;
    }
}

