package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.SmPolicyDecision;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyNotification
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyNotification   {
  @JsonProperty("resourceUri")
  private String resourceUri;

  @JsonProperty("smPolicyDecision")
  private SmPolicyDecision smPolicyDecision = null;

  public SmPolicyNotification resourceUri(String resourceUri) {
    this.resourceUri = resourceUri;
    return this;
  }

  /**
   * Get resourceUri
   * @return resourceUri
  */
  @ApiModelProperty(value = "")


  public String getResourceUri() {
    return resourceUri;
  }

  public void setResourceUri(String resourceUri) {
    this.resourceUri = resourceUri;
  }

  public SmPolicyNotification smPolicyDecision(SmPolicyDecision smPolicyDecision) {
    this.smPolicyDecision = smPolicyDecision;
    return this;
  }

  /**
   * Get smPolicyDecision
   * @return smPolicyDecision
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyDecision getSmPolicyDecision() {
    return smPolicyDecision;
  }

  public void setSmPolicyDecision(SmPolicyDecision smPolicyDecision) {
    this.smPolicyDecision = smPolicyDecision;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyNotification smPolicyNotification = (SmPolicyNotification) o;
    return Objects.equals(this.resourceUri, smPolicyNotification.resourceUri) &&
        Objects.equals(this.smPolicyDecision, smPolicyNotification.smPolicyDecision);
  }

  @Override
  public int hashCode() {
    return Objects.hash(resourceUri, smPolicyDecision);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyNotification {\n");
    
    sb.append("    resourceUri: ").append(toIndentedString(resourceUri)).append("\n");
    sb.append("    smPolicyDecision: ").append(toIndentedString(smPolicyDecision)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

