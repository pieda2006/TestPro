package fivegc.pcf.smp.domain.service.api;

import java.sql.ResultSet;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConditionFactory {
    private static ConditionFactory myinstance = null;
    private static final String conditionTableName = "CONDITION_TABLE";
    private static final String KeyParamName = "CONDITIONID";
    private static final int CONDITION_ID = 1;
    private static final int CONDITION_JSON = 2;

    private static final Logger log = LoggerFactory.getLogger(ConditionFactory.class);

    private HashMap<Integer,ConditionBase> conditionHash = null;

    public ConditionFactory(){
        conditionHash = new HashMap<Integer,ConditionBase>();
    }

    public static ConditionFactory getInstance(){
        if(myinstance == null){
            myinstance = new ConditionFactory();
        }
        return myinstance;
    }

    /**
     * ConditionのJson文から条件判定用のオペレーションを作成する関数。
     * ・Json文のフォーマット不正等により条件判定用オブジェクト作成ができなかった場合はnullが返却される。
     * @author	ikeda_tss
     * @version sprint02
     * @since sprint02
     * @param JsonNode conditionJson 条件判定用のオペレーションが記載されているJson文
     * @return	EvaluateBase 条件判定用のオブジェクトを返却する
     */
     
    public EvaluateBase createOperation(JsonNode conditionJson){
        JsonNode operationJson = null;
        EvaluateBase evaluateObj = null;

        int operationType = conditionJson.path("OperationType").asInt();

        DataManager datamanage = DataManager.getInstance();
        JsonNode configjson = datamanage.getConfigValue();

        if(configjson == null){
            log.error("No Config setting");
            return null;
        }

        JsonNode classNameJson = configjson.path("EvaluateClass");

        ObjectMapper objmapper = new ObjectMapper();

        int counter = 0;
        try {
            while (classNameJson.has(counter)) {
                JsonNode name = classNameJson.path(counter);
        	if(name.path("OperationType").asInt() == operationType){
        	    Object evalObject = Class.forName(name.path("ClassName").asText()).newInstance();
        	    if(evalObject instanceof EvaluateBase){
                        evaluateObj = (EvaluateBase)evalObject;
        		break;
        	    } else {
                        return null;
                    }
                }
                counter++;
            }
        } catch (Exception e) {
              log.error(e.toString());
        } 

        if(evaluateObj == null){
            log.error("EvaluateSubClass is not Created");
            return null;
        }

        counter = 0;
        operationJson = conditionJson.path("Operation");

        log.debug("operationJson : " + operationJson.toString());

        while (operationJson.has(counter)) {
            evaluateObj.setEvaluateObj(createOperation(operationJson.path(counter)));
            counter++;
        }

        operationJson = null;
        Map.Entry<String,JsonNode> jsonmap = null;
        TreeMap<String,Object> jsonentry = new TreeMap<String,Object>();
        Iterator<Map.Entry<String,JsonNode>> jsonIte = conditionJson.fields();

        try {
            while(jsonIte.hasNext()){
                jsonmap = jsonIte.next();
                if(!jsonmap.getKey().equals("Operation")){
                    jsonentry.put(jsonmap.getKey(),jsonmap.getValue());
                }
            }
            operationJson = objmapper.readTree(objmapper.writeValueAsString(jsonentry));
        } catch (Exception e){
        }
        evaluateObj.setParameterFromJson(operationJson); 
        evaluateObj.setOperationType(operationType);
        return evaluateObj;
    }
    
    public ConditionBase getCondition(int conditionType){
        int conditionID;
        ConditionBase conditionObj = conditionHash.get(conditionType);
        if(conditionObj == null){
            ObjectMapper objmapper = new ObjectMapper();
            DataManager datamanage = DataManager.getInstance();
            JsonNode conditionJson = null;
            ResultSet result = datamanage.getData(conditionTableName,KeyParamName,conditionType);
            try {
                result.next();

                conditionJson = objmapper.readTree(result.getString(CONDITION_JSON));
                ConditionBase condition = new ConditionBase();
                EvaluateBase evaluateObj = null;

                evaluateObj = createOperation(conditionJson);

               JsonNode operationjson = null;
               Map.Entry<String,JsonNode> jsonmap = null;
               TreeMap<String,Object> jsonentry = new TreeMap<String,Object>();
               Iterator<Map.Entry<String,JsonNode>> jsonIte = conditionJson.fields();

               while(jsonIte.hasNext()){
                   jsonmap = jsonIte.next();

                   if(!jsonmap.getKey().equals("Operation")){
                       /*if(jsonmap.getValue().isInt()){
                           jsonentry.put(jsonmap.getKey(),jsonmap.getValue().asInt());
                       } else if(jsonmap.getValue().isTextual()){
                           jsonentry.put(jsonmap.getKey(),jsonmap.getValue().asText());
                       }*/
                       jsonentry.put(jsonmap.getKey(),jsonmap.getValue());
                   }
               }
               operationjson = objmapper.readTree(objmapper.writeValueAsString(jsonentry));
                condition.setEvaluateObj(evaluateObj);
                conditionID = result.getInt(CONDITION_ID);
                conditionHash.put(conditionID, condition);
                conditionObj = condition;
                conditionObj.setConditionType(conditionID);
                conditionObj.setOperationJson(operationjson);
            } catch (Exception e) {
                //Error Action
            }
        }
        ConditionBase retCondition = new ConditionBase(conditionObj);
        return retCondition;
    }

}
