package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RequestedQos
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class RequestedQos   {
  @JsonProperty("5qi")
  private Integer _5qi;

  @JsonProperty("gbrUl")
  private String gbrUl;

  @JsonProperty("gbrDl")
  private String gbrDl;

  public RequestedQos _5qi(Integer _5qi) {
    this._5qi = _5qi;
    return this;
  }

  /**
   * Get _5qi
   * minimum: 0
   * maximum: 255
   * @return _5qi
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Min(0) @Max(255) 
  public Integer get5qi() {
    return _5qi;
  }

  public void set5qi(Integer _5qi) {
    this._5qi = _5qi;
  }

  public RequestedQos gbrUl(String gbrUl) {
    this.gbrUl = gbrUl;
    return this;
  }

  /**
   * Get gbrUl
   * @return gbrUl
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^\\d+(\\.\\d+)? (bps|Kbps|Mbps|Gbps|Tbps)$") 
  public String getGbrUl() {
    return gbrUl;
  }

  public void setGbrUl(String gbrUl) {
    this.gbrUl = gbrUl;
  }

  public RequestedQos gbrDl(String gbrDl) {
    this.gbrDl = gbrDl;
    return this;
  }

  /**
   * Get gbrDl
   * @return gbrDl
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^\\d+(\\.\\d+)? (bps|Kbps|Mbps|Gbps|Tbps)$") 
  public String getGbrDl() {
    return gbrDl;
  }

  public void setGbrDl(String gbrDl) {
    this.gbrDl = gbrDl;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RequestedQos requestedQos = (RequestedQos) o;
    return Objects.equals(this._5qi, requestedQos._5qi) &&
        Objects.equals(this.gbrUl, requestedQos.gbrUl) &&
        Objects.equals(this.gbrDl, requestedQos.gbrDl);
  }

  @Override
  public int hashCode() {
    return Objects.hash(_5qi, gbrUl, gbrDl);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RequestedQos {\n");
    
    sb.append("    _5qi: ").append(toIndentedString(_5qi)).append("\n");
    sb.append("    gbrUl: ").append(toIndentedString(gbrUl)).append("\n");
    sb.append("    gbrDl: ").append(toIndentedString(gbrDl)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

