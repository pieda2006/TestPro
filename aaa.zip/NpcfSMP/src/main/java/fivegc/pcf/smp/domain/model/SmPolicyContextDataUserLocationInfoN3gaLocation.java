package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoEutraLocationTai;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyContextDataUserLocationInfoN3gaLocation
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyContextDataUserLocationInfoN3gaLocation   {
  @JsonProperty("n3gppTai")
  private SmPolicyContextDataUserLocationInfoEutraLocationTai n3gppTai = null;

  @JsonProperty("n3IwfId")
  private String n3IwfId;

  @JsonProperty("ueIpv4Addr")
  private String ueIpv4Addr;

  @JsonProperty("ueIpv6Addr")
  private String ueIpv6Addr;

  @JsonProperty("portNumber")
  private Integer portNumber;

  public SmPolicyContextDataUserLocationInfoN3gaLocation n3gppTai(SmPolicyContextDataUserLocationInfoEutraLocationTai n3gppTai) {
    this.n3gppTai = n3gppTai;
    return this;
  }

  /**
   * Get n3gppTai
   * @return n3gppTai
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataUserLocationInfoEutraLocationTai getN3gppTai() {
    return n3gppTai;
  }

  public void setN3gppTai(SmPolicyContextDataUserLocationInfoEutraLocationTai n3gppTai) {
    this.n3gppTai = n3gppTai;
  }

  public SmPolicyContextDataUserLocationInfoN3gaLocation n3IwfId(String n3IwfId) {
    this.n3IwfId = n3IwfId;
    return this;
  }

  /**
   * Get n3IwfId
   * @return n3IwfId
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^[A-Fa-f0-9]+$") 
  public String getN3IwfId() {
    return n3IwfId;
  }

  public void setN3IwfId(String n3IwfId) {
    this.n3IwfId = n3IwfId;
  }

  public SmPolicyContextDataUserLocationInfoN3gaLocation ueIpv4Addr(String ueIpv4Addr) {
    this.ueIpv4Addr = ueIpv4Addr;
    return this;
  }

  /**
   * Get ueIpv4Addr
   * @return ueIpv4Addr
  */
  @ApiModelProperty(example = "198.51.100.1", value = "")

@Pattern(regexp="^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$") 
  public String getUeIpv4Addr() {
    return ueIpv4Addr;
  }

  public void setUeIpv4Addr(String ueIpv4Addr) {
    this.ueIpv4Addr = ueIpv4Addr;
  }

  public SmPolicyContextDataUserLocationInfoN3gaLocation ueIpv6Addr(String ueIpv6Addr) {
    this.ueIpv6Addr = ueIpv6Addr;
    return this;
  }

  /**
   * Get ueIpv6Addr
   * @return ueIpv6Addr
  */
  @ApiModelProperty(example = "2001:db8:85a3::8a2e:370:7334", value = "")


  public String getUeIpv6Addr() {
    return ueIpv6Addr;
  }

  public void setUeIpv6Addr(String ueIpv6Addr) {
    this.ueIpv6Addr = ueIpv6Addr;
  }

  public SmPolicyContextDataUserLocationInfoN3gaLocation portNumber(Integer portNumber) {
    this.portNumber = portNumber;
    return this;
  }

  /**
   * Get portNumber
   * minimum: 0
   * @return portNumber
  */
  @ApiModelProperty(value = "")

@Min(0)
  public Integer getPortNumber() {
    return portNumber;
  }

  public void setPortNumber(Integer portNumber) {
    this.portNumber = portNumber;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyContextDataUserLocationInfoN3gaLocation smPolicyContextDataUserLocationInfoN3gaLocation = (SmPolicyContextDataUserLocationInfoN3gaLocation) o;
    return Objects.equals(this.n3gppTai, smPolicyContextDataUserLocationInfoN3gaLocation.n3gppTai) &&
        Objects.equals(this.n3IwfId, smPolicyContextDataUserLocationInfoN3gaLocation.n3IwfId) &&
        Objects.equals(this.ueIpv4Addr, smPolicyContextDataUserLocationInfoN3gaLocation.ueIpv4Addr) &&
        Objects.equals(this.ueIpv6Addr, smPolicyContextDataUserLocationInfoN3gaLocation.ueIpv6Addr) &&
        Objects.equals(this.portNumber, smPolicyContextDataUserLocationInfoN3gaLocation.portNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(n3gppTai, n3IwfId, ueIpv4Addr, ueIpv6Addr, portNumber);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyContextDataUserLocationInfoN3gaLocation {\n");
    
    sb.append("    n3gppTai: ").append(toIndentedString(n3gppTai)).append("\n");
    sb.append("    n3IwfId: ").append(toIndentedString(n3IwfId)).append("\n");
    sb.append("    ueIpv4Addr: ").append(toIndentedString(ueIpv4Addr)).append("\n");
    sb.append("    ueIpv6Addr: ").append(toIndentedString(ueIpv6Addr)).append("\n");
    sb.append("    portNumber: ").append(toIndentedString(portNumber)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

