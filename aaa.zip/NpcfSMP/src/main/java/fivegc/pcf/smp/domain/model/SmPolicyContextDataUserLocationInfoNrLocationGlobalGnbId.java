package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbIdGNbId;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfoEutraLocationTaiPlmnId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId   {
  @JsonProperty("plmnId")
  private SmPolicyContextDataUserLocationInfoEutraLocationTaiPlmnId plmnId = null;

  @JsonProperty("n3IwfId")
  private String n3IwfId;

  @JsonProperty("gNbId")
  private SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbIdGNbId gNbId = null;

  @JsonProperty("ngeNbId")
  private String ngeNbId;

  public SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId plmnId(SmPolicyContextDataUserLocationInfoEutraLocationTaiPlmnId plmnId) {
    this.plmnId = plmnId;
    return this;
  }

  /**
   * Get plmnId
   * @return plmnId
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataUserLocationInfoEutraLocationTaiPlmnId getPlmnId() {
    return plmnId;
  }

  public void setPlmnId(SmPolicyContextDataUserLocationInfoEutraLocationTaiPlmnId plmnId) {
    this.plmnId = plmnId;
  }

  public SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId n3IwfId(String n3IwfId) {
    this.n3IwfId = n3IwfId;
    return this;
  }

  /**
   * Get n3IwfId
   * @return n3IwfId
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^[A-Fa-f0-9]+$") 
  public String getN3IwfId() {
    return n3IwfId;
  }

  public void setN3IwfId(String n3IwfId) {
    this.n3IwfId = n3IwfId;
  }

  public SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId gNbId(SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbIdGNbId gNbId) {
    this.gNbId = gNbId;
    return this;
  }

  /**
   * Get gNbId
   * @return gNbId
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbIdGNbId getgNbId() {
    return gNbId;
  }

  public void setgNbId(SmPolicyContextDataUserLocationInfoEutraLocationGlobalNgenbIdGNbId gNbId) {
    this.gNbId = gNbId;
  }

  public SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId ngeNbId(String ngeNbId) {
    this.ngeNbId = ngeNbId;
    return this;
  }

  /**
   * Get ngeNbId
   * @return ngeNbId
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^(MacroNGeNB-[A-Fa-f0-9]{5}|LMacroNGeNB-[A-Fa-f0-9]{6}|SMacroNGeNB-[A-Fa-f0-9]{5})$") 
  public String getNgeNbId() {
    return ngeNbId;
  }

  public void setNgeNbId(String ngeNbId) {
    this.ngeNbId = ngeNbId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId smPolicyContextDataUserLocationInfoNrLocationGlobalGnbId = (SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId) o;
    return Objects.equals(this.plmnId, smPolicyContextDataUserLocationInfoNrLocationGlobalGnbId.plmnId) &&
        Objects.equals(this.n3IwfId, smPolicyContextDataUserLocationInfoNrLocationGlobalGnbId.n3IwfId) &&
        Objects.equals(this.gNbId, smPolicyContextDataUserLocationInfoNrLocationGlobalGnbId.gNbId) &&
        Objects.equals(this.ngeNbId, smPolicyContextDataUserLocationInfoNrLocationGlobalGnbId.ngeNbId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(plmnId, n3IwfId, gNbId, ngeNbId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyContextDataUserLocationInfoNrLocationGlobalGnbId {\n");
    
    sb.append("    plmnId: ").append(toIndentedString(plmnId)).append("\n");
    sb.append("    n3IwfId: ").append(toIndentedString(n3IwfId)).append("\n");
    sb.append("    gNbId: ").append(toIndentedString(gNbId)).append("\n");
    sb.append("    ngeNbId: ").append(toIndentedString(ngeNbId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

