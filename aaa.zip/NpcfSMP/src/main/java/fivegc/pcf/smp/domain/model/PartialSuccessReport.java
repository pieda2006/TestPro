package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.FailureCause;
import fivegc.pcf.smp.domain.model.RuleReport;
import fivegc.pcf.smp.domain.model.SessionRuleReport;
import fivegc.pcf.smp.domain.model.UeCampingRep;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * PartialSuccessReport
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class PartialSuccessReport   {
  @JsonProperty("failureCause")
  private FailureCause failureCause;

  @JsonProperty("ruleReports")
  @Valid
  private List<RuleReport> ruleReports = null;

  @JsonProperty("sessRuleReports")
  @Valid
  private List<SessionRuleReport> sessRuleReports = null;

  @JsonProperty("ueCampingRep")
  private UeCampingRep ueCampingRep = null;

  public PartialSuccessReport failureCause(FailureCause failureCause) {
    this.failureCause = failureCause;
    return this;
  }

  /**
   * Get failureCause
   * @return failureCause
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public FailureCause getFailureCause() {
    return failureCause;
  }

  public void setFailureCause(FailureCause failureCause) {
    this.failureCause = failureCause;
  }

  public PartialSuccessReport ruleReports(List<RuleReport> ruleReports) {
    this.ruleReports = ruleReports;
    return this;
  }

  public PartialSuccessReport addRuleReportsItem(RuleReport ruleReportsItem) {
    if (this.ruleReports == null) {
      this.ruleReports = new ArrayList<>();
    }
    this.ruleReports.add(ruleReportsItem);
    return this;
  }

  /**
   * Information about the PCC rules provisioned by the PCF not successfully installed/activated.
   * @return ruleReports
  */
  @ApiModelProperty(value = "Information about the PCC rules provisioned by the PCF not successfully installed/activated.")

  @Valid
@Size(min=1) 
  public List<RuleReport> getRuleReports() {
    return ruleReports;
  }

  public void setRuleReports(List<RuleReport> ruleReports) {
    this.ruleReports = ruleReports;
  }

  public PartialSuccessReport sessRuleReports(List<SessionRuleReport> sessRuleReports) {
    this.sessRuleReports = sessRuleReports;
    return this;
  }

  public PartialSuccessReport addSessRuleReportsItem(SessionRuleReport sessRuleReportsItem) {
    if (this.sessRuleReports == null) {
      this.sessRuleReports = new ArrayList<>();
    }
    this.sessRuleReports.add(sessRuleReportsItem);
    return this;
  }

  /**
   * Information about the session rules provisioned by the PCF not successfully installed.
   * @return sessRuleReports
  */
  @ApiModelProperty(value = "Information about the session rules provisioned by the PCF not successfully installed.")

  @Valid
@Size(min=1) 
  public List<SessionRuleReport> getSessRuleReports() {
    return sessRuleReports;
  }

  public void setSessRuleReports(List<SessionRuleReport> sessRuleReports) {
    this.sessRuleReports = sessRuleReports;
  }

  public PartialSuccessReport ueCampingRep(UeCampingRep ueCampingRep) {
    this.ueCampingRep = ueCampingRep;
    return this;
  }

  /**
   * Get ueCampingRep
   * @return ueCampingRep
  */
  @ApiModelProperty(value = "")

  @Valid

  public UeCampingRep getUeCampingRep() {
    return ueCampingRep;
  }

  public void setUeCampingRep(UeCampingRep ueCampingRep) {
    this.ueCampingRep = ueCampingRep;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PartialSuccessReport partialSuccessReport = (PartialSuccessReport) o;
    return Objects.equals(this.failureCause, partialSuccessReport.failureCause) &&
        Objects.equals(this.ruleReports, partialSuccessReport.ruleReports) &&
        Objects.equals(this.sessRuleReports, partialSuccessReport.sessRuleReports) &&
        Objects.equals(this.ueCampingRep, partialSuccessReport.ueCampingRep);
  }

  @Override
  public int hashCode() {
    return Objects.hash(failureCause, ruleReports, sessRuleReports, ueCampingRep);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PartialSuccessReport {\n");
    
    sb.append("    failureCause: ").append(toIndentedString(failureCause)).append("\n");
    sb.append("    ruleReports: ").append(toIndentedString(ruleReports)).append("\n");
    sb.append("    sessRuleReports: ").append(toIndentedString(sessRuleReports)).append("\n");
    sb.append("    ueCampingRep: ").append(toIndentedString(ueCampingRep)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

