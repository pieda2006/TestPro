package fivegc.pcf.smp.domain.service.api;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
//import java.util.Random;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.*;
import com.fasterxml.jackson.databind.JsonNode;

import org.springframework.stereotype.Repository;
import org.springframework.context.annotation.Scope;

@Scope("prototype")
@Repository
public class RedisAPI {

  //private JedisPoolManager pool_mng;

  private static final Logger log = LoggerFactory.getLogger(RedisAPI.class);

  // uniq id 払い出しのためRedisに投入するluaスクリプト
  // (次の行と結合するので行末にスペースを追加すること)
  private static final String UniqIdHuntScript =
    "local K,M,C,B,i,s,p,v,z "            +
    "K=KEYS[1] "                          + // キーのbase
    "M=tonumber(ARGV[1]) "                + // 最大値
    "C=K..'_Cnt' "                        + // 最終捕捉カウンタキー
    "B=K..'_Bit' "                        + // 空塞管理bitキー
    "i=redis.call('INCR',C) "             + // 最終捕捉カウンタ + 1取得
    "s=math.floor(i/8) "                  + // バイト数に変換
    "p=redis.call('BITPOS',B,0,s) "       + // 最終捕捉バイト目から空きを検索
    "if(-1==p) then "                     + // BITPOSのstart位置が空塞管理bitキーのキーが拡張されてないバイトの場合、
    " z=redis.call('STRLEN',B) "          + // (例：空塞管理bitキーが0xffで最終捕捉カウンタが8)
    " if(math.ceil((M+1)/8)>z) then "     + // redisによってはエラーとなり次のバイトを捕捉できないためキーのlengthを判定し
    "  p=z*8 "                            + // 未拡張であればlengthの次のbitを捕捉する
    " end "                               +
    "end "                                +
    "if(M<=p) then "                      +
    " p=redis.call('BITPOS',B,0,0,s-1) "  + // 検索して見つからない場合は最初から検索
    "end "                                +
    "if(-1~=p) then "                     +
    " v=redis.call('SETBIT',B,p,1) "      + // UniqIdを使用中に変更
    " if(0==v) then "                     +
    "  redis.call('SET',C,p) "            + // 最終捕捉カウンタ更新
    "  return p "                         +
    " end "                               +
    "end "                                +
    "return p";

  public static final int Hash_num = 16;
  public static final int Hash_Split_Min = 1000;
  private Jedis jedis = null;
  private String hostname = "localhost";

  public RedisAPI() {
    jedis =  new Jedis(hostname,11211);
  }

  /**
   * TODO 与えられたデータを全てRedisに設定(Hash未対応)
   * @param Redis_Key
   * @param 設定するデータ
   */ 
  public void Redis_Set(String key, String value) {
	  
    //Jedis jedis = pool_mng.getJedisObj();
    
    String status_code = jedis.set(key, value);
    if(!status_code.equals("OK")){
      log.error("Redis Set Error: " + status_code);
    }

    //pool_mng.returnJedisObj(jedis);
    return;
  }

  /**
   * TODO 保持しているデータを全て取得(Hash未対応)
   * @param Redis_Key
   * @return 保持データ
   */
  public String Redis_Get(String key) {

    //Jedis jedis = pool_mng.getJedisObj();

    String value = jedis.get(key);
    if(null == value){
      log.warn("Redis Get Error key: " + key);
    }

    //pool_mng.returnJedisObj(jedis);
    return value;
  }

  /**
   * TODO 指定されたRedis_Keyに保持しているデータを全て削除する
   * @param Redis_Key
   */
  public void Redis_Del(String key) {

    log.info("Redis_Del start.");
    //Jedis jedis = pool_mng.getJedisObj();
    log.debug("delete start (key) " + key);

    Long delnum = jedis.del(key);
    log.debug("result : " + delnum);
    if(0 == delnum){
      log.error("Redis Del Error key: " + key);
    }

    //pool_mng.returnJedisObj(jedis);
    return;
  }

  /**
   * TODO Redis_keyに保持している指定されたHash_Keyのデータを削除する。
   * @param Redis_Key
   * @param Hash_Key
   */
  public void Redis_HDel(String key, String... fields) {

    log.info("Redis_Hdel start.");
    //Jedis jedis = pool_mng.getJedisObj();
    log.debug("delete start (key)   " + key);
    log.debug("delete start (field) " + fields);

    Long delnum = jedis.hdel(key, fields);
    log.debug("result : " + delnum);
    if(0 == delnum){
      log.error("Redis HDel Error key  : " + key);
      log.error("Redis HDel Error field: " + fields);
    }

    //pool_mng.returnJedisObj(jedis);
    return;
  }

  /**
   * TODO 渡されたHash_KeyとHash_Valueを指定したRedis_Keyに設定する
   * @param Redis_Key
   * @param Map(Hash_key, HashValue)
   */ 
  public void Redis_HMSet(String key, Map<String, String> value) {

	//Jedis jedis = pool_mng.getJedisObj();
    
    /* ハッシュ型の設定 */
    String status_code = jedis.hmset(key, value);
    
    if(!status_code.equals("OK")){
    	log.error("Redis Set Error: " + status_code);
    }

    //pool_mng.returnJedisObj(jedis);
    return;
  }


  /**
   * TODO 指定されたRedis_KeyのHash_Keyに対応するデータを取得し、Mapとして、Hash_Keyと対応したデータを返す。
   * @param Redis_Key
   * @param Hash_Key
   * @return Map(Hash_Key, Hash_Value)
   */
  public Map<String, String> Redis_HMGet(String key, String... fields) {
	  
    //Jedis jedis = pool_mng.getJedisObj();

    Map<String, String> map = new HashMap<>();
    int loop_cnt = 0;

    /* ハッシュ型の取得 */
    List<String> value = jedis.hmget(key, fields);
    if(null != value){
      for (String str : value){
        map.put(fields[loop_cnt], str);
        loop_cnt++;
      }
    }
    else{
      log.warn("Redis Get Error key: " + key);
    }

    //pool_mng.returnJedisObj(jedis);
    return map;
  }


  /**
   * 指定されたRedis_Keyのデータを全て取得する。
   * @param Redis_Key
   * @return Map(Hash_Key, Hash_Value)
   */
  public Map<String,String> Redis_HGetAll(String key) {

    //Jedis jedis = pool_mng.getJedisObj();

    Map<String, String> map = new HashMap<>(); 

    // RedisにHgetALL実施
    map = jedis.hgetAll(key);

    return map;
  }


  /**
   * UniqID捕捉
   *  (途中の計算式でint型の最大0x7fffffffを超えないように引数を指定すること)
   * 
   * @param 捕捉するキー情報
   * @param 捕捉するユニークIDの最小値
   * @param 捕捉するユニークIDの最大値
   * @return 捕捉したユニークID
   */
  public int Redis_UniqIdHunt(String key, int min, int max) {

    int hash_rand;
    //Jedis jedis = pool_mng.getJedisObj();

    // Redisに送信する最大値について引数の最大－最小値を行い、redisの最小値を0開始で正規化する。
    //  (BITPOSの開始指定がバイト単位のため開始を指定できない)
    int redis_max = max - min + 1; // 0開始なので個数にするため+1

    /* 小さな数でハッシュ分割してしまうと捕捉NGが発生しやすくなるため値が小さい場合は分割しない */
    /* また、ハッシュ分割する場合は余りが1等の小さい数字にならないようにmin/maxを設定すること   */
    /* (余りが1のブロックの場合、そのブロックで1つ使用中の場合でもそのブロックはエラーとなる)   */
    int hash_max = (redis_max + (Hash_num-1)) / Hash_num; // 端数のため切り上げ
    int hash_max_bk = hash_max;
    //if( hash_max > Hash_Split_Min)
    //{
        /* ハッシュ分割する場合 */
    //    Random random = new Random();
    //    hash_rand = random.nextInt(Hash_num);
    //    if( hash_rand == (Hash_num -1) )
    //    {
            // 最終面の場合は端数の場合があるため余りを設定
    //        hash_max = redis_max % hash_max;
    //        if ( hash_max == 0 ) {
                // 割り切れる場合は値を元に戻す
    //            hash_max = hash_max_bk;
    //        }
    //    }
    //}
    //else
    //{
        /* ハッシュ分割しない場合 */
        hash_max = redis_max;
        hash_rand = 0;
    //}
    key = "{" + key + ":" + hash_rand + "}";
    
    /* Redisアクセス */
    ArrayList<byte[]> keys = new ArrayList<byte[]>();
    ArrayList<byte[]> args = new ArrayList<byte[]>();
    keys.add(key.getBytes(StandardCharsets.UTF_8));
    args.add(String.valueOf(hash_max).getBytes(StandardCharsets.UTF_8));
    Long redis_uniqId = (Long) jedis.eval(UniqIdHuntScript.getBytes(StandardCharsets.UTF_8), keys, args);
    if(redis_uniqId == null) {
        log.error("Redis UniqIdHunt Error: null");
    }
    else if(redis_uniqId == -2) {
        log.error("Redis UniqIdHunt Lock NG: " + key);
        // 必要であればリトライ
    }
    else if(redis_uniqId < 0) {
        log.error("Redis UniqIdHunt Error: " + key + redis_uniqId);
    }

    log.debug("Redis UniqIdHunt uniqId: " + key + redis_uniqId);

    // アウトパラメータに設定
    if( hash_rand == (Hash_num -1) ) {
        // 書き換えを実施している場合は元に戻す
        hash_max = hash_max_bk;
    }

    if(redis_uniqId == null){
        log.error("redis_uniqId null" );
        return -1;
    }

    int uniqId = hash_rand * hash_max + redis_uniqId.intValue();

    // Redisからは正規化した値で払い出されるため、最小値を足して返す
    uniqId += min;

    // 捕捉したJedisリソースを解放
    //pool_mng.returnJedisObj(jedis);
    return uniqId;

  }
  
  /**
   * UniqID解放
   * 
   * @param 解放するキー情報
   * @param 解放するユニークID
   * @param 解放するユニークIDの最小値
   * @param 捕捉するユニークIDの最大値
   */
  public void Redis_UniqIdFree(String key, int uniqId, int min, int max) {

    int hash_id;
    int hash_rand;
    //Jedis jedis = pool_mng.getJedisObj();

    /* Redisに送信する最大値について引数の最大－最小値を行い、redisの最小値を0開始で正規化する。 */
    /*  (BITPOSの開始指定がバイト単位のため開始を指定できない)                                   */
    int redis_max = max - min + 1; // 0開始なので個数にするため+1

    // 最小値を0 開始に正規化してredis保存しているため
    // 最小値を引いてUniqIDとする
    int redis_uniqId = uniqId - min;

    /* 小さな数でハッシュ分割してしまうと捕捉NGが発生しやすくなるため値が小さい場合は分割しない */
    /* また、ハッシュ分割する場合は余りが1等の小さい数字にならないようにmin/maxを設定すること   */
    /* (余りが1のブロックの場合、そのブロックで1つ使用中の場合でもそのブロックはエラーとなる)   */
    int hash_max = (redis_max + (Hash_num-1)) / Hash_num; // 端数のため切り上げ
    if( hash_max > Hash_Split_Min)
    {
        /* ハッシュ分割する場合 */
        hash_rand = redis_uniqId / hash_max;
        hash_id = redis_uniqId % hash_max; 
    } 
    else
    {
        /* ハッシュ分割しない場合 */
        hash_id = redis_uniqId;
        hash_rand = 0;
    }

    key = "{" + key + ":" + hash_rand + "}_Bit";

    /* Redisアクセス */
    Boolean ret = (Boolean) jedis.setbit(key, hash_id, "0");
    
    if(ret == null) {
        log.error("Redis UniqIdFree Error: null");
    }

    log.debug("Redis UniqIdFree uniqId: " + key + hash_id);

    // 捕捉したJedisリソースを解放
    //pool_mng.returnJedisObj(jedis);
    return;

  }
}

