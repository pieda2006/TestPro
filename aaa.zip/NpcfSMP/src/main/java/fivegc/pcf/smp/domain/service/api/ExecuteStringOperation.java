package fivegc.pcf.smp.domain.service.api;

import java.util.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class ExecuteStringOperation extends ExecuteBase {

    private static final Logger log = LoggerFactory.getLogger(ExecuteStringOperation.class);

    private JsonNode right;
    private JsonNode left;
    private JsonNode result;
    private int rightKind;
    private int leftKind;
    private int valueKind;
    private int dataKind;

    public ExecuteStringOperation(){
    }

    void executeAction(JsonNode reqJson, ObjectNode ansJson, ObjectNode distJson, JsonNode actionJson, JsonNode operationJson) {
        String rightstring = getStringFromJson(right, rightKind, reqJson, actionJson, distJson, ansJson, operationJson);
        String leftstring = getStringFromJson(left, leftKind, reqJson, actionJson, distJson, ansJson, operationJson);

        if(rightstring == null || leftstring == null){
            log.error("There is no string to be concatenated");
            return;
        }

        String calcResult = null;

        calcResult = leftstring + rightstring;

        setResultObject(calcResult, dataKind, result, distJson, ansJson);

    }

    public void setParameterFromJson(JsonNode operationjson){
        setRight(operationjson.path("Right"));
        setRightKind(operationjson.path("RightType").asInt());
        setLeft(operationjson.path("Left"));
        setResult(operationjson.path("Result"));
        setLeftKind(operationjson.path("LeftType").asInt());
        setResultKind(operationjson.path("DataKind").asInt());
    }

    void setRight(JsonNode inputjson){
        right = inputjson;
    }
    void setLeft(JsonNode inputjson){
        left = inputjson;
    }
    void setResult(JsonNode inputjson){
        result = inputjson;
    }
    void setRightKind(int kind){
        rightKind = kind;
    }
    void setLeftKind(int kind){
        leftKind = kind;
    }
    void setResultKind(int kind){
        dataKind = kind;
    }
}
