package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.FlowDirectionRm;
import fivegc.pcf.smp.domain.model.FlowInformationEthFlowDescription;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * FlowInformation
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class FlowInformation   {
  @JsonProperty("flowDescription")
  private String flowDescription;

  @JsonProperty("ethFlowDescription")
  private FlowInformationEthFlowDescription ethFlowDescription = null;

  @JsonProperty("packFiltId")
  private String packFiltId;

  @JsonProperty("packetFilterUsage")
  private Boolean packetFilterUsage;

  @JsonProperty("tosTrafficClass")
  private JsonNullable<String> tosTrafficClass = JsonNullable.undefined();

  @JsonProperty("spi")
  private JsonNullable<String> spi = JsonNullable.undefined();

  @JsonProperty("flowLabel")
  private JsonNullable<String> flowLabel = JsonNullable.undefined();

  @JsonProperty("flowDirection")
  private JsonNullable<FlowDirectionRm> flowDirection = JsonNullable.undefined();

  public FlowInformation flowDescription(String flowDescription) {
    this.flowDescription = flowDescription;
    return this;
  }

  /**
   * Defines a packet filter for an IP flow.Refer to subclause 5.4.2 of 3GPP TS 29.212 [23] for encoding.
   * @return flowDescription
  */
  @ApiModelProperty(value = "Defines a packet filter for an IP flow.Refer to subclause 5.4.2 of 3GPP TS 29.212 [23] for encoding.")


  public String getFlowDescription() {
    return flowDescription;
  }

  public void setFlowDescription(String flowDescription) {
    this.flowDescription = flowDescription;
  }

  public FlowInformation ethFlowDescription(FlowInformationEthFlowDescription ethFlowDescription) {
    this.ethFlowDescription = ethFlowDescription;
    return this;
  }

  /**
   * Get ethFlowDescription
   * @return ethFlowDescription
  */
  @ApiModelProperty(value = "")

  @Valid

  public FlowInformationEthFlowDescription getEthFlowDescription() {
    return ethFlowDescription;
  }

  public void setEthFlowDescription(FlowInformationEthFlowDescription ethFlowDescription) {
    this.ethFlowDescription = ethFlowDescription;
  }

  public FlowInformation packFiltId(String packFiltId) {
    this.packFiltId = packFiltId;
    return this;
  }

  /**
   * An identifier of packet filter.
   * @return packFiltId
  */
  @ApiModelProperty(value = "An identifier of packet filter.")


  public String getPackFiltId() {
    return packFiltId;
  }

  public void setPackFiltId(String packFiltId) {
    this.packFiltId = packFiltId;
  }

  public FlowInformation packetFilterUsage(Boolean packetFilterUsage) {
    this.packetFilterUsage = packetFilterUsage;
    return this;
  }

  /**
   * The packet shall be sent to the UE.
   * @return packetFilterUsage
  */
  @ApiModelProperty(value = "The packet shall be sent to the UE.")


  public Boolean getPacketFilterUsage() {
    return packetFilterUsage;
  }

  public void setPacketFilterUsage(Boolean packetFilterUsage) {
    this.packetFilterUsage = packetFilterUsage;
  }

  public FlowInformation tosTrafficClass(String tosTrafficClass) {
    this.tosTrafficClass = JsonNullable.of(tosTrafficClass);
    return this;
  }

  /**
   * Contains the Ipv4 Type-of-Service and mask field or the Ipv6 Traffic-Class field and mask field.
   * @return tosTrafficClass
  */
  @ApiModelProperty(value = "Contains the Ipv4 Type-of-Service and mask field or the Ipv6 Traffic-Class field and mask field.")


  public JsonNullable<String> getTosTrafficClass() {
    return tosTrafficClass;
  }

  public void setTosTrafficClass(JsonNullable<String> tosTrafficClass) {
    this.tosTrafficClass = tosTrafficClass;
  }

  public FlowInformation spi(String spi) {
    this.spi = JsonNullable.of(spi);
    return this;
  }

  /**
   * the security parameter index of the IPSec packet.
   * @return spi
  */
  @ApiModelProperty(value = "the security parameter index of the IPSec packet.")


  public JsonNullable<String> getSpi() {
    return spi;
  }

  public void setSpi(JsonNullable<String> spi) {
    this.spi = spi;
  }

  public FlowInformation flowLabel(String flowLabel) {
    this.flowLabel = JsonNullable.of(flowLabel);
    return this;
  }

  /**
   * the Ipv6 flow label header field.
   * @return flowLabel
  */
  @ApiModelProperty(value = "the Ipv6 flow label header field.")


  public JsonNullable<String> getFlowLabel() {
    return flowLabel;
  }

  public void setFlowLabel(JsonNullable<String> flowLabel) {
    this.flowLabel = flowLabel;
  }

  public FlowInformation flowDirection(FlowDirectionRm flowDirection) {
    this.flowDirection = JsonNullable.of(flowDirection);
    return this;
  }

  /**
   * Get flowDirection
   * @return flowDirection
  */
  @ApiModelProperty(value = "")

  @Valid

  public JsonNullable<FlowDirectionRm> getFlowDirection() {
    return flowDirection;
  }

  public void setFlowDirection(JsonNullable<FlowDirectionRm> flowDirection) {
    this.flowDirection = flowDirection;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FlowInformation flowInformation = (FlowInformation) o;
    return Objects.equals(this.flowDescription, flowInformation.flowDescription) &&
        Objects.equals(this.ethFlowDescription, flowInformation.ethFlowDescription) &&
        Objects.equals(this.packFiltId, flowInformation.packFiltId) &&
        Objects.equals(this.packetFilterUsage, flowInformation.packetFilterUsage) &&
        Objects.equals(this.tosTrafficClass, flowInformation.tosTrafficClass) &&
        Objects.equals(this.spi, flowInformation.spi) &&
        Objects.equals(this.flowLabel, flowInformation.flowLabel) &&
        Objects.equals(this.flowDirection, flowInformation.flowDirection);
  }

  @Override
  public int hashCode() {
    return Objects.hash(flowDescription, ethFlowDescription, packFiltId, packetFilterUsage, tosTrafficClass, spi, flowLabel, flowDirection);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FlowInformation {\n");
    
    sb.append("    flowDescription: ").append(toIndentedString(flowDescription)).append("\n");
    sb.append("    ethFlowDescription: ").append(toIndentedString(ethFlowDescription)).append("\n");
    sb.append("    packFiltId: ").append(toIndentedString(packFiltId)).append("\n");
    sb.append("    packetFilterUsage: ").append(toIndentedString(packetFilterUsage)).append("\n");
    sb.append("    tosTrafficClass: ").append(toIndentedString(tosTrafficClass)).append("\n");
    sb.append("    spi: ").append(toIndentedString(spi)).append("\n");
    sb.append("    flowLabel: ").append(toIndentedString(flowLabel)).append("\n");
    sb.append("    flowDirection: ").append(toIndentedString(flowDirection)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

