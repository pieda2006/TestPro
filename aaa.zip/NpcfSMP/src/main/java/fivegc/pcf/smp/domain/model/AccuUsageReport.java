package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * AccuUsageReport
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class AccuUsageReport   {
  @JsonProperty("refUmIds")
  private String refUmIds;

  @JsonProperty("volUsage")
  private Long volUsage;

  @JsonProperty("volUsageUplink")
  private Long volUsageUplink;

  @JsonProperty("volUsageDownlink")
  private Long volUsageDownlink;

  @JsonProperty("timeUsage")
  private Integer timeUsage;

  @JsonProperty("nextVolUsage")
  private Long nextVolUsage;

  @JsonProperty("nextVolUsageUplink")
  private Long nextVolUsageUplink;

  @JsonProperty("nextVolUsageDownlink")
  private Long nextVolUsageDownlink;

  @JsonProperty("nextTimeUsage")
  private Integer nextTimeUsage;

  public AccuUsageReport refUmIds(String refUmIds) {
    this.refUmIds = refUmIds;
    return this;
  }

  /**
   * An id referencing UsageMonitoringData objects associated with this usage report.
   * @return refUmIds
  */
  @ApiModelProperty(required = true, value = "An id referencing UsageMonitoringData objects associated with this usage report.")
  @NotNull


  public String getRefUmIds() {
    return refUmIds;
  }

  public void setRefUmIds(String refUmIds) {
    this.refUmIds = refUmIds;
  }

  public AccuUsageReport volUsage(Long volUsage) {
    this.volUsage = volUsage;
    return this;
  }

  /**
   * Unsigned integer identifying a volume in units of bytes.
   * minimum: 0
   * @return volUsage
  */
  @ApiModelProperty(value = "Unsigned integer identifying a volume in units of bytes.")

@Min(0L)
  public Long getVolUsage() {
    return volUsage;
  }

  public void setVolUsage(Long volUsage) {
    this.volUsage = volUsage;
  }

  public AccuUsageReport volUsageUplink(Long volUsageUplink) {
    this.volUsageUplink = volUsageUplink;
    return this;
  }

  /**
   * Unsigned integer identifying a volume in units of bytes.
   * minimum: 0
   * @return volUsageUplink
  */
  @ApiModelProperty(value = "Unsigned integer identifying a volume in units of bytes.")

@Min(0L)
  public Long getVolUsageUplink() {
    return volUsageUplink;
  }

  public void setVolUsageUplink(Long volUsageUplink) {
    this.volUsageUplink = volUsageUplink;
  }

  public AccuUsageReport volUsageDownlink(Long volUsageDownlink) {
    this.volUsageDownlink = volUsageDownlink;
    return this;
  }

  /**
   * Unsigned integer identifying a volume in units of bytes.
   * minimum: 0
   * @return volUsageDownlink
  */
  @ApiModelProperty(value = "Unsigned integer identifying a volume in units of bytes.")

@Min(0L)
  public Long getVolUsageDownlink() {
    return volUsageDownlink;
  }

  public void setVolUsageDownlink(Long volUsageDownlink) {
    this.volUsageDownlink = volUsageDownlink;
  }

  public AccuUsageReport timeUsage(Integer timeUsage) {
    this.timeUsage = timeUsage;
    return this;
  }

  /**
   * Get timeUsage
   * @return timeUsage
  */
  @ApiModelProperty(value = "")


  public Integer getTimeUsage() {
    return timeUsage;
  }

  public void setTimeUsage(Integer timeUsage) {
    this.timeUsage = timeUsage;
  }

  public AccuUsageReport nextVolUsage(Long nextVolUsage) {
    this.nextVolUsage = nextVolUsage;
    return this;
  }

  /**
   * Unsigned integer identifying a volume in units of bytes.
   * minimum: 0
   * @return nextVolUsage
  */
  @ApiModelProperty(value = "Unsigned integer identifying a volume in units of bytes.")

@Min(0L)
  public Long getNextVolUsage() {
    return nextVolUsage;
  }

  public void setNextVolUsage(Long nextVolUsage) {
    this.nextVolUsage = nextVolUsage;
  }

  public AccuUsageReport nextVolUsageUplink(Long nextVolUsageUplink) {
    this.nextVolUsageUplink = nextVolUsageUplink;
    return this;
  }

  /**
   * Unsigned integer identifying a volume in units of bytes.
   * minimum: 0
   * @return nextVolUsageUplink
  */
  @ApiModelProperty(value = "Unsigned integer identifying a volume in units of bytes.")

@Min(0L)
  public Long getNextVolUsageUplink() {
    return nextVolUsageUplink;
  }

  public void setNextVolUsageUplink(Long nextVolUsageUplink) {
    this.nextVolUsageUplink = nextVolUsageUplink;
  }

  public AccuUsageReport nextVolUsageDownlink(Long nextVolUsageDownlink) {
    this.nextVolUsageDownlink = nextVolUsageDownlink;
    return this;
  }

  /**
   * Unsigned integer identifying a volume in units of bytes.
   * minimum: 0
   * @return nextVolUsageDownlink
  */
  @ApiModelProperty(value = "Unsigned integer identifying a volume in units of bytes.")

@Min(0L)
  public Long getNextVolUsageDownlink() {
    return nextVolUsageDownlink;
  }

  public void setNextVolUsageDownlink(Long nextVolUsageDownlink) {
    this.nextVolUsageDownlink = nextVolUsageDownlink;
  }

  public AccuUsageReport nextTimeUsage(Integer nextTimeUsage) {
    this.nextTimeUsage = nextTimeUsage;
    return this;
  }

  /**
   * Get nextTimeUsage
   * @return nextTimeUsage
  */
  @ApiModelProperty(value = "")


  public Integer getNextTimeUsage() {
    return nextTimeUsage;
  }

  public void setNextTimeUsage(Integer nextTimeUsage) {
    this.nextTimeUsage = nextTimeUsage;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AccuUsageReport accuUsageReport = (AccuUsageReport) o;
    return Objects.equals(this.refUmIds, accuUsageReport.refUmIds) &&
        Objects.equals(this.volUsage, accuUsageReport.volUsage) &&
        Objects.equals(this.volUsageUplink, accuUsageReport.volUsageUplink) &&
        Objects.equals(this.volUsageDownlink, accuUsageReport.volUsageDownlink) &&
        Objects.equals(this.timeUsage, accuUsageReport.timeUsage) &&
        Objects.equals(this.nextVolUsage, accuUsageReport.nextVolUsage) &&
        Objects.equals(this.nextVolUsageUplink, accuUsageReport.nextVolUsageUplink) &&
        Objects.equals(this.nextVolUsageDownlink, accuUsageReport.nextVolUsageDownlink) &&
        Objects.equals(this.nextTimeUsage, accuUsageReport.nextTimeUsage);
  }

  @Override
  public int hashCode() {
    return Objects.hash(refUmIds, volUsage, volUsageUplink, volUsageDownlink, timeUsage, nextVolUsage, nextVolUsageUplink, nextVolUsageDownlink, nextTimeUsage);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AccuUsageReport {\n");
    
    sb.append("    refUmIds: ").append(toIndentedString(refUmIds)).append("\n");
    sb.append("    volUsage: ").append(toIndentedString(volUsage)).append("\n");
    sb.append("    volUsageUplink: ").append(toIndentedString(volUsageUplink)).append("\n");
    sb.append("    volUsageDownlink: ").append(toIndentedString(volUsageDownlink)).append("\n");
    sb.append("    timeUsage: ").append(toIndentedString(timeUsage)).append("\n");
    sb.append("    nextVolUsage: ").append(toIndentedString(nextVolUsage)).append("\n");
    sb.append("    nextVolUsageUplink: ").append(toIndentedString(nextVolUsageUplink)).append("\n");
    sb.append("    nextVolUsageDownlink: ").append(toIndentedString(nextVolUsageDownlink)).append("\n");
    sb.append("    nextTimeUsage: ").append(toIndentedString(nextTimeUsage)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

