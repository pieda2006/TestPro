//package fivegc.smf.Repository.MYSQL_API_client;
package fivegc.pcf.smp.domain.service.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import java.sql.*;
import java.sql.PreparedStatement;

import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.SerializationFeature;

import org.springframework.context.annotation.Scope;

/**
 * DBにアクセスを実施する。
 * ユーザは事前にSQLクエリを設定する。
 * このクラスでは、ユーザが指定したSQLクエリを基に、DBに格納されているDataを操作する。
 */
@Scope("prototype")
@Repository
public final class DbAccessController{

    // DB Connection Infomation
    private static Connection con = null;
    private static PreparedStatement stm = null;
    private static ResultSet rs = null;

    private static String url = "jdbc:mysql://localhost:11200/PCF";
    private static String user = "root";
    private static String pass = "my-secret-pw";
    private static String table = "CONFIG";

    private static final Logger log = LoggerFactory.getLogger(DbAccessController.class);

    /**
     * DBアクセスを行うために、アクセス情報を取得し、コネクションを実施する。
     */ 
    public static void PreparationAccess() {

        log.info("### PreparationAccess Start ###");

        // DBアクセス情報取得
        //DbAccessInfo.setDbAccessInfo();

        // DB Connection 実施
        try {
            con = DriverManager.getConnection(url,user,pass);
            log.debug("con : " + con);
        } catch (SQLException e) {
            log.error("### Connection Error (SQLException) ###" , e );
        }

        log.info("### PreparationAccess End ###");

    }

    /**
     * PreparedStatementに登録されたクエリ内容を実行し、内部変数のResultSetに設定する。
     */
    private static void execSmfQuery() {

	String sqlState = "";

	int retryCount = 2;
	boolean transactionCompleted = false;

        log.info("### exeSmfQuery Start ###");

	log.debug("con : " + con);
	log.debug("stm : " + stm);

        do {

            if (null == stm) {
                log.error("### execSmfQuery Error End (PreparedStatement is null) throw GENERAL_ERR ###");
                break;
            }
            log.debug("retryCount : " + retryCount);

            try {
                // select文を起動
                rs = stm.executeQuery();
                log.debug("executeQuery Success stm : " + stm);

                transactionCompleted = true;

            } catch (SQLException e) {

	        log.error("### executeQuery Error End (SQLException) ###",e);
		log.error("execSmfQuery : con : " + con);

		try{
		    log.error("execSmfQuery : stm : " + stm);
		}
		catch (NullPointerException e1) {
		    log.error("execSmfQuery : stm : >>>Impossible to display.<<<" , e1);
		}

	        sqlState = e.getSQLState();
		log.error("execSmfQuery : sqlState : " + sqlState);

                // コネクションが失敗した場合、リトライ
		if ( "08S01".equals(sqlState) ) {
		    log.error("execSmfQuery : Retry Possible");
	            retryCount--;
		}
	        else {
		    log.error("execSmfQuery : Retry Impossible Error" , e );
		    break;
		}

            }

        } while( (false == transactionCompleted) && (retryCount >= 0) );

        if( false == transactionCompleted ) {
            log.error("### execSmfQuery Error End throw GENERAL_ERR ###");
        }

        log.info("### exeSmfQuery End ###");
    }

    /**
     * ResultDetとPreparedStatementとConnectionをクローズする。
     * すでにクローズされている場合はスキップする。
     */
    public static void smfConnectionClose() {

        log.info("### smfConnectionClose Start ###");

        // ResultSet
        try {
            if(null != rs) {
                log.debug("rs : " + rs);

                rs.close();
                rs = null;
            } else {
                log.debug("### smfConnectionClose -- ResuleSet::close() skip ###" );
            }
        } catch(Exception e) {
            log.error("### smfConnectionClose -- ResuleSet::close() Exception Occurred ###" , e );
        }

        // PreparedStatement close
	try {
	    if(null != stm) {
	        log.debug("stm : " + stm);

		stm.close();
		stm = null;
	    } else {
		log.debug("### smfConnectionClose -- PreparedStatement::close() skip ###" );
	    }
	} catch(Exception e) {
	    log.error("### smfConnectionClose -- PreparedStatement::close() Exception Occurred ###" , e );
	}

        // Connection close
	try {
	    if(null != con) {
	        log.debug("con : " + con);

		con.close();
		con = null;
	    } else {
		log.debug("### smfConnectionClose -- Connection::close() skip ###" );
	    }
	} catch(Exception e) {
	    log.error("### smfConnectionClose -- Connection::close() Exception Occurred ###" , e );
	}

        // DB all connection close
        //DbAccessInfo.closeAllDbConnections();

	log.info("### smfConnectionClose End ###");

    }

    private void setRs(ResultSet p_Rs) {
        log.info("### setRs Start ###");
        log.debug("### Parameter : p_Rs : " + p_Rs);
        this.rs = p_Rs;
        log.info("### setRs End ###");
    }

    private void setCon(Connection p_Con) {
	log.debug("### setCon Start ###");
	log.debug("### Parameter : p_Con : " + p_Con);
	this.con = p_Con;
	log.debug("### setCon End ###");
    }

    private void setStm(PreparedStatement p_Stm) {
	log.debug("### setStm Start ###");
	log.debug("### Parameter : p_Stm : " + p_Stm);
	this.stm = p_Stm;
	log.debug("### setStm End ###");
    }

    /**
     * ResultSetを取得する。
     * DBアクセス実施後に起動するとクエリ実行結果が取得される。
     */ 
    public static ResultSet getResultSet() {
        return rs;
    }

    private Connection getCon() {
	return( this.con );
    }

    private PreparedStatement getStm() {
 	return( this.stm );
    }

    /**
     * ユーザが指定したSQLクエリを実行し、結果を内部変数に保持する。
     * 実行するSQLクエリに制限はない。
     * @param 実行クエリ文(String)
     */
    public static void execDbAccess(String query) throws SQLException {

	String sqlState;

	log.debug("### execGetDbData Start ###");

        // generate SQL-Query
	try {
            stm = con.prepareStatement(query);
	} catch( SQLException e ) {
	    log.error("### Connection::prepareStatement Error (SQLException) ###" , e );

	    sqlState = e.getSQLState();
	    log.error("sqlState : " + sqlState);

            try {
                if(null != stm) {
                    log.debug("stm : " + stm);

                    stm.close();
                    stm = null;
                } else {
                    log.debug("### smfConnectionClose -- PreparedStatement::close() skip ###" );
                }
            } catch(Exception e1) {
                log.error("### smfConnectionClose -- PreparedStatement::close() Exception Occurred ###" , e1 );
            }

	}
	log.debug("### stm : " + stm);

        // クエリを実行
        execSmfQuery();

        // クエリ実行結果がnullだった場合
	if (null == rs) {
	    log.debug("ResultSet is Null");
	} else {
	    log.debug("ResultSet : " + rs);
	}

        log.debug("### execGetDbData End ###");
    }

}

