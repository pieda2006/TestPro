package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.RedirectAddressType;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RedirectInformation
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class RedirectInformation   {
  @JsonProperty("redirectEnabled")
  private Boolean redirectEnabled;

  @JsonProperty("redirectAddressType")
  private RedirectAddressType redirectAddressType;

  @JsonProperty("redirectServerAddress")
  private String redirectServerAddress;

  public RedirectInformation redirectEnabled(Boolean redirectEnabled) {
    this.redirectEnabled = redirectEnabled;
    return this;
  }

  /**
   * Indicates the redirect is enable.
   * @return redirectEnabled
  */
  @ApiModelProperty(value = "Indicates the redirect is enable.")


  public Boolean getRedirectEnabled() {
    return redirectEnabled;
  }

  public void setRedirectEnabled(Boolean redirectEnabled) {
    this.redirectEnabled = redirectEnabled;
  }

  public RedirectInformation redirectAddressType(RedirectAddressType redirectAddressType) {
    this.redirectAddressType = redirectAddressType;
    return this;
  }

  /**
   * Get redirectAddressType
   * @return redirectAddressType
  */
  @ApiModelProperty(value = "")

  @Valid

  public RedirectAddressType getRedirectAddressType() {
    return redirectAddressType;
  }

  public void setRedirectAddressType(RedirectAddressType redirectAddressType) {
    this.redirectAddressType = redirectAddressType;
  }

  public RedirectInformation redirectServerAddress(String redirectServerAddress) {
    this.redirectServerAddress = redirectServerAddress;
    return this;
  }

  /**
   * Indicates the address of the redirect server.
   * @return redirectServerAddress
  */
  @ApiModelProperty(value = "Indicates the address of the redirect server.")


  public String getRedirectServerAddress() {
    return redirectServerAddress;
  }

  public void setRedirectServerAddress(String redirectServerAddress) {
    this.redirectServerAddress = redirectServerAddress;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RedirectInformation redirectInformation = (RedirectInformation) o;
    return Objects.equals(this.redirectEnabled, redirectInformation.redirectEnabled) &&
        Objects.equals(this.redirectAddressType, redirectInformation.redirectAddressType) &&
        Objects.equals(this.redirectServerAddress, redirectInformation.redirectServerAddress);
  }

  @Override
  public int hashCode() {
    return Objects.hash(redirectEnabled, redirectAddressType, redirectServerAddress);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RedirectInformation {\n");
    
    sb.append("    redirectEnabled: ").append(toIndentedString(redirectEnabled)).append("\n");
    sb.append("    redirectAddressType: ").append(toIndentedString(redirectAddressType)).append("\n");
    sb.append("    redirectServerAddress: ").append(toIndentedString(redirectServerAddress)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

