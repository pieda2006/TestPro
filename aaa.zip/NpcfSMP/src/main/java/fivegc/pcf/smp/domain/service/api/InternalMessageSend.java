package fivegc.pcf.smp.domain.service.api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;


import java.util.concurrent.*;

//import akka.actor.ActorSystem;
//import akka.stream.ActorMaterializer;
//import akka.stream.ActorMaterializerSettings;
//import play.shaded.ahc.org.asynchttpclient.*;
//import play.libs.ws.ahc.*;

class InternalMessageSend extends MessageSendBase {

    private static final Logger log = LoggerFactory.getLogger(DataAcsessBase.class);

    public InternalMessageSend() {
    }
    void executeAction(JsonNode reqJson, ObjectNode ansJson, ObjectNode distJson, JsonNode actionJson, JsonNode operationJson) {


        String uri = null;
        String sendValue = null;

        uri = getStringFromJson(sendUri, uriKind, reqJson, actionJson, distJson, ansJson, operationJson);
        if(!value.toString().equals("")){
            sendValue = getStringFromJson(value, valueKind, reqJson, actionJson, distJson, ansJson, operationJson);
        } else {
           sendValue = "";
        }

        try {
            ServiceControl servicectl = ServiceControl.getInstance();
            ObjectMapper objectmapper = new ObjectMapper();
            JsonNode jsondata = objectmapper.readTree(sendValue);
            JsonNode jsonRes = servicectl.decideAction(uri, jsondata);
            if(jsonRes instanceof ObjectNode){
                setResultObject(jsonRes, dataKind, result, distJson, ansJson);
            }
        } catch (Exception e) {
            //Error Action
            log.error("### InternalMessageSend Error End (Exception) ###",e);
        }
    }
}
