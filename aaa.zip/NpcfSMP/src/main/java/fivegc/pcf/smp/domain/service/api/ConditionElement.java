package fivegc.pcf.smp.domain.service.api;

import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Map;
import java.util.Iterator;

class ConditionElement  extends EvaluateBase {
  /*** ロガー定義 ***/
  private static final Logger log = LoggerFactory.getLogger(ConditionElement.class);
  /*** 取得対象バッファ ***/
  public final static int REQUEST = 0;
  public final static int CONDITION = 1;
  public final static int OPERATION = 4;
  public final static int RESULT = 5;
  /*** 固有パラメータ ***/
  /*** 取得対象のJsonパス ***/
  private JsonNode paramName = null;
  /*** 取得対象を取得するバッファ ***/
  private int paramKind = 0; 
  /*** 比較対象のJsonパス ***/
  private JsonNode condJson = null;
  /*** 比較対象を取得するバッファ ***/
  private int condKind = 0; 
  /*** 取得対象のJsonオブジェクトの深さ ***/
  private int depth = 0;
  /*** Resultを扱う場合のOperation ***/
  private EvaluateBase evalObj = null;

 /**
  * Operation動作用の設定の保持。
  * @author  ikeda_tss
  * @version sprint03
  * @since sprint03
  * @param JsonNode operationjson オペレーション実行時に必要なJsonデータ
  * @return 無
  **/
  public void setParameterFromJson(JsonNode operationjson) {
    if(operationjson != null){
      paramName = operationjson.path("ParamName");
      condJson = operationjson.path("ConditionPath");
      paramKind = operationjson.path("ParamKind").asInt();
      condKind = operationjson.path("CondKind").asInt();
      depth = operationjson.path("Depth").asInt();
    }
    else {
      log.error("operationjson is null");
    }
  }

 /**
  * 条件判定を実施する。Inputに渡されたJson文から条件に合致するものを抜き出す。
  * @author  ikeda_tss
  * @version sprint03
  * @since sprint03
  * @param JsonNode reqJson 受信信号のJson文
  * @param JsonNode conditionJson プラン情報に設定されたJson文
  * @param JsonNode operationJson Conditionに設定されたJson文
  * @return ResultInfo 条件判定結果
  */
  public ResultInfo evaluateCondition(JsonNode reqJson, JsonNode conditionJson, JsonNode operationJson){
    JsonNode findJson = null;
    JsonNode resJson =null;
    ResultInfo evalResult =null;
    ResultInfo resultinfo = new ResultInfo();
    resultinfo.setResultType(ResultInfo.JSONTYPE);
    if(paramKind == RESULT || condKind == RESULT) {
      evalObj = evaluateObj.get(0);
      evalResult = evalObj.evaluateCondition(reqJson, conditionJson, operationJson);
      if(evalResult.getResultType() != ResultInfo.JSONTYPE){
        log.error("ResultInfo Type is not JSON or Null");
        resultinfo.setResultType(ResultInfo.NONTYPE);
        return resultinfo;
      }
    }
    if(evalResult != null){
      findJson = selectOperationBuffer(reqJson, conditionJson, operationJson, evalResult.getJsonNode(), paramKind);
      resJson = selectOperationBuffer(reqJson, conditionJson, operationJson, evalResult.getJsonNode(), condKind);
    } else {
      findJson = selectOperationBuffer(reqJson, conditionJson, operationJson, null, paramKind);
      resJson = selectOperationBuffer(reqJson, conditionJson, operationJson, null, condKind);
    }
    for(int count = 0; condJson.has(count); count++){
      resJson = resJson.path(condJson.get(count).asText());
    }
    getCondMatchJson(findJson, resJson, 0,resultinfo);
    return resultinfo;
  }


 /**
  * 処理対象のJsonオブジェクトの選択を行う。
  * @author  ikeda_tss
  * @version sprint03
  * @since sprint03
  * @param JsonNode reqJson 受信信号のJson文
  * @param JsonNode conditionJson プラン情報に設定されたJson文
  * @param JsonNode operationJson Conditionに設定されたJson文
  * @param JsonNode resultJson Operation結果のJson文
  * @return JsonNode 選択されたJsonNode
  */
  public JsonNode selectOperationBuffer(JsonNode reqJson, JsonNode conditionJson, JsonNode operationJson, JsonNode resultJson, int kind){
    if(kind == REQUEST) {
      return reqJson;
    } else if(kind == CONDITION) {
      return conditionJson;
    } else if(kind == OPERATION) {
      return operationJson;
    } else {
      return resultJson;
    }
  }

 /**
  * 条件に一致するJsonを取得する。
  * @author  ikeda_tss
  * @version sprint03
  * @since sprint03
  * @param JsonNode findJson 処理対象のJson
  * @param JsonNode resJson 比較対象のJson
  * @param int currentdepth 現在処理中の深さ
  * @param int pathcount 処理中のパスの位置
  * @return JsonNode 選択されたJsonNode
  */
  public boolean getCondMatchJson(JsonNode findJson, JsonNode resJson,  int currentdepth, ResultInfo resultinfo){
    boolean boolval = false;
    int nextdepth = currentdepth + 1;
    boolean nextpathbool = paramName.has(nextdepth);
    String paramString = paramName.get(currentdepth).asText();

    if(paramString.equals("*")){
      Map.Entry<String,JsonNode> jsonmap = null;
      Iterator<Map.Entry<String,JsonNode>> jsonIte = findJson.fields();
      while (jsonIte.hasNext()) {
        jsonmap = jsonIte.next();
        if(nextpathbool){
          boolval = getCondMatchJson(jsonmap.getValue(), resJson, nextdepth, resultinfo);
        } else {
          boolval = jsonmap.getValue().equals(resJson);
        }
        if(boolval){
          if(currentdepth == depth){
            resultinfo.setJsonNode(jsonmap.getValue());
            return boolval;
          } else {
            return boolval;
          }
        }
      }
      return false;
    } else {
      if(nextpathbool){
        boolval = getCondMatchJson(findJson.path(paramString), resJson, nextdepth, resultinfo);
      } else {
        boolval = findJson.path(paramString).equals(resJson);
      }
      if(boolval){
        if(currentdepth == depth){
          resultinfo.setJsonNode(findJson.path(paramString));
          return boolval;
        } else {
          return boolval;
        }
      } else {
        return false;
      }
    }
  }
}
