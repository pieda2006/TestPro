package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import fivegc.pcf.smp.domain.model.AccNetChId;
import fivegc.pcf.smp.domain.model.AccNetChargingAddress;
import fivegc.pcf.smp.domain.model.QosFlowUsage;
import fivegc.pcf.smp.domain.model.ServingNfIdentity;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataServingNetwork;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataSliceInfo;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataSubsDefQos;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataSubsSessAmbr;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataTraceReq;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataUserLocationInfo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyContextData
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyContextData   {
  @JsonProperty("accNetChId")
  private AccNetChId accNetChId = null;

  @JsonProperty("chargEntityAddr")
  private AccNetChargingAddress chargEntityAddr = null;

  @JsonProperty("gpsi")
  private String gpsi;

  @JsonProperty("supi")
  private String supi;

  @JsonProperty("interGrpIds")
  @Valid
  private List<String> interGrpIds = null;

  @JsonProperty("pduSessionId")
  private Integer pduSessionId;

  /**
   * Gets or Sets pduSessionType
   */
  public enum PduSessionTypeEnum {
    IPV4("IPV4"),
    
    IPV6("IPV6"),
    
    IPV4V6("IPV4V6"),
    
    UNSTRUCTURED("UNSTRUCTURED"),
    
    ETHERNET("ETHERNET");

    private String value;

    PduSessionTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static PduSessionTypeEnum fromValue(String value) {
      for (PduSessionTypeEnum b : PduSessionTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("pduSessionType")
  private PduSessionTypeEnum pduSessionType;

  @JsonProperty("chargingcharacteristics")
  private String chargingcharacteristics;

  @JsonProperty("dnn")
  private String dnn;

  @JsonProperty("notificationUri")
  private String notificationUri;

  /**
   * Gets or Sets accessType
   */
  public enum AccessTypeEnum {
    _3GPP_ACCESS("3GPP_ACCESS"),
    
    NON_3GPP_ACCESS("NON_3GPP_ACCESS");

    private String value;

    AccessTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static AccessTypeEnum fromValue(String value) {
      for (AccessTypeEnum b : AccessTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("accessType")
  private AccessTypeEnum accessType;

  /**
   * Gets or Sets ratType
   */
  public enum RatTypeEnum {
    NR("NR"),
    
    EUTRA("EUTRA"),
    
    WLAN("WLAN"),
    
    VIRTUAL("VIRTUAL"),
    
    NBIOT("NBIOT");

    private String value;

    RatTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static RatTypeEnum fromValue(String value) {
      for (RatTypeEnum b : RatTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("ratType")
  private RatTypeEnum ratType;

  @JsonProperty("servingNetwork")
  private SmPolicyContextDataServingNetwork servingNetwork = null;

  @JsonProperty("userLocationInfo")
  private SmPolicyContextDataUserLocationInfo userLocationInfo = null;

  @JsonProperty("ueTimeZone")
  private String ueTimeZone;

  @JsonProperty("pei")
  private String pei;

  @JsonProperty("ipv4Address")
  private String ipv4Address;

  @JsonProperty("ipv6AddressPrefix")
  private String ipv6AddressPrefix;

  @JsonProperty("ipDomain")
  private String ipDomain;

  @JsonProperty("subsSessAmbr")
  private SmPolicyContextDataSubsSessAmbr subsSessAmbr = null;

  @JsonProperty("authProfIndex")
  private String authProfIndex;

  @JsonProperty("subsDefQos")
  private SmPolicyContextDataSubsDefQos subsDefQos = null;

  @JsonProperty("numOfPackFilter")
  private Integer numOfPackFilter;

  @JsonProperty("online")
  private Boolean online;

  @JsonProperty("offline")
  private Boolean offline;

  @JsonProperty("3gppPsDataOffStatus")
  private Boolean _3gppPsDataOffStatus;

  @JsonProperty("refQosIndication")
  private Boolean refQosIndication;

  @JsonProperty("traceReq")
  private JsonNullable<SmPolicyContextDataTraceReq> traceReq = JsonNullable.undefined();

  @JsonProperty("sliceInfo")
  private SmPolicyContextDataSliceInfo sliceInfo = null;

  @JsonProperty("qosFlowUsage")
  private QosFlowUsage qosFlowUsage;

  @JsonProperty("servNfId")
  private ServingNfIdentity servNfId = null;

  @JsonProperty("suppFeat")
  private String suppFeat;

  @JsonProperty("smfId")
  private UUID smfId;

  @JsonProperty("recoveryTime")
  private OffsetDateTime recoveryTime;

  public SmPolicyContextData accNetChId(AccNetChId accNetChId) {
    this.accNetChId = accNetChId;
    return this;
  }

  /**
   * Get accNetChId
   * @return accNetChId
  */
  @ApiModelProperty(value = "")

  @Valid

  public AccNetChId getAccNetChId() {
    return accNetChId;
  }

  public void setAccNetChId(AccNetChId accNetChId) {
    this.accNetChId = accNetChId;
  }

  public SmPolicyContextData chargEntityAddr(AccNetChargingAddress chargEntityAddr) {
    this.chargEntityAddr = chargEntityAddr;
    return this;
  }

  /**
   * Get chargEntityAddr
   * @return chargEntityAddr
  */
  @ApiModelProperty(value = "")

  @Valid

  public AccNetChargingAddress getChargEntityAddr() {
    return chargEntityAddr;
  }

  public void setChargEntityAddr(AccNetChargingAddress chargEntityAddr) {
    this.chargEntityAddr = chargEntityAddr;
  }

  public SmPolicyContextData gpsi(String gpsi) {
    this.gpsi = gpsi;
    return this;
  }

  /**
   * Get gpsi
   * @return gpsi
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^(msisdn-[0-9]{5,15}|extid-[^@]+@[^@]+|.+)$") 
  public String getGpsi() {
    return gpsi;
  }

  public void setGpsi(String gpsi) {
    this.gpsi = gpsi;
  }

  public SmPolicyContextData supi(String supi) {
    this.supi = supi;
    return this;
  }

  /**
   * Get supi
   * @return supi
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Pattern(regexp="^(imsi-[0-9]{5,15}|nai-.+|.+)$") 
  public String getSupi() {
    return supi;
  }

  public void setSupi(String supi) {
    this.supi = supi;
  }

  public SmPolicyContextData interGrpIds(List<String> interGrpIds) {
    this.interGrpIds = interGrpIds;
    return this;
  }

  public SmPolicyContextData addInterGrpIdsItem(String interGrpIdsItem) {
    if (this.interGrpIds == null) {
      this.interGrpIds = new ArrayList<>();
    }
    this.interGrpIds.add(interGrpIdsItem);
    return this;
  }

  /**
   * Get interGrpIds
   * @return interGrpIds
  */
  @ApiModelProperty(value = "")

@Size(min=1) 
  public List<String> getInterGrpIds() {
    return interGrpIds;
  }

  public void setInterGrpIds(List<String> interGrpIds) {
    this.interGrpIds = interGrpIds;
  }

  public SmPolicyContextData pduSessionId(Integer pduSessionId) {
    this.pduSessionId = pduSessionId;
    return this;
  }

  /**
   * Get pduSessionId
   * minimum: 0
   * maximum: 255
   * @return pduSessionId
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Min(0) @Max(255) 
  public Integer getPduSessionId() {
    return pduSessionId;
  }

  public void setPduSessionId(Integer pduSessionId) {
    this.pduSessionId = pduSessionId;
  }

  public SmPolicyContextData pduSessionType(PduSessionTypeEnum pduSessionType) {
    this.pduSessionType = pduSessionType;
    return this;
  }

  /**
   * Get pduSessionType
   * @return pduSessionType
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public PduSessionTypeEnum getPduSessionType() {
    return pduSessionType;
  }

  public void setPduSessionType(PduSessionTypeEnum pduSessionType) {
    this.pduSessionType = pduSessionType;
  }

  public SmPolicyContextData chargingcharacteristics(String chargingcharacteristics) {
    this.chargingcharacteristics = chargingcharacteristics;
    return this;
  }

  /**
   * Get chargingcharacteristics
   * @return chargingcharacteristics
  */
  @ApiModelProperty(value = "")


  public String getChargingcharacteristics() {
    return chargingcharacteristics;
  }

  public void setChargingcharacteristics(String chargingcharacteristics) {
    this.chargingcharacteristics = chargingcharacteristics;
  }

  public SmPolicyContextData dnn(String dnn) {
    this.dnn = dnn;
    return this;
  }

  /**
   * Get dnn
   * @return dnn
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getDnn() {
    return dnn;
  }

  public void setDnn(String dnn) {
    this.dnn = dnn;
  }

  public SmPolicyContextData notificationUri(String notificationUri) {
    this.notificationUri = notificationUri;
    return this;
  }

  /**
   * Get notificationUri
   * @return notificationUri
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getNotificationUri() {
    return notificationUri;
  }

  public void setNotificationUri(String notificationUri) {
    this.notificationUri = notificationUri;
  }

  public SmPolicyContextData accessType(AccessTypeEnum accessType) {
    this.accessType = accessType;
    return this;
  }

  /**
   * Get accessType
   * @return accessType
  */
  @ApiModelProperty(value = "")


  public AccessTypeEnum getAccessType() {
    return accessType;
  }

  public void setAccessType(AccessTypeEnum accessType) {
    this.accessType = accessType;
  }

  public SmPolicyContextData ratType(RatTypeEnum ratType) {
    this.ratType = ratType;
    return this;
  }

  /**
   * Get ratType
   * @return ratType
  */
  @ApiModelProperty(value = "")


  public RatTypeEnum getRatType() {
    return ratType;
  }

  public void setRatType(RatTypeEnum ratType) {
    this.ratType = ratType;
  }

  public SmPolicyContextData servingNetwork(SmPolicyContextDataServingNetwork servingNetwork) {
    this.servingNetwork = servingNetwork;
    return this;
  }

  /**
   * Get servingNetwork
   * @return servingNetwork
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataServingNetwork getServingNetwork() {
    return servingNetwork;
  }

  public void setServingNetwork(SmPolicyContextDataServingNetwork servingNetwork) {
    this.servingNetwork = servingNetwork;
  }

  public SmPolicyContextData userLocationInfo(SmPolicyContextDataUserLocationInfo userLocationInfo) {
    this.userLocationInfo = userLocationInfo;
    return this;
  }

  /**
   * Get userLocationInfo
   * @return userLocationInfo
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataUserLocationInfo getUserLocationInfo() {
    return userLocationInfo;
  }

  public void setUserLocationInfo(SmPolicyContextDataUserLocationInfo userLocationInfo) {
    this.userLocationInfo = userLocationInfo;
  }

  public SmPolicyContextData ueTimeZone(String ueTimeZone) {
    this.ueTimeZone = ueTimeZone;
    return this;
  }

  /**
   * Get ueTimeZone
   * @return ueTimeZone
  */
  @ApiModelProperty(value = "")


  public String getUeTimeZone() {
    return ueTimeZone;
  }

  public void setUeTimeZone(String ueTimeZone) {
    this.ueTimeZone = ueTimeZone;
  }

  public SmPolicyContextData pei(String pei) {
    this.pei = pei;
    return this;
  }

  /**
   * Get pei
   * @return pei
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^(imei-[0-9]{15}|imeisv-[0-9]{16}|.+)$") 
  public String getPei() {
    return pei;
  }

  public void setPei(String pei) {
    this.pei = pei;
  }

  public SmPolicyContextData ipv4Address(String ipv4Address) {
    this.ipv4Address = ipv4Address;
    return this;
  }

  /**
   * Get ipv4Address
   * @return ipv4Address
  */
  @ApiModelProperty(example = "198.51.100.1", value = "")

@Pattern(regexp="^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$") 
  public String getIpv4Address() {
    return ipv4Address;
  }

  public void setIpv4Address(String ipv4Address) {
    this.ipv4Address = ipv4Address;
  }

  public SmPolicyContextData ipv6AddressPrefix(String ipv6AddressPrefix) {
    this.ipv6AddressPrefix = ipv6AddressPrefix;
    return this;
  }

  /**
   * Get ipv6AddressPrefix
   * @return ipv6AddressPrefix
  */
  @ApiModelProperty(example = "2001:db8:abcd:12::0/64", value = "")


  public String getIpv6AddressPrefix() {
    return ipv6AddressPrefix;
  }

  public void setIpv6AddressPrefix(String ipv6AddressPrefix) {
    this.ipv6AddressPrefix = ipv6AddressPrefix;
  }

  public SmPolicyContextData ipDomain(String ipDomain) {
    this.ipDomain = ipDomain;
    return this;
  }

  /**
   * Indicates the IPv4 address domain
   * @return ipDomain
  */
  @ApiModelProperty(value = "Indicates the IPv4 address domain")


  public String getIpDomain() {
    return ipDomain;
  }

  public void setIpDomain(String ipDomain) {
    this.ipDomain = ipDomain;
  }

  public SmPolicyContextData subsSessAmbr(SmPolicyContextDataSubsSessAmbr subsSessAmbr) {
    this.subsSessAmbr = subsSessAmbr;
    return this;
  }

  /**
   * Get subsSessAmbr
   * @return subsSessAmbr
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataSubsSessAmbr getSubsSessAmbr() {
    return subsSessAmbr;
  }

  public void setSubsSessAmbr(SmPolicyContextDataSubsSessAmbr subsSessAmbr) {
    this.subsSessAmbr = subsSessAmbr;
  }

  public SmPolicyContextData authProfIndex(String authProfIndex) {
    this.authProfIndex = authProfIndex;
    return this;
  }

  /**
   * Indicates the DN-AAA authorization profile index
   * @return authProfIndex
  */
  @ApiModelProperty(value = "Indicates the DN-AAA authorization profile index")


  public String getAuthProfIndex() {
    return authProfIndex;
  }

  public void setAuthProfIndex(String authProfIndex) {
    this.authProfIndex = authProfIndex;
  }

  public SmPolicyContextData subsDefQos(SmPolicyContextDataSubsDefQos subsDefQos) {
    this.subsDefQos = subsDefQos;
    return this;
  }

  /**
   * Get subsDefQos
   * @return subsDefQos
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataSubsDefQos getSubsDefQos() {
    return subsDefQos;
  }

  public void setSubsDefQos(SmPolicyContextDataSubsDefQos subsDefQos) {
    this.subsDefQos = subsDefQos;
  }

  public SmPolicyContextData numOfPackFilter(Integer numOfPackFilter) {
    this.numOfPackFilter = numOfPackFilter;
    return this;
  }

  /**
   * Contains the number of supported packet filter for signalled QoS rules.
   * @return numOfPackFilter
  */
  @ApiModelProperty(value = "Contains the number of supported packet filter for signalled QoS rules.")


  public Integer getNumOfPackFilter() {
    return numOfPackFilter;
  }

  public void setNumOfPackFilter(Integer numOfPackFilter) {
    this.numOfPackFilter = numOfPackFilter;
  }

  public SmPolicyContextData online(Boolean online) {
    this.online = online;
    return this;
  }

  /**
   * If it is included and set to true, the online charging is applied to the PDU session.
   * @return online
  */
  @ApiModelProperty(value = "If it is included and set to true, the online charging is applied to the PDU session.")


  public Boolean getOnline() {
    return online;
  }

  public void setOnline(Boolean online) {
    this.online = online;
  }

  public SmPolicyContextData offline(Boolean offline) {
    this.offline = offline;
    return this;
  }

  /**
   * If it is included and set to true, the offline charging is applied to the PDU session.
   * @return offline
  */
  @ApiModelProperty(value = "If it is included and set to true, the offline charging is applied to the PDU session.")


  public Boolean getOffline() {
    return offline;
  }

  public void setOffline(Boolean offline) {
    this.offline = offline;
  }

  public SmPolicyContextData _3gppPsDataOffStatus(Boolean _3gppPsDataOffStatus) {
    this._3gppPsDataOffStatus = _3gppPsDataOffStatus;
    return this;
  }

  /**
   * If it is included and set to true, the 3GPP PS Data Off is activated by the UE.
   * @return _3gppPsDataOffStatus
  */
  @ApiModelProperty(value = "If it is included and set to true, the 3GPP PS Data Off is activated by the UE.")


  public Boolean get3gppPsDataOffStatus() {
    return _3gppPsDataOffStatus;
  }

  public void set3gppPsDataOffStatus(Boolean _3gppPsDataOffStatus) {
    this._3gppPsDataOffStatus = _3gppPsDataOffStatus;
  }

  public SmPolicyContextData refQosIndication(Boolean refQosIndication) {
    this.refQosIndication = refQosIndication;
    return this;
  }

  /**
   * If it is included and set to true, the reflective QoS is supported by the UE.
   * @return refQosIndication
  */
  @ApiModelProperty(value = "If it is included and set to true, the reflective QoS is supported by the UE.")


  public Boolean getRefQosIndication() {
    return refQosIndication;
  }

  public void setRefQosIndication(Boolean refQosIndication) {
    this.refQosIndication = refQosIndication;
  }

  public SmPolicyContextData traceReq(SmPolicyContextDataTraceReq traceReq) {
    this.traceReq = JsonNullable.of(traceReq);
    return this;
  }

  /**
   * Get traceReq
   * @return traceReq
  */
  @ApiModelProperty(value = "")

  @Valid

  public JsonNullable<SmPolicyContextDataTraceReq> getTraceReq() {
    return traceReq;
  }

  public void setTraceReq(JsonNullable<SmPolicyContextDataTraceReq> traceReq) {
    this.traceReq = traceReq;
  }

  public SmPolicyContextData sliceInfo(SmPolicyContextDataSliceInfo sliceInfo) {
    this.sliceInfo = sliceInfo;
    return this;
  }

  /**
   * Get sliceInfo
   * @return sliceInfo
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public SmPolicyContextDataSliceInfo getSliceInfo() {
    return sliceInfo;
  }

  public void setSliceInfo(SmPolicyContextDataSliceInfo sliceInfo) {
    this.sliceInfo = sliceInfo;
  }

  public SmPolicyContextData qosFlowUsage(QosFlowUsage qosFlowUsage) {
    this.qosFlowUsage = qosFlowUsage;
    return this;
  }

  /**
   * Get qosFlowUsage
   * @return qosFlowUsage
  */
  @ApiModelProperty(value = "")

  @Valid

  public QosFlowUsage getQosFlowUsage() {
    return qosFlowUsage;
  }

  public void setQosFlowUsage(QosFlowUsage qosFlowUsage) {
    this.qosFlowUsage = qosFlowUsage;
  }

  public SmPolicyContextData servNfId(ServingNfIdentity servNfId) {
    this.servNfId = servNfId;
    return this;
  }

  /**
   * Get servNfId
   * @return servNfId
  */
  @ApiModelProperty(value = "")

  @Valid

  public ServingNfIdentity getServNfId() {
    return servNfId;
  }

  public void setServNfId(ServingNfIdentity servNfId) {
    this.servNfId = servNfId;
  }

  public SmPolicyContextData suppFeat(String suppFeat) {
    this.suppFeat = suppFeat;
    return this;
  }

  /**
   * Get suppFeat
   * @return suppFeat
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^[A-Fa-f0-9]*$") 
  public String getSuppFeat() {
    return suppFeat;
  }

  public void setSuppFeat(String suppFeat) {
    this.suppFeat = suppFeat;
  }

  public SmPolicyContextData smfId(UUID smfId) {
    this.smfId = smfId;
    return this;
  }

  /**
   * Get smfId
   * @return smfId
  */
  @ApiModelProperty(value = "")

  @Valid

  public UUID getSmfId() {
    return smfId;
  }

  public void setSmfId(UUID smfId) {
    this.smfId = smfId;
  }

  public SmPolicyContextData recoveryTime(OffsetDateTime recoveryTime) {
    this.recoveryTime = recoveryTime;
    return this;
  }

  /**
   * Get recoveryTime
   * @return recoveryTime
  */
  @ApiModelProperty(value = "")

  @Valid

  public OffsetDateTime getRecoveryTime() {
    return recoveryTime;
  }

  public void setRecoveryTime(OffsetDateTime recoveryTime) {
    this.recoveryTime = recoveryTime;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyContextData smPolicyContextData = (SmPolicyContextData) o;
    return Objects.equals(this.accNetChId, smPolicyContextData.accNetChId) &&
        Objects.equals(this.chargEntityAddr, smPolicyContextData.chargEntityAddr) &&
        Objects.equals(this.gpsi, smPolicyContextData.gpsi) &&
        Objects.equals(this.supi, smPolicyContextData.supi) &&
        Objects.equals(this.interGrpIds, smPolicyContextData.interGrpIds) &&
        Objects.equals(this.pduSessionId, smPolicyContextData.pduSessionId) &&
        Objects.equals(this.pduSessionType, smPolicyContextData.pduSessionType) &&
        Objects.equals(this.chargingcharacteristics, smPolicyContextData.chargingcharacteristics) &&
        Objects.equals(this.dnn, smPolicyContextData.dnn) &&
        Objects.equals(this.notificationUri, smPolicyContextData.notificationUri) &&
        Objects.equals(this.accessType, smPolicyContextData.accessType) &&
        Objects.equals(this.ratType, smPolicyContextData.ratType) &&
        Objects.equals(this.servingNetwork, smPolicyContextData.servingNetwork) &&
        Objects.equals(this.userLocationInfo, smPolicyContextData.userLocationInfo) &&
        Objects.equals(this.ueTimeZone, smPolicyContextData.ueTimeZone) &&
        Objects.equals(this.pei, smPolicyContextData.pei) &&
        Objects.equals(this.ipv4Address, smPolicyContextData.ipv4Address) &&
        Objects.equals(this.ipv6AddressPrefix, smPolicyContextData.ipv6AddressPrefix) &&
        Objects.equals(this.ipDomain, smPolicyContextData.ipDomain) &&
        Objects.equals(this.subsSessAmbr, smPolicyContextData.subsSessAmbr) &&
        Objects.equals(this.authProfIndex, smPolicyContextData.authProfIndex) &&
        Objects.equals(this.subsDefQos, smPolicyContextData.subsDefQos) &&
        Objects.equals(this.numOfPackFilter, smPolicyContextData.numOfPackFilter) &&
        Objects.equals(this.online, smPolicyContextData.online) &&
        Objects.equals(this.offline, smPolicyContextData.offline) &&
        Objects.equals(this._3gppPsDataOffStatus, smPolicyContextData._3gppPsDataOffStatus) &&
        Objects.equals(this.refQosIndication, smPolicyContextData.refQosIndication) &&
        Objects.equals(this.traceReq, smPolicyContextData.traceReq) &&
        Objects.equals(this.sliceInfo, smPolicyContextData.sliceInfo) &&
        Objects.equals(this.qosFlowUsage, smPolicyContextData.qosFlowUsage) &&
        Objects.equals(this.servNfId, smPolicyContextData.servNfId) &&
        Objects.equals(this.suppFeat, smPolicyContextData.suppFeat) &&
        Objects.equals(this.smfId, smPolicyContextData.smfId) &&
        Objects.equals(this.recoveryTime, smPolicyContextData.recoveryTime);
  }

  @Override
  public int hashCode() {
    return Objects.hash(accNetChId, chargEntityAddr, gpsi, supi, interGrpIds, pduSessionId, pduSessionType, chargingcharacteristics, dnn, notificationUri, accessType, ratType, servingNetwork, userLocationInfo, ueTimeZone, pei, ipv4Address, ipv6AddressPrefix, ipDomain, subsSessAmbr, authProfIndex, subsDefQos, numOfPackFilter, online, offline, _3gppPsDataOffStatus, refQosIndication, traceReq, sliceInfo, qosFlowUsage, servNfId, suppFeat, smfId, recoveryTime);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyContextData {\n");
    
    sb.append("    accNetChId: ").append(toIndentedString(accNetChId)).append("\n");
    sb.append("    chargEntityAddr: ").append(toIndentedString(chargEntityAddr)).append("\n");
    sb.append("    gpsi: ").append(toIndentedString(gpsi)).append("\n");
    sb.append("    supi: ").append(toIndentedString(supi)).append("\n");
    sb.append("    interGrpIds: ").append(toIndentedString(interGrpIds)).append("\n");
    sb.append("    pduSessionId: ").append(toIndentedString(pduSessionId)).append("\n");
    sb.append("    pduSessionType: ").append(toIndentedString(pduSessionType)).append("\n");
    sb.append("    chargingcharacteristics: ").append(toIndentedString(chargingcharacteristics)).append("\n");
    sb.append("    dnn: ").append(toIndentedString(dnn)).append("\n");
    sb.append("    notificationUri: ").append(toIndentedString(notificationUri)).append("\n");
    sb.append("    accessType: ").append(toIndentedString(accessType)).append("\n");
    sb.append("    ratType: ").append(toIndentedString(ratType)).append("\n");
    sb.append("    servingNetwork: ").append(toIndentedString(servingNetwork)).append("\n");
    sb.append("    userLocationInfo: ").append(toIndentedString(userLocationInfo)).append("\n");
    sb.append("    ueTimeZone: ").append(toIndentedString(ueTimeZone)).append("\n");
    sb.append("    pei: ").append(toIndentedString(pei)).append("\n");
    sb.append("    ipv4Address: ").append(toIndentedString(ipv4Address)).append("\n");
    sb.append("    ipv6AddressPrefix: ").append(toIndentedString(ipv6AddressPrefix)).append("\n");
    sb.append("    ipDomain: ").append(toIndentedString(ipDomain)).append("\n");
    sb.append("    subsSessAmbr: ").append(toIndentedString(subsSessAmbr)).append("\n");
    sb.append("    authProfIndex: ").append(toIndentedString(authProfIndex)).append("\n");
    sb.append("    subsDefQos: ").append(toIndentedString(subsDefQos)).append("\n");
    sb.append("    numOfPackFilter: ").append(toIndentedString(numOfPackFilter)).append("\n");
    sb.append("    online: ").append(toIndentedString(online)).append("\n");
    sb.append("    offline: ").append(toIndentedString(offline)).append("\n");
    sb.append("    _3gppPsDataOffStatus: ").append(toIndentedString(_3gppPsDataOffStatus)).append("\n");
    sb.append("    refQosIndication: ").append(toIndentedString(refQosIndication)).append("\n");
    sb.append("    traceReq: ").append(toIndentedString(traceReq)).append("\n");
    sb.append("    sliceInfo: ").append(toIndentedString(sliceInfo)).append("\n");
    sb.append("    qosFlowUsage: ").append(toIndentedString(qosFlowUsage)).append("\n");
    sb.append("    servNfId: ").append(toIndentedString(servNfId)).append("\n");
    sb.append("    suppFeat: ").append(toIndentedString(suppFeat)).append("\n");
    sb.append("    smfId: ").append(toIndentedString(smfId)).append("\n");
    sb.append("    recoveryTime: ").append(toIndentedString(recoveryTime)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

