package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import io.swagger.annotations.ApiModel;
import com.fasterxml.jackson.annotation.JsonValue;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Possible values are - NO_INFORMATION: Indicate that no information about the AF signalling protocol is being provided.  - SIP: Indicate that the signalling protocol is Session Initiation Protocol. 
 */
public enum AfSigProtocol {
  
  NO_INFORMATION("NO_INFORMATION"),
  
  SIP("SIP");

  private String value;

  AfSigProtocol(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static AfSigProtocol fromValue(String value) {
    for (AfSigProtocol b : AfSigProtocol.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    return null;
  }
}

