package fivegc.pcf.smp.domain.service.api;

import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class EvaluateElement extends EvaluateBase {

    private static final Logger log = LoggerFactory.getLogger(EvaluateElement.class);

    private JsonNode paramName;
    private int paramType;

    public final static int INTPARM = 0;
    public final static int STRINGPARM = 1;

    public final static int REQUEST = 4;
    public final static int CONDTION = 5;
    public final static int OPERATION = 6;
    public final static int RESULT = 7;

    public EvaluateElement(){
    }
    public ResultInfo evaluateCondition(JsonNode reqJson, JsonNode conditionJson, JsonNode operationJson){
        ResultInfo resultinfo = new ResultInfo();

        JsonNode findJson = null;
        if(operationType == REQUEST){
            findJson = reqJson;
        } else if(operationType == CONDTION){
            findJson = conditionJson;
        } else if(operationType == OPERATION){
            findJson = operationJson;
        } else if(operationType == RESULT){
           if(evaluateObj.size() == 1){
             ResultInfo result = evaluateObj.get(0).evaluateCondition(reqJson, conditionJson, operationJson);
             findJson = result.getJsonNode();
           }
        }

        if(findJson == null){
          log.error("findJson is null");
          return resultinfo;
        }

        for(int count = 0; paramName.has(count); count++){
            findJson = findJson.path(paramName.get(count).asText());
        }

        if(findJson.isMissingNode()){
            resultinfo.setResultType(ResultInfo.NONTYPE);
            return resultinfo; 
        }

        if(paramType == INTPARM){
            resultinfo.setResultType(ResultInfo.INTTYPE);
            resultinfo.setIntResult(findJson.asInt());

        } else {
            resultinfo.setResultType(ResultInfo.STRINGTYPE);
            resultinfo.setStringResult(findJson.asText());
        }
        return resultinfo;
    }

    public void setParameterFromJson(JsonNode operationjson){
        if(operationjson != null) {
            setParamName(operationjson.path("ParamName"));
            setParamType(operationjson.path("ParamType").asInt());
        } else {
            log.error("operationjson is null");
        }
    }

    public void setParamName(JsonNode input){
        paramName = input;
    }
    public void setParamType(int type){
        paramType = type;
    }
}
