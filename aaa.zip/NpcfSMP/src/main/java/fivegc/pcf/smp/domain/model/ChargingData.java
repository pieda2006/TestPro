package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.MeteringMethod;
import fivegc.pcf.smp.domain.model.ReportingLevel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ChargingData
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class ChargingData   {
  @JsonProperty("chgId")
  private String chgId;

  @JsonProperty("meteringMethod")
  private JsonNullable<MeteringMethod> meteringMethod = JsonNullable.undefined();

  @JsonProperty("offline")
  private Boolean offline;

  @JsonProperty("online")
  private Boolean online;

  @JsonProperty("sdfHandl")
  private Boolean sdfHandl;

  @JsonProperty("ratingGroup")
  private Integer ratingGroup;

  @JsonProperty("reportingLevel")
  private JsonNullable<ReportingLevel> reportingLevel = JsonNullable.undefined();

  @JsonProperty("serviceId")
  private Integer serviceId;

  @JsonProperty("sponsorId")
  private String sponsorId;

  @JsonProperty("appSvcProvId")
  private String appSvcProvId;

  @JsonProperty("afChargingIdentifier")
  private Integer afChargingIdentifier;

  public ChargingData chgId(String chgId) {
    this.chgId = chgId;
    return this;
  }

  /**
   * Univocally identifies the charging control policy data within a PDU session.
   * @return chgId
  */
  @ApiModelProperty(required = true, value = "Univocally identifies the charging control policy data within a PDU session.")
  @NotNull


  public String getChgId() {
    return chgId;
  }

  public void setChgId(String chgId) {
    this.chgId = chgId;
  }

  public ChargingData meteringMethod(MeteringMethod meteringMethod) {
    this.meteringMethod = JsonNullable.of(meteringMethod);
    return this;
  }

  /**
   * Get meteringMethod
   * @return meteringMethod
  */
  @ApiModelProperty(value = "")

  @Valid

  public JsonNullable<MeteringMethod> getMeteringMethod() {
    return meteringMethod;
  }

  public void setMeteringMethod(JsonNullable<MeteringMethod> meteringMethod) {
    this.meteringMethod = meteringMethod;
  }

  public ChargingData offline(Boolean offline) {
    this.offline = offline;
    return this;
  }

  /**
   * Indicates the offline charging is applicable to the PCC rule.
   * @return offline
  */
  @ApiModelProperty(value = "Indicates the offline charging is applicable to the PCC rule.")


  public Boolean getOffline() {
    return offline;
  }

  public void setOffline(Boolean offline) {
    this.offline = offline;
  }

  public ChargingData online(Boolean online) {
    this.online = online;
    return this;
  }

  /**
   * Indicates the online charging is applicable to the PCC rule.
   * @return online
  */
  @ApiModelProperty(value = "Indicates the online charging is applicable to the PCC rule.")


  public Boolean getOnline() {
    return online;
  }

  public void setOnline(Boolean online) {
    this.online = online;
  }

  public ChargingData sdfHandl(Boolean sdfHandl) {
    this.sdfHandl = sdfHandl;
    return this;
  }

  /**
   * Indicates whether the service data flow is allowed to start while the SMF is waiting for the response to the credit request.
   * @return sdfHandl
  */
  @ApiModelProperty(value = "Indicates whether the service data flow is allowed to start while the SMF is waiting for the response to the credit request.")


  public Boolean getSdfHandl() {
    return sdfHandl;
  }

  public void setSdfHandl(Boolean sdfHandl) {
    this.sdfHandl = sdfHandl;
  }

  public ChargingData ratingGroup(Integer ratingGroup) {
    this.ratingGroup = ratingGroup;
    return this;
  }

  /**
   * Get ratingGroup
   * minimum: 0
   * @return ratingGroup
  */
  @ApiModelProperty(value = "")

@Min(0)
  public Integer getRatingGroup() {
    return ratingGroup;
  }

  public void setRatingGroup(Integer ratingGroup) {
    this.ratingGroup = ratingGroup;
  }

  public ChargingData reportingLevel(ReportingLevel reportingLevel) {
    this.reportingLevel = JsonNullable.of(reportingLevel);
    return this;
  }

  /**
   * Get reportingLevel
   * @return reportingLevel
  */
  @ApiModelProperty(value = "")

  @Valid

  public JsonNullable<ReportingLevel> getReportingLevel() {
    return reportingLevel;
  }

  public void setReportingLevel(JsonNullable<ReportingLevel> reportingLevel) {
    this.reportingLevel = reportingLevel;
  }

  public ChargingData serviceId(Integer serviceId) {
    this.serviceId = serviceId;
    return this;
  }

  /**
   * Get serviceId
   * minimum: 0
   * @return serviceId
  */
  @ApiModelProperty(value = "")

@Min(0)
  public Integer getServiceId() {
    return serviceId;
  }

  public void setServiceId(Integer serviceId) {
    this.serviceId = serviceId;
  }

  public ChargingData sponsorId(String sponsorId) {
    this.sponsorId = sponsorId;
    return this;
  }

  /**
   * Indicates the sponsor identity.
   * @return sponsorId
  */
  @ApiModelProperty(value = "Indicates the sponsor identity.")


  public String getSponsorId() {
    return sponsorId;
  }

  public void setSponsorId(String sponsorId) {
    this.sponsorId = sponsorId;
  }

  public ChargingData appSvcProvId(String appSvcProvId) {
    this.appSvcProvId = appSvcProvId;
    return this;
  }

  /**
   * Indicates the application service provider identity.
   * @return appSvcProvId
  */
  @ApiModelProperty(value = "Indicates the application service provider identity.")


  public String getAppSvcProvId() {
    return appSvcProvId;
  }

  public void setAppSvcProvId(String appSvcProvId) {
    this.appSvcProvId = appSvcProvId;
  }

  public ChargingData afChargingIdentifier(Integer afChargingIdentifier) {
    this.afChargingIdentifier = afChargingIdentifier;
    return this;
  }

  /**
   * Get afChargingIdentifier
   * minimum: 0
   * @return afChargingIdentifier
  */
  @ApiModelProperty(value = "")

@Min(0)
  public Integer getAfChargingIdentifier() {
    return afChargingIdentifier;
  }

  public void setAfChargingIdentifier(Integer afChargingIdentifier) {
    this.afChargingIdentifier = afChargingIdentifier;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ChargingData chargingData = (ChargingData) o;
    return Objects.equals(this.chgId, chargingData.chgId) &&
        Objects.equals(this.meteringMethod, chargingData.meteringMethod) &&
        Objects.equals(this.offline, chargingData.offline) &&
        Objects.equals(this.online, chargingData.online) &&
        Objects.equals(this.sdfHandl, chargingData.sdfHandl) &&
        Objects.equals(this.ratingGroup, chargingData.ratingGroup) &&
        Objects.equals(this.reportingLevel, chargingData.reportingLevel) &&
        Objects.equals(this.serviceId, chargingData.serviceId) &&
        Objects.equals(this.sponsorId, chargingData.sponsorId) &&
        Objects.equals(this.appSvcProvId, chargingData.appSvcProvId) &&
        Objects.equals(this.afChargingIdentifier, chargingData.afChargingIdentifier);
  }

  @Override
  public int hashCode() {
    return Objects.hash(chgId, meteringMethod, offline, online, sdfHandl, ratingGroup, reportingLevel, serviceId, sponsorId, appSvcProvId, afChargingIdentifier);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ChargingData {\n");
    
    sb.append("    chgId: ").append(toIndentedString(chgId)).append("\n");
    sb.append("    meteringMethod: ").append(toIndentedString(meteringMethod)).append("\n");
    sb.append("    offline: ").append(toIndentedString(offline)).append("\n");
    sb.append("    online: ").append(toIndentedString(online)).append("\n");
    sb.append("    sdfHandl: ").append(toIndentedString(sdfHandl)).append("\n");
    sb.append("    ratingGroup: ").append(toIndentedString(ratingGroup)).append("\n");
    sb.append("    reportingLevel: ").append(toIndentedString(reportingLevel)).append("\n");
    sb.append("    serviceId: ").append(toIndentedString(serviceId)).append("\n");
    sb.append("    sponsorId: ").append(toIndentedString(sponsorId)).append("\n");
    sb.append("    appSvcProvId: ").append(toIndentedString(appSvcProvId)).append("\n");
    sb.append("    afChargingIdentifier: ").append(toIndentedString(afChargingIdentifier)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

