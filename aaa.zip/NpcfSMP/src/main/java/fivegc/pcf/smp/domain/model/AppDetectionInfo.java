package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.FlowInformation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * AppDetectionInfo
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class AppDetectionInfo   {
  @JsonProperty("appId")
  private String appId;

  @JsonProperty("instanceId")
  private String instanceId;

  @JsonProperty("sdfDescriptions")
  @Valid
  private List<FlowInformation> sdfDescriptions = null;

  public AppDetectionInfo appId(String appId) {
    this.appId = appId;
    return this;
  }

  /**
   * A reference to the application detection filter configured at the UPF
   * @return appId
  */
  @ApiModelProperty(required = true, value = "A reference to the application detection filter configured at the UPF")
  @NotNull


  public String getAppId() {
    return appId;
  }

  public void setAppId(String appId) {
    this.appId = appId;
  }

  public AppDetectionInfo instanceId(String instanceId) {
    this.instanceId = instanceId;
    return this;
  }

  /**
   * Identifier sent by the SMF in order to allow correlation of application Start and Stop events to the specific service data flow description, if service data flow descriptions are deducible.
   * @return instanceId
  */
  @ApiModelProperty(value = "Identifier sent by the SMF in order to allow correlation of application Start and Stop events to the specific service data flow description, if service data flow descriptions are deducible.")


  public String getInstanceId() {
    return instanceId;
  }

  public void setInstanceId(String instanceId) {
    this.instanceId = instanceId;
  }

  public AppDetectionInfo sdfDescriptions(List<FlowInformation> sdfDescriptions) {
    this.sdfDescriptions = sdfDescriptions;
    return this;
  }

  public AppDetectionInfo addSdfDescriptionsItem(FlowInformation sdfDescriptionsItem) {
    if (this.sdfDescriptions == null) {
      this.sdfDescriptions = new ArrayList<>();
    }
    this.sdfDescriptions.add(sdfDescriptionsItem);
    return this;
  }

  /**
   * Contains the detected service data flow descriptions if they are deducible.
   * @return sdfDescriptions
  */
  @ApiModelProperty(value = "Contains the detected service data flow descriptions if they are deducible.")

  @Valid
@Size(min=1) 
  public List<FlowInformation> getSdfDescriptions() {
    return sdfDescriptions;
  }

  public void setSdfDescriptions(List<FlowInformation> sdfDescriptions) {
    this.sdfDescriptions = sdfDescriptions;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AppDetectionInfo appDetectionInfo = (AppDetectionInfo) o;
    return Objects.equals(this.appId, appDetectionInfo.appId) &&
        Objects.equals(this.instanceId, appDetectionInfo.instanceId) &&
        Objects.equals(this.sdfDescriptions, appDetectionInfo.sdfDescriptions);
  }

  @Override
  public int hashCode() {
    return Objects.hash(appId, instanceId, sdfDescriptions);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AppDetectionInfo {\n");
    
    sb.append("    appId: ").append(toIndentedString(appId)).append("\n");
    sb.append("    instanceId: ").append(toIndentedString(instanceId)).append("\n");
    sb.append("    sdfDescriptions: ").append(toIndentedString(sdfDescriptions)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

