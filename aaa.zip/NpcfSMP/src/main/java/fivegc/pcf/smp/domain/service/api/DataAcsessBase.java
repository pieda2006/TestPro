package fivegc.pcf.smp.domain.service.api;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.*;
import com.fasterxml.jackson.databind.JsonNode;

import org.springframework.stereotype.Repository;
import org.springframework.context.annotation.Scope;

@Scope("prototype")
@Repository
class DataAcsessBase extends ExecuteBase{
    public final static int GET = 0;
    public final static int INSERT = 1;
    public final static int UPDATE = 2;
    public final static int DELETE = 3;
    public final static int INTKEY = 0;
    public final static int STRINGKEY = 1;

    public final static int RGET = 20;
    public final static int SET = 21;
    public final static int DEL = 22;

    public JsonNode tableName;
    public JsonNode key;
    public JsonNode value;
    public JsonNode dataJson;
    public int keyType;
    public int tableKind;
    public int valueKind;
    public int keyKind;
    public int dataKind;

    private static final Logger log = LoggerFactory.getLogger(DataAcsessBase.class);

    //PCF追加
    public DataAcsessBase() {
    }

    public void executeAction(JsonNode reqJson, JsonNode ansJson, JsonNode distJson, JsonNode actionJson, JsonNode operationJson){
    }

    public void setParameterFromJson(JsonNode dataJson){

        if(null != dataJson){

            log.debug("dataJson : " + dataJson.toString());

            setTableName( dataJson );
            setKey( dataJson );
            setResult( dataJson );
            setTableKind( dataJson );
            setKeyKind( dataJson );
            setResultKind( dataJson );
            setkeyType( dataJson );
            setValue( dataJson );
            setValueKind( dataJson );
        }else{
            log.error("dataJson : null");
        }
    }

    public void setTableName(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }

        tableName = dataJson.path("TableName");
    }
    public void setKey(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        key = dataJson.path("Key");
    }
    public void setResult(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        this.dataJson = dataJson.path("Data");
        log.debug("setResult dataJson : " + this.dataJson.toString());
    }
    public void setTableKind(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        tableKind = dataJson.path("TableKind").asInt();
    }
    public void setKeyKind(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        keyKind = dataJson.path("KeyKind").asInt();
    }
    public void setResultKind(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        dataKind = dataJson.path("DataKind").asInt();
    }
    public void setkeyType(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        keyType = dataJson.path("KeyType").asInt();
    }
    public void setValue(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        value = dataJson.path("Value");
    }
    public void setValueKind(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        valueKind = dataJson.path("ValueKind").asInt();
    }

}
