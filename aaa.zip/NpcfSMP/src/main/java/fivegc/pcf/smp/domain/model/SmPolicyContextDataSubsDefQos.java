package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataSubsDefQosArp;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyContextDataSubsDefQos
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyContextDataSubsDefQos   {
  @JsonProperty("5qi")
  private Integer _5qi;

  @JsonProperty("arp")
  private SmPolicyContextDataSubsDefQosArp arp = null;

  @JsonProperty("priorityLevel")
  private Integer priorityLevel;

  public SmPolicyContextDataSubsDefQos _5qi(Integer _5qi) {
    this._5qi = _5qi;
    return this;
  }

  /**
   * Get _5qi
   * minimum: 0
   * maximum: 255
   * @return _5qi
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Min(0) @Max(255) 
  public Integer get5qi() {
    return _5qi;
  }

  public void set5qi(Integer _5qi) {
    this._5qi = _5qi;
  }

  public SmPolicyContextDataSubsDefQos arp(SmPolicyContextDataSubsDefQosArp arp) {
    this.arp = arp;
    return this;
  }

  /**
   * Get arp
   * @return arp
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public SmPolicyContextDataSubsDefQosArp getArp() {
    return arp;
  }

  public void setArp(SmPolicyContextDataSubsDefQosArp arp) {
    this.arp = arp;
  }

  public SmPolicyContextDataSubsDefQos priorityLevel(Integer priorityLevel) {
    this.priorityLevel = priorityLevel;
    return this;
  }

  /**
   * Get priorityLevel
   * minimum: 1
   * maximum: 127
   * @return priorityLevel
  */
  @ApiModelProperty(value = "")

@Min(1) @Max(127) 
  public Integer getPriorityLevel() {
    return priorityLevel;
  }

  public void setPriorityLevel(Integer priorityLevel) {
    this.priorityLevel = priorityLevel;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyContextDataSubsDefQos smPolicyContextDataSubsDefQos = (SmPolicyContextDataSubsDefQos) o;
    return Objects.equals(this._5qi, smPolicyContextDataSubsDefQos._5qi) &&
        Objects.equals(this.arp, smPolicyContextDataSubsDefQos.arp) &&
        Objects.equals(this.priorityLevel, smPolicyContextDataSubsDefQos.priorityLevel);
  }

  @Override
  public int hashCode() {
    return Objects.hash(_5qi, arp, priorityLevel);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyContextDataSubsDefQos {\n");
    
    sb.append("    _5qi: ").append(toIndentedString(_5qi)).append("\n");
    sb.append("    arp: ").append(toIndentedString(arp)).append("\n");
    sb.append("    priorityLevel: ").append(toIndentedString(priorityLevel)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

