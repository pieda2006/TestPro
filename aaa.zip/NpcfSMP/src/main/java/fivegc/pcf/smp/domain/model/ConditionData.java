package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.OffsetDateTime;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ConditionData
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class ConditionData   {
  @JsonProperty("condId")
  private String condId;

  @JsonProperty("activationTime")
  private JsonNullable<OffsetDateTime> activationTime = JsonNullable.undefined();

  @JsonProperty("deactivationTime")
  private JsonNullable<OffsetDateTime> deactivationTime = JsonNullable.undefined();

  /**
   * Gets or Sets accessType
   */
  public enum AccessTypeEnum {
    _3GPP_ACCESS("3GPP_ACCESS"),
    
    NON_3GPP_ACCESS("NON_3GPP_ACCESS");

    private String value;

    AccessTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static AccessTypeEnum fromValue(String value) {
      for (AccessTypeEnum b : AccessTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("accessType")
  private AccessTypeEnum accessType;

  /**
   * Gets or Sets ratType
   */
  public enum RatTypeEnum {
    NR("NR"),
    
    EUTRA("EUTRA"),
    
    WLAN("WLAN"),
    
    VIRTUAL("VIRTUAL"),
    
    NBIOT("NBIOT");

    private String value;

    RatTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static RatTypeEnum fromValue(String value) {
      for (RatTypeEnum b : RatTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("ratType")
  private RatTypeEnum ratType;

  public ConditionData condId(String condId) {
    this.condId = condId;
    return this;
  }

  /**
   * Uniquely identifies the condition data within a PDU session.
   * @return condId
  */
  @ApiModelProperty(required = true, value = "Uniquely identifies the condition data within a PDU session.")
  @NotNull


  public String getCondId() {
    return condId;
  }

  public void setCondId(String condId) {
    this.condId = condId;
  }

  public ConditionData activationTime(OffsetDateTime activationTime) {
    this.activationTime = JsonNullable.of(activationTime);
    return this;
  }

  /**
   * Get activationTime
   * @return activationTime
  */
  @ApiModelProperty(value = "")

  @Valid

  public JsonNullable<OffsetDateTime> getActivationTime() {
    return activationTime;
  }

  public void setActivationTime(JsonNullable<OffsetDateTime> activationTime) {
    this.activationTime = activationTime;
  }

  public ConditionData deactivationTime(OffsetDateTime deactivationTime) {
    this.deactivationTime = JsonNullable.of(deactivationTime);
    return this;
  }

  /**
   * Get deactivationTime
   * @return deactivationTime
  */
  @ApiModelProperty(value = "")

  @Valid

  public JsonNullable<OffsetDateTime> getDeactivationTime() {
    return deactivationTime;
  }

  public void setDeactivationTime(JsonNullable<OffsetDateTime> deactivationTime) {
    this.deactivationTime = deactivationTime;
  }

  public ConditionData accessType(AccessTypeEnum accessType) {
    this.accessType = accessType;
    return this;
  }

  /**
   * Get accessType
   * @return accessType
  */
  @ApiModelProperty(value = "")


  public AccessTypeEnum getAccessType() {
    return accessType;
  }

  public void setAccessType(AccessTypeEnum accessType) {
    this.accessType = accessType;
  }

  public ConditionData ratType(RatTypeEnum ratType) {
    this.ratType = ratType;
    return this;
  }

  /**
   * Get ratType
   * @return ratType
  */
  @ApiModelProperty(value = "")


  public RatTypeEnum getRatType() {
    return ratType;
  }

  public void setRatType(RatTypeEnum ratType) {
    this.ratType = ratType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConditionData conditionData = (ConditionData) o;
    return Objects.equals(this.condId, conditionData.condId) &&
        Objects.equals(this.activationTime, conditionData.activationTime) &&
        Objects.equals(this.deactivationTime, conditionData.deactivationTime) &&
        Objects.equals(this.accessType, conditionData.accessType) &&
        Objects.equals(this.ratType, conditionData.ratType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(condId, activationTime, deactivationTime, accessType, ratType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConditionData {\n");
    
    sb.append("    condId: ").append(toIndentedString(condId)).append("\n");
    sb.append("    activationTime: ").append(toIndentedString(activationTime)).append("\n");
    sb.append("    deactivationTime: ").append(toIndentedString(deactivationTime)).append("\n");
    sb.append("    accessType: ").append(toIndentedString(accessType)).append("\n");
    sb.append("    ratType: ").append(toIndentedString(ratType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

