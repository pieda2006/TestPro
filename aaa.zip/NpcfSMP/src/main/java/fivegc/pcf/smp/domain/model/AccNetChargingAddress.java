package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Describes the network entity within the access network performing charging
 */
@ApiModel(description = "Describes the network entity within the access network performing charging")
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class AccNetChargingAddress   {
  @JsonProperty("anChargIpv4Addr")
  private String anChargIpv4Addr;

  @JsonProperty("anChargIpv6Addr")
  private String anChargIpv6Addr;

  public AccNetChargingAddress anChargIpv4Addr(String anChargIpv4Addr) {
    this.anChargIpv4Addr = anChargIpv4Addr;
    return this;
  }

  /**
   * Get anChargIpv4Addr
   * @return anChargIpv4Addr
  */
  @ApiModelProperty(example = "198.51.100.1", value = "")

@Pattern(regexp="^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$") 
  public String getAnChargIpv4Addr() {
    return anChargIpv4Addr;
  }

  public void setAnChargIpv4Addr(String anChargIpv4Addr) {
    this.anChargIpv4Addr = anChargIpv4Addr;
  }

  public AccNetChargingAddress anChargIpv6Addr(String anChargIpv6Addr) {
    this.anChargIpv6Addr = anChargIpv6Addr;
    return this;
  }

  /**
   * Get anChargIpv6Addr
   * @return anChargIpv6Addr
  */
  @ApiModelProperty(example = "2001:db8:85a3::8a2e:370:7334", value = "")


  public String getAnChargIpv6Addr() {
    return anChargIpv6Addr;
  }

  public void setAnChargIpv6Addr(String anChargIpv6Addr) {
    this.anChargIpv6Addr = anChargIpv6Addr;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AccNetChargingAddress accNetChargingAddress = (AccNetChargingAddress) o;
    return Objects.equals(this.anChargIpv4Addr, accNetChargingAddress.anChargIpv4Addr) &&
        Objects.equals(this.anChargIpv6Addr, accNetChargingAddress.anChargIpv6Addr);
  }

  @Override
  public int hashCode() {
    return Objects.hash(anChargIpv4Addr, anChargIpv6Addr);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AccNetChargingAddress {\n");
    
    sb.append("    anChargIpv4Addr: ").append(toIndentedString(anChargIpv4Addr)).append("\n");
    sb.append("    anChargIpv6Addr: ").append(toIndentedString(anChargIpv6Addr)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

