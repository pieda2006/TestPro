package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import fivegc.pcf.smp.domain.model.AccNetChId;
import fivegc.pcf.smp.domain.model.AccuUsageReport;
import fivegc.pcf.smp.domain.model.AppDetectionInfo;
import fivegc.pcf.smp.domain.model.CreditManagementStatus;
import fivegc.pcf.smp.domain.model.PolicyControlRequestTrigger;
import fivegc.pcf.smp.domain.model.QosFlowUsage;
import fivegc.pcf.smp.domain.model.QosNotificationControlInfo;
import fivegc.pcf.smp.domain.model.RuleReport;
import fivegc.pcf.smp.domain.model.ServingNfIdentity;
import fivegc.pcf.smp.domain.model.SessionRuleReport;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataServingNetwork;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataSubsDefQos;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataSubsSessAmbr;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataTraceReq;
import fivegc.pcf.smp.domain.model.SmPolicyUpdateContextDataRepPraInfos;
import fivegc.pcf.smp.domain.model.SmPolicyUpdateContextDataUserLocationInfo;
import fivegc.pcf.smp.domain.model.UeInitiatedResourceRequest;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SmPolicyUpdateContextData
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class SmPolicyUpdateContextData   {
  @JsonProperty("repPolicyCtrlReqTriggers")
  @Valid
  private List<PolicyControlRequestTrigger> repPolicyCtrlReqTriggers = null;

  @JsonProperty("accNetChIds")
  @Valid
  private List<AccNetChId> accNetChIds = null;

  /**
   * Gets or Sets accessType
   */
  public enum AccessTypeEnum {
    _3GPP_ACCESS("3GPP_ACCESS"),
    
    NON_3GPP_ACCESS("NON_3GPP_ACCESS");

    private String value;

    AccessTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static AccessTypeEnum fromValue(String value) {
      for (AccessTypeEnum b : AccessTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("accessType")
  private AccessTypeEnum accessType;

  /**
   * Gets or Sets ratType
   */
  public enum RatTypeEnum {
    NR("NR"),
    
    EUTRA("EUTRA"),
    
    WLAN("WLAN"),
    
    VIRTUAL("VIRTUAL"),
    
    NBIOT("NBIOT");

    private String value;

    RatTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static RatTypeEnum fromValue(String value) {
      for (RatTypeEnum b : RatTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("ratType")
  private RatTypeEnum ratType;

  @JsonProperty("servingNetwork")
  private SmPolicyContextDataServingNetwork servingNetwork = null;

  @JsonProperty("userLocationInfo")
  private SmPolicyUpdateContextDataUserLocationInfo userLocationInfo = null;

  @JsonProperty("ueTimeZone")
  private String ueTimeZone;

  @JsonProperty("relIpv4Address")
  private String relIpv4Address;

  @JsonProperty("ipv4Address")
  private String ipv4Address;

  @JsonProperty("ipv6AddressPrefix")
  private String ipv6AddressPrefix;

  @JsonProperty("relIpv6AddressPrefix")
  private String relIpv6AddressPrefix;

  @JsonProperty("addIpv6AddrPrefixes")
  private String addIpv6AddrPrefixes;

  @JsonProperty("addRelIpv6AddrPrefixes")
  private String addRelIpv6AddrPrefixes;

  @JsonProperty("relUeMac")
  private String relUeMac;

  @JsonProperty("ueMac")
  private String ueMac;

  @JsonProperty("subsSessAmbr")
  private SmPolicyContextDataSubsSessAmbr subsSessAmbr = null;

  @JsonProperty("authProfIndex")
  private String authProfIndex;

  @JsonProperty("subsDefQos")
  private SmPolicyContextDataSubsDefQos subsDefQos = null;

  @JsonProperty("numOfPackFilter")
  private Integer numOfPackFilter;

  @JsonProperty("accuUsageReports")
  @Valid
  private List<AccuUsageReport> accuUsageReports = null;

  @JsonProperty("3gppPsDataOffStatus")
  private Boolean _3gppPsDataOffStatus;

  @JsonProperty("appDetectionInfos")
  @Valid
  private List<AppDetectionInfo> appDetectionInfos = null;

  @JsonProperty("ruleReports")
  @Valid
  private List<RuleReport> ruleReports = null;

  @JsonProperty("sessRuleReports")
  @Valid
  private List<SessionRuleReport> sessRuleReports = null;

  @JsonProperty("qncReports")
  @Valid
  private List<QosNotificationControlInfo> qncReports = null;

  @JsonProperty("userLocationInfoTime")
  private OffsetDateTime userLocationInfoTime;

  @JsonProperty("repPraInfos")
  @Valid
  private Map<String, SmPolicyUpdateContextDataRepPraInfos> repPraInfos = null;

  @JsonProperty("ueInitResReq")
  private UeInitiatedResourceRequest ueInitResReq = null;

  @JsonProperty("refQosIndication")
  private Boolean refQosIndication;

  @JsonProperty("qosFlowUsage")
  private QosFlowUsage qosFlowUsage;

  @JsonProperty("creditManageStatus")
  private CreditManagementStatus creditManageStatus;

  @JsonProperty("servNfId")
  private ServingNfIdentity servNfId = null;

  @JsonProperty("traceReq")
  private JsonNullable<SmPolicyContextDataTraceReq> traceReq = JsonNullable.undefined();

  public SmPolicyUpdateContextData repPolicyCtrlReqTriggers(List<PolicyControlRequestTrigger> repPolicyCtrlReqTriggers) {
    this.repPolicyCtrlReqTriggers = repPolicyCtrlReqTriggers;
    return this;
  }

  public SmPolicyUpdateContextData addRepPolicyCtrlReqTriggersItem(PolicyControlRequestTrigger repPolicyCtrlReqTriggersItem) {
    if (this.repPolicyCtrlReqTriggers == null) {
      this.repPolicyCtrlReqTriggers = new ArrayList<>();
    }
    this.repPolicyCtrlReqTriggers.add(repPolicyCtrlReqTriggersItem);
    return this;
  }

  /**
   * The policy control reqeust trigges which are met.
   * @return repPolicyCtrlReqTriggers
  */
  @ApiModelProperty(value = "The policy control reqeust trigges which are met.")

  @Valid
@Size(min=1) 
  public List<PolicyControlRequestTrigger> getRepPolicyCtrlReqTriggers() {
    return repPolicyCtrlReqTriggers;
  }

  public void setRepPolicyCtrlReqTriggers(List<PolicyControlRequestTrigger> repPolicyCtrlReqTriggers) {
    this.repPolicyCtrlReqTriggers = repPolicyCtrlReqTriggers;
  }

  public SmPolicyUpdateContextData accNetChIds(List<AccNetChId> accNetChIds) {
    this.accNetChIds = accNetChIds;
    return this;
  }

  public SmPolicyUpdateContextData addAccNetChIdsItem(AccNetChId accNetChIdsItem) {
    if (this.accNetChIds == null) {
      this.accNetChIds = new ArrayList<>();
    }
    this.accNetChIds.add(accNetChIdsItem);
    return this;
  }

  /**
   * Indicates the access network charging identifier for the PCC rule(s) or whole PDU session.
   * @return accNetChIds
  */
  @ApiModelProperty(value = "Indicates the access network charging identifier for the PCC rule(s) or whole PDU session.")

  @Valid
@Size(min=1) 
  public List<AccNetChId> getAccNetChIds() {
    return accNetChIds;
  }

  public void setAccNetChIds(List<AccNetChId> accNetChIds) {
    this.accNetChIds = accNetChIds;
  }

  public SmPolicyUpdateContextData accessType(AccessTypeEnum accessType) {
    this.accessType = accessType;
    return this;
  }

  /**
   * Get accessType
   * @return accessType
  */
  @ApiModelProperty(value = "")


  public AccessTypeEnum getAccessType() {
    return accessType;
  }

  public void setAccessType(AccessTypeEnum accessType) {
    this.accessType = accessType;
  }

  public SmPolicyUpdateContextData ratType(RatTypeEnum ratType) {
    this.ratType = ratType;
    return this;
  }

  /**
   * Get ratType
   * @return ratType
  */
  @ApiModelProperty(value = "")


  public RatTypeEnum getRatType() {
    return ratType;
  }

  public void setRatType(RatTypeEnum ratType) {
    this.ratType = ratType;
  }

  public SmPolicyUpdateContextData servingNetwork(SmPolicyContextDataServingNetwork servingNetwork) {
    this.servingNetwork = servingNetwork;
    return this;
  }

  /**
   * Get servingNetwork
   * @return servingNetwork
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataServingNetwork getServingNetwork() {
    return servingNetwork;
  }

  public void setServingNetwork(SmPolicyContextDataServingNetwork servingNetwork) {
    this.servingNetwork = servingNetwork;
  }

  public SmPolicyUpdateContextData userLocationInfo(SmPolicyUpdateContextDataUserLocationInfo userLocationInfo) {
    this.userLocationInfo = userLocationInfo;
    return this;
  }

  /**
   * Get userLocationInfo
   * @return userLocationInfo
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyUpdateContextDataUserLocationInfo getUserLocationInfo() {
    return userLocationInfo;
  }

  public void setUserLocationInfo(SmPolicyUpdateContextDataUserLocationInfo userLocationInfo) {
    this.userLocationInfo = userLocationInfo;
  }

  public SmPolicyUpdateContextData ueTimeZone(String ueTimeZone) {
    this.ueTimeZone = ueTimeZone;
    return this;
  }

  /**
   * Get ueTimeZone
   * @return ueTimeZone
  */
  @ApiModelProperty(value = "")


  public String getUeTimeZone() {
    return ueTimeZone;
  }

  public void setUeTimeZone(String ueTimeZone) {
    this.ueTimeZone = ueTimeZone;
  }

  public SmPolicyUpdateContextData relIpv4Address(String relIpv4Address) {
    this.relIpv4Address = relIpv4Address;
    return this;
  }

  /**
   * Get relIpv4Address
   * @return relIpv4Address
  */
  @ApiModelProperty(example = "198.51.100.1", value = "")

@Pattern(regexp="^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$") 
  public String getRelIpv4Address() {
    return relIpv4Address;
  }

  public void setRelIpv4Address(String relIpv4Address) {
    this.relIpv4Address = relIpv4Address;
  }

  public SmPolicyUpdateContextData ipv4Address(String ipv4Address) {
    this.ipv4Address = ipv4Address;
    return this;
  }

  /**
   * Get ipv4Address
   * @return ipv4Address
  */
  @ApiModelProperty(example = "198.51.100.1", value = "")

@Pattern(regexp="^(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])$") 
  public String getIpv4Address() {
    return ipv4Address;
  }

  public void setIpv4Address(String ipv4Address) {
    this.ipv4Address = ipv4Address;
  }

  public SmPolicyUpdateContextData ipv6AddressPrefix(String ipv6AddressPrefix) {
    this.ipv6AddressPrefix = ipv6AddressPrefix;
    return this;
  }

  /**
   * Get ipv6AddressPrefix
   * @return ipv6AddressPrefix
  */
  @ApiModelProperty(example = "2001:db8:abcd:12::0/64", value = "")


  public String getIpv6AddressPrefix() {
    return ipv6AddressPrefix;
  }

  public void setIpv6AddressPrefix(String ipv6AddressPrefix) {
    this.ipv6AddressPrefix = ipv6AddressPrefix;
  }

  public SmPolicyUpdateContextData relIpv6AddressPrefix(String relIpv6AddressPrefix) {
    this.relIpv6AddressPrefix = relIpv6AddressPrefix;
    return this;
  }

  /**
   * Get relIpv6AddressPrefix
   * @return relIpv6AddressPrefix
  */
  @ApiModelProperty(example = "2001:db8:abcd:12::0/64", value = "")


  public String getRelIpv6AddressPrefix() {
    return relIpv6AddressPrefix;
  }

  public void setRelIpv6AddressPrefix(String relIpv6AddressPrefix) {
    this.relIpv6AddressPrefix = relIpv6AddressPrefix;
  }

  public SmPolicyUpdateContextData addIpv6AddrPrefixes(String addIpv6AddrPrefixes) {
    this.addIpv6AddrPrefixes = addIpv6AddrPrefixes;
    return this;
  }

  /**
   * Get addIpv6AddrPrefixes
   * @return addIpv6AddrPrefixes
  */
  @ApiModelProperty(example = "2001:db8:abcd:12::0/64", value = "")


  public String getAddIpv6AddrPrefixes() {
    return addIpv6AddrPrefixes;
  }

  public void setAddIpv6AddrPrefixes(String addIpv6AddrPrefixes) {
    this.addIpv6AddrPrefixes = addIpv6AddrPrefixes;
  }

  public SmPolicyUpdateContextData addRelIpv6AddrPrefixes(String addRelIpv6AddrPrefixes) {
    this.addRelIpv6AddrPrefixes = addRelIpv6AddrPrefixes;
    return this;
  }

  /**
   * Get addRelIpv6AddrPrefixes
   * @return addRelIpv6AddrPrefixes
  */
  @ApiModelProperty(example = "2001:db8:abcd:12::0/64", value = "")


  public String getAddRelIpv6AddrPrefixes() {
    return addRelIpv6AddrPrefixes;
  }

  public void setAddRelIpv6AddrPrefixes(String addRelIpv6AddrPrefixes) {
    this.addRelIpv6AddrPrefixes = addRelIpv6AddrPrefixes;
  }

  public SmPolicyUpdateContextData relUeMac(String relUeMac) {
    this.relUeMac = relUeMac;
    return this;
  }

  /**
   * Get relUeMac
   * @return relUeMac
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^([0-9a-fA-F]{2})((-[0-9a-fA-F]{2}){5})$") 
  public String getRelUeMac() {
    return relUeMac;
  }

  public void setRelUeMac(String relUeMac) {
    this.relUeMac = relUeMac;
  }

  public SmPolicyUpdateContextData ueMac(String ueMac) {
    this.ueMac = ueMac;
    return this;
  }

  /**
   * Get ueMac
   * @return ueMac
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^([0-9a-fA-F]{2})((-[0-9a-fA-F]{2}){5})$") 
  public String getUeMac() {
    return ueMac;
  }

  public void setUeMac(String ueMac) {
    this.ueMac = ueMac;
  }

  public SmPolicyUpdateContextData subsSessAmbr(SmPolicyContextDataSubsSessAmbr subsSessAmbr) {
    this.subsSessAmbr = subsSessAmbr;
    return this;
  }

  /**
   * Get subsSessAmbr
   * @return subsSessAmbr
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataSubsSessAmbr getSubsSessAmbr() {
    return subsSessAmbr;
  }

  public void setSubsSessAmbr(SmPolicyContextDataSubsSessAmbr subsSessAmbr) {
    this.subsSessAmbr = subsSessAmbr;
  }

  public SmPolicyUpdateContextData authProfIndex(String authProfIndex) {
    this.authProfIndex = authProfIndex;
    return this;
  }

  /**
   * Indicates the DN-AAA authorization profile index
   * @return authProfIndex
  */
  @ApiModelProperty(value = "Indicates the DN-AAA authorization profile index")


  public String getAuthProfIndex() {
    return authProfIndex;
  }

  public void setAuthProfIndex(String authProfIndex) {
    this.authProfIndex = authProfIndex;
  }

  public SmPolicyUpdateContextData subsDefQos(SmPolicyContextDataSubsDefQos subsDefQos) {
    this.subsDefQos = subsDefQos;
    return this;
  }

  /**
   * Get subsDefQos
   * @return subsDefQos
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataSubsDefQos getSubsDefQos() {
    return subsDefQos;
  }

  public void setSubsDefQos(SmPolicyContextDataSubsDefQos subsDefQos) {
    this.subsDefQos = subsDefQos;
  }

  public SmPolicyUpdateContextData numOfPackFilter(Integer numOfPackFilter) {
    this.numOfPackFilter = numOfPackFilter;
    return this;
  }

  /**
   * Contains the number of supported packet filter for signalled QoS rules.
   * @return numOfPackFilter
  */
  @ApiModelProperty(value = "Contains the number of supported packet filter for signalled QoS rules.")


  public Integer getNumOfPackFilter() {
    return numOfPackFilter;
  }

  public void setNumOfPackFilter(Integer numOfPackFilter) {
    this.numOfPackFilter = numOfPackFilter;
  }

  public SmPolicyUpdateContextData accuUsageReports(List<AccuUsageReport> accuUsageReports) {
    this.accuUsageReports = accuUsageReports;
    return this;
  }

  public SmPolicyUpdateContextData addAccuUsageReportsItem(AccuUsageReport accuUsageReportsItem) {
    if (this.accuUsageReports == null) {
      this.accuUsageReports = new ArrayList<>();
    }
    this.accuUsageReports.add(accuUsageReportsItem);
    return this;
  }

  /**
   * Contains the usage report
   * @return accuUsageReports
  */
  @ApiModelProperty(value = "Contains the usage report")

  @Valid
@Size(min=1) 
  public List<AccuUsageReport> getAccuUsageReports() {
    return accuUsageReports;
  }

  public void setAccuUsageReports(List<AccuUsageReport> accuUsageReports) {
    this.accuUsageReports = accuUsageReports;
  }

  public SmPolicyUpdateContextData _3gppPsDataOffStatus(Boolean _3gppPsDataOffStatus) {
    this._3gppPsDataOffStatus = _3gppPsDataOffStatus;
    return this;
  }

  /**
   * If it is included and set to true, the 3GPP PS Data Off is activated by the UE.
   * @return _3gppPsDataOffStatus
  */
  @ApiModelProperty(value = "If it is included and set to true, the 3GPP PS Data Off is activated by the UE.")


  public Boolean get3gppPsDataOffStatus() {
    return _3gppPsDataOffStatus;
  }

  public void set3gppPsDataOffStatus(Boolean _3gppPsDataOffStatus) {
    this._3gppPsDataOffStatus = _3gppPsDataOffStatus;
  }

  public SmPolicyUpdateContextData appDetectionInfos(List<AppDetectionInfo> appDetectionInfos) {
    this.appDetectionInfos = appDetectionInfos;
    return this;
  }

  public SmPolicyUpdateContextData addAppDetectionInfosItem(AppDetectionInfo appDetectionInfosItem) {
    if (this.appDetectionInfos == null) {
      this.appDetectionInfos = new ArrayList<>();
    }
    this.appDetectionInfos.add(appDetectionInfosItem);
    return this;
  }

  /**
   * Report the start/stop of the application traffic and detected SDF descriptions if applicable.
   * @return appDetectionInfos
  */
  @ApiModelProperty(value = "Report the start/stop of the application traffic and detected SDF descriptions if applicable.")

  @Valid
@Size(min=1) 
  public List<AppDetectionInfo> getAppDetectionInfos() {
    return appDetectionInfos;
  }

  public void setAppDetectionInfos(List<AppDetectionInfo> appDetectionInfos) {
    this.appDetectionInfos = appDetectionInfos;
  }

  public SmPolicyUpdateContextData ruleReports(List<RuleReport> ruleReports) {
    this.ruleReports = ruleReports;
    return this;
  }

  public SmPolicyUpdateContextData addRuleReportsItem(RuleReport ruleReportsItem) {
    if (this.ruleReports == null) {
      this.ruleReports = new ArrayList<>();
    }
    this.ruleReports.add(ruleReportsItem);
    return this;
  }

  /**
   * Used to report the PCC rule failure.
   * @return ruleReports
  */
  @ApiModelProperty(value = "Used to report the PCC rule failure.")

  @Valid
@Size(min=1) 
  public List<RuleReport> getRuleReports() {
    return ruleReports;
  }

  public void setRuleReports(List<RuleReport> ruleReports) {
    this.ruleReports = ruleReports;
  }

  public SmPolicyUpdateContextData sessRuleReports(List<SessionRuleReport> sessRuleReports) {
    this.sessRuleReports = sessRuleReports;
    return this;
  }

  public SmPolicyUpdateContextData addSessRuleReportsItem(SessionRuleReport sessRuleReportsItem) {
    if (this.sessRuleReports == null) {
      this.sessRuleReports = new ArrayList<>();
    }
    this.sessRuleReports.add(sessRuleReportsItem);
    return this;
  }

  /**
   * Used to report the session rule failure.
   * @return sessRuleReports
  */
  @ApiModelProperty(value = "Used to report the session rule failure.")

  @Valid
@Size(min=1) 
  public List<SessionRuleReport> getSessRuleReports() {
    return sessRuleReports;
  }

  public void setSessRuleReports(List<SessionRuleReport> sessRuleReports) {
    this.sessRuleReports = sessRuleReports;
  }

  public SmPolicyUpdateContextData qncReports(List<QosNotificationControlInfo> qncReports) {
    this.qncReports = qncReports;
    return this;
  }

  public SmPolicyUpdateContextData addQncReportsItem(QosNotificationControlInfo qncReportsItem) {
    if (this.qncReports == null) {
      this.qncReports = new ArrayList<>();
    }
    this.qncReports.add(qncReportsItem);
    return this;
  }

  /**
   * QoS Notification Control information.
   * @return qncReports
  */
  @ApiModelProperty(value = "QoS Notification Control information.")

  @Valid
@Size(min=1) 
  public List<QosNotificationControlInfo> getQncReports() {
    return qncReports;
  }

  public void setQncReports(List<QosNotificationControlInfo> qncReports) {
    this.qncReports = qncReports;
  }

  public SmPolicyUpdateContextData userLocationInfoTime(OffsetDateTime userLocationInfoTime) {
    this.userLocationInfoTime = userLocationInfoTime;
    return this;
  }

  /**
   * Get userLocationInfoTime
   * @return userLocationInfoTime
  */
  @ApiModelProperty(value = "")

  @Valid

  public OffsetDateTime getUserLocationInfoTime() {
    return userLocationInfoTime;
  }

  public void setUserLocationInfoTime(OffsetDateTime userLocationInfoTime) {
    this.userLocationInfoTime = userLocationInfoTime;
  }

  public SmPolicyUpdateContextData repPraInfos(Map<String, SmPolicyUpdateContextDataRepPraInfos> repPraInfos) {
    this.repPraInfos = repPraInfos;
    return this;
  }

  public SmPolicyUpdateContextData putRepPraInfosItem(String key, SmPolicyUpdateContextDataRepPraInfos repPraInfosItem) {
    if (this.repPraInfos == null) {
      this.repPraInfos = new HashMap<>();
    }
    this.repPraInfos.put(key, repPraInfosItem);
    return this;
  }

  /**
   * Reports the changes of presence reporting area.
   * @return repPraInfos
  */
  @ApiModelProperty(value = "Reports the changes of presence reporting area.")

  @Valid
@Size(min=1) 
  public Map<String, SmPolicyUpdateContextDataRepPraInfos> getRepPraInfos() {
    return repPraInfos;
  }

  public void setRepPraInfos(Map<String, SmPolicyUpdateContextDataRepPraInfos> repPraInfos) {
    this.repPraInfos = repPraInfos;
  }

  public SmPolicyUpdateContextData ueInitResReq(UeInitiatedResourceRequest ueInitResReq) {
    this.ueInitResReq = ueInitResReq;
    return this;
  }

  /**
   * Get ueInitResReq
   * @return ueInitResReq
  */
  @ApiModelProperty(value = "")

  @Valid

  public UeInitiatedResourceRequest getUeInitResReq() {
    return ueInitResReq;
  }

  public void setUeInitResReq(UeInitiatedResourceRequest ueInitResReq) {
    this.ueInitResReq = ueInitResReq;
  }

  public SmPolicyUpdateContextData refQosIndication(Boolean refQosIndication) {
    this.refQosIndication = refQosIndication;
    return this;
  }

  /**
   * If it is included and set to true, the reflective QoS is supported by the UE. If it is included and set to false, the reflective QoS is revoked by the UE.
   * @return refQosIndication
  */
  @ApiModelProperty(value = "If it is included and set to true, the reflective QoS is supported by the UE. If it is included and set to false, the reflective QoS is revoked by the UE.")


  public Boolean getRefQosIndication() {
    return refQosIndication;
  }

  public void setRefQosIndication(Boolean refQosIndication) {
    this.refQosIndication = refQosIndication;
  }

  public SmPolicyUpdateContextData qosFlowUsage(QosFlowUsage qosFlowUsage) {
    this.qosFlowUsage = qosFlowUsage;
    return this;
  }

  /**
   * Get qosFlowUsage
   * @return qosFlowUsage
  */
  @ApiModelProperty(value = "")

  @Valid

  public QosFlowUsage getQosFlowUsage() {
    return qosFlowUsage;
  }

  public void setQosFlowUsage(QosFlowUsage qosFlowUsage) {
    this.qosFlowUsage = qosFlowUsage;
  }

  public SmPolicyUpdateContextData creditManageStatus(CreditManagementStatus creditManageStatus) {
    this.creditManageStatus = creditManageStatus;
    return this;
  }

  /**
   * Get creditManageStatus
   * @return creditManageStatus
  */
  @ApiModelProperty(value = "")

  @Valid

  public CreditManagementStatus getCreditManageStatus() {
    return creditManageStatus;
  }

  public void setCreditManageStatus(CreditManagementStatus creditManageStatus) {
    this.creditManageStatus = creditManageStatus;
  }

  public SmPolicyUpdateContextData servNfId(ServingNfIdentity servNfId) {
    this.servNfId = servNfId;
    return this;
  }

  /**
   * Get servNfId
   * @return servNfId
  */
  @ApiModelProperty(value = "")

  @Valid

  public ServingNfIdentity getServNfId() {
    return servNfId;
  }

  public void setServNfId(ServingNfIdentity servNfId) {
    this.servNfId = servNfId;
  }

  public SmPolicyUpdateContextData traceReq(SmPolicyContextDataTraceReq traceReq) {
    this.traceReq = JsonNullable.of(traceReq);
    return this;
  }

  /**
   * Get traceReq
   * @return traceReq
  */
  @ApiModelProperty(value = "")

  @Valid

  public JsonNullable<SmPolicyContextDataTraceReq> getTraceReq() {
    return traceReq;
  }

  public void setTraceReq(JsonNullable<SmPolicyContextDataTraceReq> traceReq) {
    this.traceReq = traceReq;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyUpdateContextData smPolicyUpdateContextData = (SmPolicyUpdateContextData) o;
    return Objects.equals(this.repPolicyCtrlReqTriggers, smPolicyUpdateContextData.repPolicyCtrlReqTriggers) &&
        Objects.equals(this.accNetChIds, smPolicyUpdateContextData.accNetChIds) &&
        Objects.equals(this.accessType, smPolicyUpdateContextData.accessType) &&
        Objects.equals(this.ratType, smPolicyUpdateContextData.ratType) &&
        Objects.equals(this.servingNetwork, smPolicyUpdateContextData.servingNetwork) &&
        Objects.equals(this.userLocationInfo, smPolicyUpdateContextData.userLocationInfo) &&
        Objects.equals(this.ueTimeZone, smPolicyUpdateContextData.ueTimeZone) &&
        Objects.equals(this.relIpv4Address, smPolicyUpdateContextData.relIpv4Address) &&
        Objects.equals(this.ipv4Address, smPolicyUpdateContextData.ipv4Address) &&
        Objects.equals(this.ipv6AddressPrefix, smPolicyUpdateContextData.ipv6AddressPrefix) &&
        Objects.equals(this.relIpv6AddressPrefix, smPolicyUpdateContextData.relIpv6AddressPrefix) &&
        Objects.equals(this.addIpv6AddrPrefixes, smPolicyUpdateContextData.addIpv6AddrPrefixes) &&
        Objects.equals(this.addRelIpv6AddrPrefixes, smPolicyUpdateContextData.addRelIpv6AddrPrefixes) &&
        Objects.equals(this.relUeMac, smPolicyUpdateContextData.relUeMac) &&
        Objects.equals(this.ueMac, smPolicyUpdateContextData.ueMac) &&
        Objects.equals(this.subsSessAmbr, smPolicyUpdateContextData.subsSessAmbr) &&
        Objects.equals(this.authProfIndex, smPolicyUpdateContextData.authProfIndex) &&
        Objects.equals(this.subsDefQos, smPolicyUpdateContextData.subsDefQos) &&
        Objects.equals(this.numOfPackFilter, smPolicyUpdateContextData.numOfPackFilter) &&
        Objects.equals(this.accuUsageReports, smPolicyUpdateContextData.accuUsageReports) &&
        Objects.equals(this._3gppPsDataOffStatus, smPolicyUpdateContextData._3gppPsDataOffStatus) &&
        Objects.equals(this.appDetectionInfos, smPolicyUpdateContextData.appDetectionInfos) &&
        Objects.equals(this.ruleReports, smPolicyUpdateContextData.ruleReports) &&
        Objects.equals(this.sessRuleReports, smPolicyUpdateContextData.sessRuleReports) &&
        Objects.equals(this.qncReports, smPolicyUpdateContextData.qncReports) &&
        Objects.equals(this.userLocationInfoTime, smPolicyUpdateContextData.userLocationInfoTime) &&
        Objects.equals(this.repPraInfos, smPolicyUpdateContextData.repPraInfos) &&
        Objects.equals(this.ueInitResReq, smPolicyUpdateContextData.ueInitResReq) &&
        Objects.equals(this.refQosIndication, smPolicyUpdateContextData.refQosIndication) &&
        Objects.equals(this.qosFlowUsage, smPolicyUpdateContextData.qosFlowUsage) &&
        Objects.equals(this.creditManageStatus, smPolicyUpdateContextData.creditManageStatus) &&
        Objects.equals(this.servNfId, smPolicyUpdateContextData.servNfId) &&
        Objects.equals(this.traceReq, smPolicyUpdateContextData.traceReq);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repPolicyCtrlReqTriggers, accNetChIds, accessType, ratType, servingNetwork, userLocationInfo, ueTimeZone, relIpv4Address, ipv4Address, ipv6AddressPrefix, relIpv6AddressPrefix, addIpv6AddrPrefixes, addRelIpv6AddrPrefixes, relUeMac, ueMac, subsSessAmbr, authProfIndex, subsDefQos, numOfPackFilter, accuUsageReports, _3gppPsDataOffStatus, appDetectionInfos, ruleReports, sessRuleReports, qncReports, userLocationInfoTime, repPraInfos, ueInitResReq, refQosIndication, qosFlowUsage, creditManageStatus, servNfId, traceReq);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyUpdateContextData {\n");
    
    sb.append("    repPolicyCtrlReqTriggers: ").append(toIndentedString(repPolicyCtrlReqTriggers)).append("\n");
    sb.append("    accNetChIds: ").append(toIndentedString(accNetChIds)).append("\n");
    sb.append("    accessType: ").append(toIndentedString(accessType)).append("\n");
    sb.append("    ratType: ").append(toIndentedString(ratType)).append("\n");
    sb.append("    servingNetwork: ").append(toIndentedString(servingNetwork)).append("\n");
    sb.append("    userLocationInfo: ").append(toIndentedString(userLocationInfo)).append("\n");
    sb.append("    ueTimeZone: ").append(toIndentedString(ueTimeZone)).append("\n");
    sb.append("    relIpv4Address: ").append(toIndentedString(relIpv4Address)).append("\n");
    sb.append("    ipv4Address: ").append(toIndentedString(ipv4Address)).append("\n");
    sb.append("    ipv6AddressPrefix: ").append(toIndentedString(ipv6AddressPrefix)).append("\n");
    sb.append("    relIpv6AddressPrefix: ").append(toIndentedString(relIpv6AddressPrefix)).append("\n");
    sb.append("    addIpv6AddrPrefixes: ").append(toIndentedString(addIpv6AddrPrefixes)).append("\n");
    sb.append("    addRelIpv6AddrPrefixes: ").append(toIndentedString(addRelIpv6AddrPrefixes)).append("\n");
    sb.append("    relUeMac: ").append(toIndentedString(relUeMac)).append("\n");
    sb.append("    ueMac: ").append(toIndentedString(ueMac)).append("\n");
    sb.append("    subsSessAmbr: ").append(toIndentedString(subsSessAmbr)).append("\n");
    sb.append("    authProfIndex: ").append(toIndentedString(authProfIndex)).append("\n");
    sb.append("    subsDefQos: ").append(toIndentedString(subsDefQos)).append("\n");
    sb.append("    numOfPackFilter: ").append(toIndentedString(numOfPackFilter)).append("\n");
    sb.append("    accuUsageReports: ").append(toIndentedString(accuUsageReports)).append("\n");
    sb.append("    _3gppPsDataOffStatus: ").append(toIndentedString(_3gppPsDataOffStatus)).append("\n");
    sb.append("    appDetectionInfos: ").append(toIndentedString(appDetectionInfos)).append("\n");
    sb.append("    ruleReports: ").append(toIndentedString(ruleReports)).append("\n");
    sb.append("    sessRuleReports: ").append(toIndentedString(sessRuleReports)).append("\n");
    sb.append("    qncReports: ").append(toIndentedString(qncReports)).append("\n");
    sb.append("    userLocationInfoTime: ").append(toIndentedString(userLocationInfoTime)).append("\n");
    sb.append("    repPraInfos: ").append(toIndentedString(repPraInfos)).append("\n");
    sb.append("    ueInitResReq: ").append(toIndentedString(ueInitResReq)).append("\n");
    sb.append("    refQosIndication: ").append(toIndentedString(refQosIndication)).append("\n");
    sb.append("    qosFlowUsage: ").append(toIndentedString(qosFlowUsage)).append("\n");
    sb.append("    creditManageStatus: ").append(toIndentedString(creditManageStatus)).append("\n");
    sb.append("    servNfId: ").append(toIndentedString(servNfId)).append("\n");
    sb.append("    traceReq: ").append(toIndentedString(traceReq)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

