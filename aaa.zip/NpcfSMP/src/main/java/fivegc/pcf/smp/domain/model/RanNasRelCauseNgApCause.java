package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RanNasRelCauseNgApCause
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class RanNasRelCauseNgApCause   {
  @JsonProperty("group")
  private Integer group;

  @JsonProperty("value")
  private Integer value;

  public RanNasRelCauseNgApCause group(Integer group) {
    this.group = group;
    return this;
  }

  /**
   * Get group
   * minimum: 0
   * @return group
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Min(0)
  public Integer getGroup() {
    return group;
  }

  public void setGroup(Integer group) {
    this.group = group;
  }

  public RanNasRelCauseNgApCause value(Integer value) {
    this.value = value;
    return this;
  }

  /**
   * Get value
   * minimum: 0
   * @return value
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Min(0)
  public Integer getValue() {
    return value;
  }

  public void setValue(Integer value) {
    this.value = value;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RanNasRelCauseNgApCause ranNasRelCauseNgApCause = (RanNasRelCauseNgApCause) o;
    return Objects.equals(this.group, ranNasRelCauseNgApCause.group) &&
        Objects.equals(this.value, ranNasRelCauseNgApCause.value);
  }

  @Override
  public int hashCode() {
    return Objects.hash(group, value);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RanNasRelCauseNgApCause {\n");
    
    sb.append("    group: ").append(toIndentedString(group)).append("\n");
    sb.append("    value: ").append(toIndentedString(value)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

