package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * QosCharacteristics
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class QosCharacteristics   {
  @JsonProperty("5qi")
  private Integer _5qi;

  /**
   * Gets or Sets resourceType
   */
  public enum ResourceTypeEnum {
    NON_GBR("NON_GBR"),
    
    NON_CRITICAL_GBR("NON_CRITICAL_GBR"),
    
    CRITICAL_GBR("CRITICAL_GBR");

    private String value;

    ResourceTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ResourceTypeEnum fromValue(String value) {
      for (ResourceTypeEnum b : ResourceTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("resourceType")
  private ResourceTypeEnum resourceType;

  @JsonProperty("priorityLevel")
  private Integer priorityLevel;

  @JsonProperty("packetDelayBudget")
  private Integer packetDelayBudget;

  @JsonProperty("packetErrorRate")
  private String packetErrorRate;

  @JsonProperty("averagingWindow")
  private Integer averagingWindow = 2000;

  @JsonProperty("maxDataBurstVol")
  private Integer maxDataBurstVol;

  public QosCharacteristics _5qi(Integer _5qi) {
    this._5qi = _5qi;
    return this;
  }

  /**
   * Get _5qi
   * minimum: 0
   * maximum: 255
   * @return _5qi
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Min(0) @Max(255) 
  public Integer get5qi() {
    return _5qi;
  }

  public void set5qi(Integer _5qi) {
    this._5qi = _5qi;
  }

  public QosCharacteristics resourceType(ResourceTypeEnum resourceType) {
    this.resourceType = resourceType;
    return this;
  }

  /**
   * Get resourceType
   * @return resourceType
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public ResourceTypeEnum getResourceType() {
    return resourceType;
  }

  public void setResourceType(ResourceTypeEnum resourceType) {
    this.resourceType = resourceType;
  }

  public QosCharacteristics priorityLevel(Integer priorityLevel) {
    this.priorityLevel = priorityLevel;
    return this;
  }

  /**
   * Get priorityLevel
   * minimum: 1
   * maximum: 127
   * @return priorityLevel
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Min(1) @Max(127) 
  public Integer getPriorityLevel() {
    return priorityLevel;
  }

  public void setPriorityLevel(Integer priorityLevel) {
    this.priorityLevel = priorityLevel;
  }

  public QosCharacteristics packetDelayBudget(Integer packetDelayBudget) {
    this.packetDelayBudget = packetDelayBudget;
    return this;
  }

  /**
   * Get packetDelayBudget
   * minimum: 1
   * @return packetDelayBudget
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Min(1)
  public Integer getPacketDelayBudget() {
    return packetDelayBudget;
  }

  public void setPacketDelayBudget(Integer packetDelayBudget) {
    this.packetDelayBudget = packetDelayBudget;
  }

  public QosCharacteristics packetErrorRate(String packetErrorRate) {
    this.packetErrorRate = packetErrorRate;
    return this;
  }

  /**
   * Get packetErrorRate
   * @return packetErrorRate
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Pattern(regexp="^([0-9]E-[0-9])$") 
  public String getPacketErrorRate() {
    return packetErrorRate;
  }

  public void setPacketErrorRate(String packetErrorRate) {
    this.packetErrorRate = packetErrorRate;
  }

  public QosCharacteristics averagingWindow(Integer averagingWindow) {
    this.averagingWindow = averagingWindow;
    return this;
  }

  /**
   * Get averagingWindow
   * minimum: 1
   * maximum: 4095
   * @return averagingWindow
  */
  @ApiModelProperty(value = "")

@Min(1) @Max(4095) 
  public Integer getAveragingWindow() {
    return averagingWindow;
  }

  public void setAveragingWindow(Integer averagingWindow) {
    this.averagingWindow = averagingWindow;
  }

  public QosCharacteristics maxDataBurstVol(Integer maxDataBurstVol) {
    this.maxDataBurstVol = maxDataBurstVol;
    return this;
  }

  /**
   * Get maxDataBurstVol
   * minimum: 1
   * maximum: 4095
   * @return maxDataBurstVol
  */
  @ApiModelProperty(value = "")

@Min(1) @Max(4095) 
  public Integer getMaxDataBurstVol() {
    return maxDataBurstVol;
  }

  public void setMaxDataBurstVol(Integer maxDataBurstVol) {
    this.maxDataBurstVol = maxDataBurstVol;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    QosCharacteristics qosCharacteristics = (QosCharacteristics) o;
    return Objects.equals(this._5qi, qosCharacteristics._5qi) &&
        Objects.equals(this.resourceType, qosCharacteristics.resourceType) &&
        Objects.equals(this.priorityLevel, qosCharacteristics.priorityLevel) &&
        Objects.equals(this.packetDelayBudget, qosCharacteristics.packetDelayBudget) &&
        Objects.equals(this.packetErrorRate, qosCharacteristics.packetErrorRate) &&
        Objects.equals(this.averagingWindow, qosCharacteristics.averagingWindow) &&
        Objects.equals(this.maxDataBurstVol, qosCharacteristics.maxDataBurstVol);
  }

  @Override
  public int hashCode() {
    return Objects.hash(_5qi, resourceType, priorityLevel, packetDelayBudget, packetErrorRate, averagingWindow, maxDataBurstVol);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class QosCharacteristics {\n");
    
    sb.append("    _5qi: ").append(toIndentedString(_5qi)).append("\n");
    sb.append("    resourceType: ").append(toIndentedString(resourceType)).append("\n");
    sb.append("    priorityLevel: ").append(toIndentedString(priorityLevel)).append("\n");
    sb.append("    packetDelayBudget: ").append(toIndentedString(packetDelayBudget)).append("\n");
    sb.append("    packetErrorRate: ").append(toIndentedString(packetErrorRate)).append("\n");
    sb.append("    averagingWindow: ").append(toIndentedString(averagingWindow)).append("\n");
    sb.append("    maxDataBurstVol: ").append(toIndentedString(maxDataBurstVol)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

