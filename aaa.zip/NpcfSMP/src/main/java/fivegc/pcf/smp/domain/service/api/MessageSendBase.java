package fivegc.pcf.smp.domain.service.api;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.*;
import com.fasterxml.jackson.databind.JsonNode;

import org.springframework.stereotype.Repository;
import org.springframework.context.annotation.Scope;

@Scope("prototype")
@Repository
class MessageSendBase  extends ExecuteBase{

    public JsonNode sendUri;
    public int uriKind;
    public JsonNode value;
    public JsonNode result;
    public JsonNode header;
    public JsonNode headvalue;
    public JsonNode user;
    public JsonNode pass;
    public int valueKind;
    public int dataKind;
    public int headerkind;
    public int headvaluekind;
    public int userKind;
    public int passKind;

    public final static int TYPEINT = 0;
    public final static int TYPESTRING = 1;
    public final static int TYPENULL = 2;
    public final static int TYPEOBJECT = 3;

    public final static int GET = 0;
    public final static int HEAD = 1;
    public final static int POST = 2;
    public final static int PUT = 3;
    public final static int DELETE = 4;
    public final static int CONNECT = 5;
    public final static int OPTIONS = 6;
    public final static int TRACE = 7;
    public final static int PATCH = 8;
    public final static int OWN = 9;

    private static final Logger log = LoggerFactory.getLogger(DataAcsessBase.class);

    //PCF追加
    public MessageSendBase() {
    }

    public void setParameterFromJson(JsonNode operationjson){
        if(null != operationjson){
            log.debug("operationjson : " + operationjson.toString());
            setSendUri(operationjson);
            setUriKind(operationjson);
            setSendValue(operationjson);
            setResult(operationjson);
            setValueKind(operationjson);
            setDataKind(operationjson);
            setHeader(operationjson);
            setHeaderKind(operationjson);
            setHeadValue(operationjson);
            setHeadValueKind(operationjson);
            setUser(operationjson);
            setUserKind(operationjson);
            setPass(operationjson);
            setPassKind(operationjson);
        }else{
            log.error("operationjson : null");
        }

    }

    /*** getter setter ***/
    void setSendUri(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        sendUri = dataJson.path("SendTo");
    }
    void setUriKind(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        uriKind = dataJson.path("URLKind").asInt();
    }
    void setSendValue(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        value = dataJson.path("SendValue");
    }
    void setResult(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        result = dataJson.path("Result");
    }
    void setValueKind(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        valueKind = dataJson.path("ValueKind").asInt();
    }
    void setDataKind(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        dataKind = dataJson.path("DataKind").asInt();
    }
    void setHeader(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        header = dataJson.path("Header");
    }
    void setHeaderKind(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        headerkind = dataJson.path("HeaderKind").asInt();
    }
    void setHeadValue(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        headvalue = dataJson.path("HeadValue");
    }
    void setHeadValueKind(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        headvaluekind = dataJson.path("HeadValueKind").asInt();
    }
    void setUser(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        user = dataJson.path("User");
    }
    void setUserKind(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        userKind = dataJson.path("UserKind").asInt();
    }
    void setPass(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        pass = dataJson.path("Pass");
    }
    void setPassKind(JsonNode dataJson){
        if(null == dataJson){
            log.error("dataJson : null");
            return;
        }
        passKind = dataJson.path("PassKind").asInt();
    }

}
