package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Identifies an Ethernet flow
 */
@ApiModel(description = "Identifies an Ethernet flow")
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class FlowInformationEthFlowDescription   {
  @JsonProperty("destMacAddr")
  private String destMacAddr;

  @JsonProperty("ethType")
  private String ethType;

  @JsonProperty("fDesc")
  private String fDesc;

  /**
   * Possible values are - DOWNLINK: The corresponding filter applies for traffic to the UE. - UPLINK: The corresponding filter applies for traffic from the UE. - BIDIRECTIONAL: The corresponding filter applies for traffic both to and from the UE. - UNSPECIFIED: The corresponding filter applies for traffic to the UE (downlink), but has no specific direction declared. The service data flow detection shall apply the filter for uplink traffic as if the filter was bidirectional. The PCF shall not use the value UNSPECIFIED in filters created by the network in NW-initiated procedures. The PCF shall only include the value UNSPECIFIED in filters in UE-initiated procedures if the same value is received from the SMF. 
   */
  public enum FDirEnum {
    DOWNLINK("DOWNLINK"),
    
    UPLINK("UPLINK"),
    
    BIDIRECTIONAL("BIDIRECTIONAL"),
    
    UNSPECIFIED("UNSPECIFIED");

    private String value;

    FDirEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static FDirEnum fromValue(String value) {
      for (FDirEnum b : FDirEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("fDir")
  private FDirEnum fDir;

  @JsonProperty("sourceMacAddr")
  private String sourceMacAddr;

  @JsonProperty("vlanTags")
  @Valid
  private List<String> vlanTags = null;

  public FlowInformationEthFlowDescription destMacAddr(String destMacAddr) {
    this.destMacAddr = destMacAddr;
    return this;
  }

  /**
   * Get destMacAddr
   * @return destMacAddr
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^([0-9a-fA-F]{2})((-[0-9a-fA-F]{2}){5})$") 
  public String getDestMacAddr() {
    return destMacAddr;
  }

  public void setDestMacAddr(String destMacAddr) {
    this.destMacAddr = destMacAddr;
  }

  public FlowInformationEthFlowDescription ethType(String ethType) {
    this.ethType = ethType;
    return this;
  }

  /**
   * Get ethType
   * @return ethType
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getEthType() {
    return ethType;
  }

  public void setEthType(String ethType) {
    this.ethType = ethType;
  }

  public FlowInformationEthFlowDescription fDesc(String fDesc) {
    this.fDesc = fDesc;
    return this;
  }

  /**
   * Defines a packet filter of an IP flow.
   * @return fDesc
  */
  @ApiModelProperty(value = "Defines a packet filter of an IP flow.")


  public String getfDesc() {
    return fDesc;
  }

  public void setfDesc(String fDesc) {
    this.fDesc = fDesc;
  }

  public FlowInformationEthFlowDescription fDir(FDirEnum fDir) {
    this.fDir = fDir;
    return this;
  }

  /**
   * Possible values are - DOWNLINK: The corresponding filter applies for traffic to the UE. - UPLINK: The corresponding filter applies for traffic from the UE. - BIDIRECTIONAL: The corresponding filter applies for traffic both to and from the UE. - UNSPECIFIED: The corresponding filter applies for traffic to the UE (downlink), but has no specific direction declared. The service data flow detection shall apply the filter for uplink traffic as if the filter was bidirectional. The PCF shall not use the value UNSPECIFIED in filters created by the network in NW-initiated procedures. The PCF shall only include the value UNSPECIFIED in filters in UE-initiated procedures if the same value is received from the SMF. 
   * @return fDir
  */
  @ApiModelProperty(value = "Possible values are - DOWNLINK: The corresponding filter applies for traffic to the UE. - UPLINK: The corresponding filter applies for traffic from the UE. - BIDIRECTIONAL: The corresponding filter applies for traffic both to and from the UE. - UNSPECIFIED: The corresponding filter applies for traffic to the UE (downlink), but has no specific direction declared. The service data flow detection shall apply the filter for uplink traffic as if the filter was bidirectional. The PCF shall not use the value UNSPECIFIED in filters created by the network in NW-initiated procedures. The PCF shall only include the value UNSPECIFIED in filters in UE-initiated procedures if the same value is received from the SMF. ")


  public FDirEnum getfDir() {
    return fDir;
  }

  public void setfDir(FDirEnum fDir) {
    this.fDir = fDir;
  }

  public FlowInformationEthFlowDescription sourceMacAddr(String sourceMacAddr) {
    this.sourceMacAddr = sourceMacAddr;
    return this;
  }

  /**
   * Get sourceMacAddr
   * @return sourceMacAddr
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^([0-9a-fA-F]{2})((-[0-9a-fA-F]{2}){5})$") 
  public String getSourceMacAddr() {
    return sourceMacAddr;
  }

  public void setSourceMacAddr(String sourceMacAddr) {
    this.sourceMacAddr = sourceMacAddr;
  }

  public FlowInformationEthFlowDescription vlanTags(List<String> vlanTags) {
    this.vlanTags = vlanTags;
    return this;
  }

  public FlowInformationEthFlowDescription addVlanTagsItem(String vlanTagsItem) {
    if (this.vlanTags == null) {
      this.vlanTags = new ArrayList<>();
    }
    this.vlanTags.add(vlanTagsItem);
    return this;
  }

  /**
   * Get vlanTags
   * @return vlanTags
  */
  @ApiModelProperty(value = "")

@Size(min=1,max=2) 
  public List<String> getVlanTags() {
    return vlanTags;
  }

  public void setVlanTags(List<String> vlanTags) {
    this.vlanTags = vlanTags;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FlowInformationEthFlowDescription flowInformationEthFlowDescription = (FlowInformationEthFlowDescription) o;
    return Objects.equals(this.destMacAddr, flowInformationEthFlowDescription.destMacAddr) &&
        Objects.equals(this.ethType, flowInformationEthFlowDescription.ethType) &&
        Objects.equals(this.fDesc, flowInformationEthFlowDescription.fDesc) &&
        Objects.equals(this.fDir, flowInformationEthFlowDescription.fDir) &&
        Objects.equals(this.sourceMacAddr, flowInformationEthFlowDescription.sourceMacAddr) &&
        Objects.equals(this.vlanTags, flowInformationEthFlowDescription.vlanTags);
  }

  @Override
  public int hashCode() {
    return Objects.hash(destMacAddr, ethType, fDesc, fDir, sourceMacAddr, vlanTags);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FlowInformationEthFlowDescription {\n");
    
    sb.append("    destMacAddr: ").append(toIndentedString(destMacAddr)).append("\n");
    sb.append("    ethType: ").append(toIndentedString(ethType)).append("\n");
    sb.append("    fDesc: ").append(toIndentedString(fDesc)).append("\n");
    sb.append("    fDir: ").append(toIndentedString(fDir)).append("\n");
    sb.append("    sourceMacAddr: ").append(toIndentedString(sourceMacAddr)).append("\n");
    sb.append("    vlanTags: ").append(toIndentedString(vlanTags)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

