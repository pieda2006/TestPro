package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.SmPolicyContextDataSubsDefQosArp;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * QosData
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class QosData   {
  @JsonProperty("qosId")
  private String qosId;

  @JsonProperty("5qi")
  private Integer _5qi;

  @JsonProperty("maxbrUl")
  private JsonNullable<String> maxbrUl = JsonNullable.undefined();

  @JsonProperty("maxbrDl")
  private JsonNullable<String> maxbrDl = JsonNullable.undefined();

  @JsonProperty("gbrUl")
  private JsonNullable<String> gbrUl = JsonNullable.undefined();

  @JsonProperty("gbrDl")
  private JsonNullable<String> gbrDl = JsonNullable.undefined();

  @JsonProperty("arp")
  private SmPolicyContextDataSubsDefQosArp arp = null;

  @JsonProperty("qnc")
  private Boolean qnc;

  @JsonProperty("priorityLevel")
  private JsonNullable<Integer> priorityLevel = JsonNullable.undefined();

  @JsonProperty("averWindow")
  private JsonNullable<Integer> averWindow = JsonNullable.undefined();

  @JsonProperty("maxDataBurstVol")
  private JsonNullable<Integer> maxDataBurstVol = JsonNullable.undefined();

  @JsonProperty("reflectiveQos")
  private Boolean reflectiveQos;

  @JsonProperty("sharingKeyDl")
  private String sharingKeyDl;

  @JsonProperty("sharingKeyUl")
  private String sharingKeyUl;

  @JsonProperty("maxPacketLossRateDl")
  private JsonNullable<Integer> maxPacketLossRateDl = JsonNullable.undefined();

  @JsonProperty("maxPacketLossRateUl")
  private JsonNullable<Integer> maxPacketLossRateUl = JsonNullable.undefined();

  @JsonProperty("defQosFlowIndication")
  private Boolean defQosFlowIndication;

  public QosData qosId(String qosId) {
    this.qosId = qosId;
    return this;
  }

  /**
   * Univocally identifies the QoS control policy data within a PDU session.
   * @return qosId
  */
  @ApiModelProperty(required = true, value = "Univocally identifies the QoS control policy data within a PDU session.")
  @NotNull


  public String getQosId() {
    return qosId;
  }

  public void setQosId(String qosId) {
    this.qosId = qosId;
  }

  public QosData _5qi(Integer _5qi) {
    this._5qi = _5qi;
    return this;
  }

  /**
   * Get _5qi
   * minimum: 0
   * maximum: 255
   * @return _5qi
  */
  @ApiModelProperty(value = "")

@Min(0) @Max(255) 
  public Integer get5qi() {
    return _5qi;
  }

  public void set5qi(Integer _5qi) {
    this._5qi = _5qi;
  }

  public QosData maxbrUl(String maxbrUl) {
    this.maxbrUl = JsonNullable.of(maxbrUl);
    return this;
  }

  /**
   * Get maxbrUl
   * @return maxbrUl
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^\\d+(\\.\\d+)? (bps|Kbps|Mbps|Gbps|Tbps)$") 
  public JsonNullable<String> getMaxbrUl() {
    return maxbrUl;
  }

  public void setMaxbrUl(JsonNullable<String> maxbrUl) {
    this.maxbrUl = maxbrUl;
  }

  public QosData maxbrDl(String maxbrDl) {
    this.maxbrDl = JsonNullable.of(maxbrDl);
    return this;
  }

  /**
   * Get maxbrDl
   * @return maxbrDl
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^\\d+(\\.\\d+)? (bps|Kbps|Mbps|Gbps|Tbps)$") 
  public JsonNullable<String> getMaxbrDl() {
    return maxbrDl;
  }

  public void setMaxbrDl(JsonNullable<String> maxbrDl) {
    this.maxbrDl = maxbrDl;
  }

  public QosData gbrUl(String gbrUl) {
    this.gbrUl = JsonNullable.of(gbrUl);
    return this;
  }

  /**
   * Get gbrUl
   * @return gbrUl
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^\\d+(\\.\\d+)? (bps|Kbps|Mbps|Gbps|Tbps)$") 
  public JsonNullable<String> getGbrUl() {
    return gbrUl;
  }

  public void setGbrUl(JsonNullable<String> gbrUl) {
    this.gbrUl = gbrUl;
  }

  public QosData gbrDl(String gbrDl) {
    this.gbrDl = JsonNullable.of(gbrDl);
    return this;
  }

  /**
   * Get gbrDl
   * @return gbrDl
  */
  @ApiModelProperty(value = "")

@Pattern(regexp="^\\d+(\\.\\d+)? (bps|Kbps|Mbps|Gbps|Tbps)$") 
  public JsonNullable<String> getGbrDl() {
    return gbrDl;
  }

  public void setGbrDl(JsonNullable<String> gbrDl) {
    this.gbrDl = gbrDl;
  }

  public QosData arp(SmPolicyContextDataSubsDefQosArp arp) {
    this.arp = arp;
    return this;
  }

  /**
   * Get arp
   * @return arp
  */
  @ApiModelProperty(value = "")

  @Valid

  public SmPolicyContextDataSubsDefQosArp getArp() {
    return arp;
  }

  public void setArp(SmPolicyContextDataSubsDefQosArp arp) {
    this.arp = arp;
  }

  public QosData qnc(Boolean qnc) {
    this.qnc = qnc;
    return this;
  }

  /**
   * Indicates whether notifications are requested from 3GPP NG-RAN when the GFBR can no longer (or again) be guaranteed for a QoS Flow during the lifetime of the QoS Flow.
   * @return qnc
  */
  @ApiModelProperty(value = "Indicates whether notifications are requested from 3GPP NG-RAN when the GFBR can no longer (or again) be guaranteed for a QoS Flow during the lifetime of the QoS Flow.")


  public Boolean getQnc() {
    return qnc;
  }

  public void setQnc(Boolean qnc) {
    this.qnc = qnc;
  }

  public QosData priorityLevel(Integer priorityLevel) {
    this.priorityLevel = JsonNullable.of(priorityLevel);
    return this;
  }

  /**
   * Get priorityLevel
   * minimum: 1
   * maximum: 127
   * @return priorityLevel
  */
  @ApiModelProperty(value = "")

@Min(1) @Max(127) 
  public JsonNullable<Integer> getPriorityLevel() {
    return priorityLevel;
  }

  public void setPriorityLevel(JsonNullable<Integer> priorityLevel) {
    this.priorityLevel = priorityLevel;
  }

  public QosData averWindow(Integer averWindow) {
    this.averWindow = JsonNullable.of(averWindow);
    return this;
  }

  /**
   * Get averWindow
   * minimum: 1
   * maximum: 4095
   * @return averWindow
  */
  @ApiModelProperty(value = "")

@Min(1) @Max(4095) 
  public JsonNullable<Integer> getAverWindow() {
    return averWindow;
  }

  public void setAverWindow(JsonNullable<Integer> averWindow) {
    this.averWindow = averWindow;
  }

  public QosData maxDataBurstVol(Integer maxDataBurstVol) {
    this.maxDataBurstVol = JsonNullable.of(maxDataBurstVol);
    return this;
  }

  /**
   * Get maxDataBurstVol
   * minimum: 1
   * maximum: 4095
   * @return maxDataBurstVol
  */
  @ApiModelProperty(value = "")

@Min(1) @Max(4095) 
  public JsonNullable<Integer> getMaxDataBurstVol() {
    return maxDataBurstVol;
  }

  public void setMaxDataBurstVol(JsonNullable<Integer> maxDataBurstVol) {
    this.maxDataBurstVol = maxDataBurstVol;
  }

  public QosData reflectiveQos(Boolean reflectiveQos) {
    this.reflectiveQos = reflectiveQos;
    return this;
  }

  /**
   * Indicates whether the QoS information is reflective for the corresponding service data flow.
   * @return reflectiveQos
  */
  @ApiModelProperty(value = "Indicates whether the QoS information is reflective for the corresponding service data flow.")


  public Boolean getReflectiveQos() {
    return reflectiveQos;
  }

  public void setReflectiveQos(Boolean reflectiveQos) {
    this.reflectiveQos = reflectiveQos;
  }

  public QosData sharingKeyDl(String sharingKeyDl) {
    this.sharingKeyDl = sharingKeyDl;
    return this;
  }

  /**
   * Indicates, by containing the same value, what PCC rules may share resource in downlink direction.
   * @return sharingKeyDl
  */
  @ApiModelProperty(value = "Indicates, by containing the same value, what PCC rules may share resource in downlink direction.")


  public String getSharingKeyDl() {
    return sharingKeyDl;
  }

  public void setSharingKeyDl(String sharingKeyDl) {
    this.sharingKeyDl = sharingKeyDl;
  }

  public QosData sharingKeyUl(String sharingKeyUl) {
    this.sharingKeyUl = sharingKeyUl;
    return this;
  }

  /**
   * Indicates, by containing the same value, what PCC rules may share resource in uplink direction.
   * @return sharingKeyUl
  */
  @ApiModelProperty(value = "Indicates, by containing the same value, what PCC rules may share resource in uplink direction.")


  public String getSharingKeyUl() {
    return sharingKeyUl;
  }

  public void setSharingKeyUl(String sharingKeyUl) {
    this.sharingKeyUl = sharingKeyUl;
  }

  public QosData maxPacketLossRateDl(Integer maxPacketLossRateDl) {
    this.maxPacketLossRateDl = JsonNullable.of(maxPacketLossRateDl);
    return this;
  }

  /**
   * Get maxPacketLossRateDl
   * minimum: 0
   * maximum: 1000
   * @return maxPacketLossRateDl
  */
  @ApiModelProperty(value = "")

@Min(0) @Max(1000) 
  public JsonNullable<Integer> getMaxPacketLossRateDl() {
    return maxPacketLossRateDl;
  }

  public void setMaxPacketLossRateDl(JsonNullable<Integer> maxPacketLossRateDl) {
    this.maxPacketLossRateDl = maxPacketLossRateDl;
  }

  public QosData maxPacketLossRateUl(Integer maxPacketLossRateUl) {
    this.maxPacketLossRateUl = JsonNullable.of(maxPacketLossRateUl);
    return this;
  }

  /**
   * Get maxPacketLossRateUl
   * minimum: 0
   * maximum: 1000
   * @return maxPacketLossRateUl
  */
  @ApiModelProperty(value = "")

@Min(0) @Max(1000) 
  public JsonNullable<Integer> getMaxPacketLossRateUl() {
    return maxPacketLossRateUl;
  }

  public void setMaxPacketLossRateUl(JsonNullable<Integer> maxPacketLossRateUl) {
    this.maxPacketLossRateUl = maxPacketLossRateUl;
  }

  public QosData defQosFlowIndication(Boolean defQosFlowIndication) {
    this.defQosFlowIndication = defQosFlowIndication;
    return this;
  }

  /**
   * Indicates that the dynamic PCC rule shall always have its binding with the QoS Flow associated with the default QoS rule
   * @return defQosFlowIndication
  */
  @ApiModelProperty(value = "Indicates that the dynamic PCC rule shall always have its binding with the QoS Flow associated with the default QoS rule")


  public Boolean getDefQosFlowIndication() {
    return defQosFlowIndication;
  }

  public void setDefQosFlowIndication(Boolean defQosFlowIndication) {
    this.defQosFlowIndication = defQosFlowIndication;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    QosData qosData = (QosData) o;
    return Objects.equals(this.qosId, qosData.qosId) &&
        Objects.equals(this._5qi, qosData._5qi) &&
        Objects.equals(this.maxbrUl, qosData.maxbrUl) &&
        Objects.equals(this.maxbrDl, qosData.maxbrDl) &&
        Objects.equals(this.gbrUl, qosData.gbrUl) &&
        Objects.equals(this.gbrDl, qosData.gbrDl) &&
        Objects.equals(this.arp, qosData.arp) &&
        Objects.equals(this.qnc, qosData.qnc) &&
        Objects.equals(this.priorityLevel, qosData.priorityLevel) &&
        Objects.equals(this.averWindow, qosData.averWindow) &&
        Objects.equals(this.maxDataBurstVol, qosData.maxDataBurstVol) &&
        Objects.equals(this.reflectiveQos, qosData.reflectiveQos) &&
        Objects.equals(this.sharingKeyDl, qosData.sharingKeyDl) &&
        Objects.equals(this.sharingKeyUl, qosData.sharingKeyUl) &&
        Objects.equals(this.maxPacketLossRateDl, qosData.maxPacketLossRateDl) &&
        Objects.equals(this.maxPacketLossRateUl, qosData.maxPacketLossRateUl) &&
        Objects.equals(this.defQosFlowIndication, qosData.defQosFlowIndication);
  }

  @Override
  public int hashCode() {
    return Objects.hash(qosId, _5qi, maxbrUl, maxbrDl, gbrUl, gbrDl, arp, qnc, priorityLevel, averWindow, maxDataBurstVol, reflectiveQos, sharingKeyDl, sharingKeyUl, maxPacketLossRateDl, maxPacketLossRateUl, defQosFlowIndication);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class QosData {\n");
    
    sb.append("    qosId: ").append(toIndentedString(qosId)).append("\n");
    sb.append("    _5qi: ").append(toIndentedString(_5qi)).append("\n");
    sb.append("    maxbrUl: ").append(toIndentedString(maxbrUl)).append("\n");
    sb.append("    maxbrDl: ").append(toIndentedString(maxbrDl)).append("\n");
    sb.append("    gbrUl: ").append(toIndentedString(gbrUl)).append("\n");
    sb.append("    gbrDl: ").append(toIndentedString(gbrDl)).append("\n");
    sb.append("    arp: ").append(toIndentedString(arp)).append("\n");
    sb.append("    qnc: ").append(toIndentedString(qnc)).append("\n");
    sb.append("    priorityLevel: ").append(toIndentedString(priorityLevel)).append("\n");
    sb.append("    averWindow: ").append(toIndentedString(averWindow)).append("\n");
    sb.append("    maxDataBurstVol: ").append(toIndentedString(maxDataBurstVol)).append("\n");
    sb.append("    reflectiveQos: ").append(toIndentedString(reflectiveQos)).append("\n");
    sb.append("    sharingKeyDl: ").append(toIndentedString(sharingKeyDl)).append("\n");
    sb.append("    sharingKeyUl: ").append(toIndentedString(sharingKeyUl)).append("\n");
    sb.append("    maxPacketLossRateDl: ").append(toIndentedString(maxPacketLossRateDl)).append("\n");
    sb.append("    maxPacketLossRateUl: ").append(toIndentedString(maxPacketLossRateUl)).append("\n");
    sb.append("    defQosFlowIndication: ").append(toIndentedString(defQosFlowIndication)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

