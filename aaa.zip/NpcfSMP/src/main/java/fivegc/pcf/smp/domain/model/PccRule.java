package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.AfSigProtocol;
import fivegc.pcf.smp.domain.model.FlowInformation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * PccRule
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class PccRule   {
  @JsonProperty("flowInfos")
  @Valid
  private List<FlowInformation> flowInfos = null;

  @JsonProperty("appId")
  private String appId;

  @JsonProperty("contVer")
  private Integer contVer;

  @JsonProperty("pccRuleId")
  private String pccRuleId;

  @JsonProperty("precedence")
  private Integer precedence;

  @JsonProperty("afSigProtocol")
  private JsonNullable<AfSigProtocol> afSigProtocol = JsonNullable.undefined();

  @JsonProperty("appReloc")
  private Boolean appReloc;

  @JsonProperty("refQosData")
  @Valid
  private List<String> refQosData = null;

  @JsonProperty("refTcData")
  @Valid
  private List<String> refTcData = null;

  @JsonProperty("refChgData")
  @Valid
  private JsonNullable<List<String>> refChgData = JsonNullable.undefined();

  @JsonProperty("refChgN3gData")
  @Valid
  private JsonNullable<List<String>> refChgN3gData = JsonNullable.undefined();

  @JsonProperty("refUmData")
  @Valid
  private JsonNullable<List<String>> refUmData = JsonNullable.undefined();

  @JsonProperty("refUmN3gData")
  @Valid
  private JsonNullable<List<String>> refUmN3gData = JsonNullable.undefined();

  @JsonProperty("refCondData")
  private JsonNullable<String> refCondData = JsonNullable.undefined();

  @JsonProperty("addrPreserInd")
  private JsonNullable<Boolean> addrPreserInd = JsonNullable.undefined();

  public PccRule flowInfos(List<FlowInformation> flowInfos) {
    this.flowInfos = flowInfos;
    return this;
  }

  public PccRule addFlowInfosItem(FlowInformation flowInfosItem) {
    if (this.flowInfos == null) {
      this.flowInfos = new ArrayList<>();
    }
    this.flowInfos.add(flowInfosItem);
    return this;
  }

  /**
   * An array of IP flow packet filter information.
   * @return flowInfos
  */
  @ApiModelProperty(value = "An array of IP flow packet filter information.")

  @Valid
@Size(min=1) 
  public List<FlowInformation> getFlowInfos() {
    return flowInfos;
  }

  public void setFlowInfos(List<FlowInformation> flowInfos) {
    this.flowInfos = flowInfos;
  }

  public PccRule appId(String appId) {
    this.appId = appId;
    return this;
  }

  /**
   * A reference to the application detection filter configured at the UPF.
   * @return appId
  */
  @ApiModelProperty(value = "A reference to the application detection filter configured at the UPF.")


  public String getAppId() {
    return appId;
  }

  public void setAppId(String appId) {
    this.appId = appId;
  }

  public PccRule contVer(Integer contVer) {
    this.contVer = contVer;
    return this;
  }

  /**
   * Represents the content version of some content.
   * @return contVer
  */
  @ApiModelProperty(value = "Represents the content version of some content.")


  public Integer getContVer() {
    return contVer;
  }

  public void setContVer(Integer contVer) {
    this.contVer = contVer;
  }

  public PccRule pccRuleId(String pccRuleId) {
    this.pccRuleId = pccRuleId;
    return this;
  }

  /**
   * Univocally identifies the PCC rule within a PDU session.
   * @return pccRuleId
  */
  @ApiModelProperty(required = true, value = "Univocally identifies the PCC rule within a PDU session.")
  @NotNull


  public String getPccRuleId() {
    return pccRuleId;
  }

  public void setPccRuleId(String pccRuleId) {
    this.pccRuleId = pccRuleId;
  }

  public PccRule precedence(Integer precedence) {
    this.precedence = precedence;
    return this;
  }

  /**
   * Get precedence
   * minimum: 0
   * @return precedence
  */
  @ApiModelProperty(value = "")

@Min(0)
  public Integer getPrecedence() {
    return precedence;
  }

  public void setPrecedence(Integer precedence) {
    this.precedence = precedence;
  }

  public PccRule afSigProtocol(AfSigProtocol afSigProtocol) {
    this.afSigProtocol = JsonNullable.of(afSigProtocol);
    return this;
  }

  /**
   * Get afSigProtocol
   * @return afSigProtocol
  */
  @ApiModelProperty(value = "")

  @Valid

  public JsonNullable<AfSigProtocol> getAfSigProtocol() {
    return afSigProtocol;
  }

  public void setAfSigProtocol(JsonNullable<AfSigProtocol> afSigProtocol) {
    this.afSigProtocol = afSigProtocol;
  }

  public PccRule appReloc(Boolean appReloc) {
    this.appReloc = appReloc;
    return this;
  }

  /**
   * Indication of application relocation possibility.
   * @return appReloc
  */
  @ApiModelProperty(value = "Indication of application relocation possibility.")


  public Boolean getAppReloc() {
    return appReloc;
  }

  public void setAppReloc(Boolean appReloc) {
    this.appReloc = appReloc;
  }

  public PccRule refQosData(List<String> refQosData) {
    this.refQosData = refQosData;
    return this;
  }

  public PccRule addRefQosDataItem(String refQosDataItem) {
    if (this.refQosData == null) {
      this.refQosData = new ArrayList<>();
    }
    this.refQosData.add(refQosDataItem);
    return this;
  }

  /**
   * A reference to the QoSData policy type decision type. It is the qosId described in subclause 5.6.2.8. (NOTE)
   * @return refQosData
  */
  @ApiModelProperty(value = "A reference to the QoSData policy type decision type. It is the qosId described in subclause 5.6.2.8. (NOTE)")

@Size(min=1,max=1) 
  public List<String> getRefQosData() {
    return refQosData;
  }

  public void setRefQosData(List<String> refQosData) {
    this.refQosData = refQosData;
  }

  public PccRule refTcData(List<String> refTcData) {
    this.refTcData = refTcData;
    return this;
  }

  public PccRule addRefTcDataItem(String refTcDataItem) {
    if (this.refTcData == null) {
      this.refTcData = new ArrayList<>();
    }
    this.refTcData.add(refTcDataItem);
    return this;
  }

  /**
   * A reference to the TrafficControlData policy decision type. It is the tcId described in subclause 5.6.2.10. (NOTE)
   * @return refTcData
  */
  @ApiModelProperty(value = "A reference to the TrafficControlData policy decision type. It is the tcId described in subclause 5.6.2.10. (NOTE)")

@Size(min=1,max=1) 
  public List<String> getRefTcData() {
    return refTcData;
  }

  public void setRefTcData(List<String> refTcData) {
    this.refTcData = refTcData;
  }

  public PccRule refChgData(List<String> refChgData) {
    this.refChgData = JsonNullable.of(refChgData);
    return this;
  }

  public PccRule addRefChgDataItem(String refChgDataItem) {
    if (this.refChgData == null || !this.refChgData.isPresent()) {
      this.refChgData = JsonNullable.of(new ArrayList<>());
    }
    this.refChgData.get().add(refChgDataItem);
    return this;
  }

  /**
   * A reference to the ChargingData policy decision type. It is the chgId described in subclause 5.6.2.11. (NOTE)
   * @return refChgData
  */
  @ApiModelProperty(value = "A reference to the ChargingData policy decision type. It is the chgId described in subclause 5.6.2.11. (NOTE)")

@Size(min=1,max=1) 
  public JsonNullable<List<String>> getRefChgData() {
    return refChgData;
  }

  public void setRefChgData(JsonNullable<List<String>> refChgData) {
    this.refChgData = refChgData;
  }

  public PccRule refChgN3gData(List<String> refChgN3gData) {
    this.refChgN3gData = JsonNullable.of(refChgN3gData);
    return this;
  }

  public PccRule addRefChgN3gDataItem(String refChgN3gDataItem) {
    if (this.refChgN3gData == null || !this.refChgN3gData.isPresent()) {
      this.refChgN3gData = JsonNullable.of(new ArrayList<>());
    }
    this.refChgN3gData.get().add(refChgN3gDataItem);
    return this;
  }

  /**
   * A reference to the ChargingData policy decision type only applicable to Non-3GPP access if \"ATSSS\" feature is supported. It is the chgId described in subclause 5.6.2.11.
   * @return refChgN3gData
  */
  @ApiModelProperty(value = "A reference to the ChargingData policy decision type only applicable to Non-3GPP access if \"ATSSS\" feature is supported. It is the chgId described in subclause 5.6.2.11.")

@Size(min=1,max=1) 
  public JsonNullable<List<String>> getRefChgN3gData() {
    return refChgN3gData;
  }

  public void setRefChgN3gData(JsonNullable<List<String>> refChgN3gData) {
    this.refChgN3gData = refChgN3gData;
  }

  public PccRule refUmData(List<String> refUmData) {
    this.refUmData = JsonNullable.of(refUmData);
    return this;
  }

  public PccRule addRefUmDataItem(String refUmDataItem) {
    if (this.refUmData == null || !this.refUmData.isPresent()) {
      this.refUmData = JsonNullable.of(new ArrayList<>());
    }
    this.refUmData.get().add(refUmDataItem);
    return this;
  }

  /**
   * A reference to UsageMonitoringData policy decision type. It is the umId described in subclause 5.6.2.12. (NOTE)
   * @return refUmData
  */
  @ApiModelProperty(value = "A reference to UsageMonitoringData policy decision type. It is the umId described in subclause 5.6.2.12. (NOTE)")

@Size(min=1,max=1) 
  public JsonNullable<List<String>> getRefUmData() {
    return refUmData;
  }

  public void setRefUmData(JsonNullable<List<String>> refUmData) {
    this.refUmData = refUmData;
  }

  public PccRule refUmN3gData(List<String> refUmN3gData) {
    this.refUmN3gData = JsonNullable.of(refUmN3gData);
    return this;
  }

  public PccRule addRefUmN3gDataItem(String refUmN3gDataItem) {
    if (this.refUmN3gData == null || !this.refUmN3gData.isPresent()) {
      this.refUmN3gData = JsonNullable.of(new ArrayList<>());
    }
    this.refUmN3gData.get().add(refUmN3gDataItem);
    return this;
  }

  /**
   * A reference to UsageMonitoringData policy decision type only applicable to Non-3GPP access if \"ATSSS\" feature is supported. It is the umId described in subclause 5.6.2.12.
   * @return refUmN3gData
  */
  @ApiModelProperty(value = "A reference to UsageMonitoringData policy decision type only applicable to Non-3GPP access if \"ATSSS\" feature is supported. It is the umId described in subclause 5.6.2.12.")

@Size(min=1,max=1) 
  public JsonNullable<List<String>> getRefUmN3gData() {
    return refUmN3gData;
  }

  public void setRefUmN3gData(JsonNullable<List<String>> refUmN3gData) {
    this.refUmN3gData = refUmN3gData;
  }

  public PccRule refCondData(String refCondData) {
    this.refCondData = JsonNullable.of(refCondData);
    return this;
  }

  /**
   * A reference to the condition data. It is the condId described in subclause 5.6.2.9.
   * @return refCondData
  */
  @ApiModelProperty(value = "A reference to the condition data. It is the condId described in subclause 5.6.2.9.")


  public JsonNullable<String> getRefCondData() {
    return refCondData;
  }

  public void setRefCondData(JsonNullable<String> refCondData) {
    this.refCondData = refCondData;
  }

  public PccRule addrPreserInd(Boolean addrPreserInd) {
    this.addrPreserInd = JsonNullable.of(addrPreserInd);
    return this;
  }

  /**
   * Get addrPreserInd
   * @return addrPreserInd
  */
  @ApiModelProperty(value = "")


  public JsonNullable<Boolean> getAddrPreserInd() {
    return addrPreserInd;
  }

  public void setAddrPreserInd(JsonNullable<Boolean> addrPreserInd) {
    this.addrPreserInd = addrPreserInd;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PccRule pccRule = (PccRule) o;
    return Objects.equals(this.flowInfos, pccRule.flowInfos) &&
        Objects.equals(this.appId, pccRule.appId) &&
        Objects.equals(this.contVer, pccRule.contVer) &&
        Objects.equals(this.pccRuleId, pccRule.pccRuleId) &&
        Objects.equals(this.precedence, pccRule.precedence) &&
        Objects.equals(this.afSigProtocol, pccRule.afSigProtocol) &&
        Objects.equals(this.appReloc, pccRule.appReloc) &&
        Objects.equals(this.refQosData, pccRule.refQosData) &&
        Objects.equals(this.refTcData, pccRule.refTcData) &&
        Objects.equals(this.refChgData, pccRule.refChgData) &&
        Objects.equals(this.refChgN3gData, pccRule.refChgN3gData) &&
        Objects.equals(this.refUmData, pccRule.refUmData) &&
        Objects.equals(this.refUmN3gData, pccRule.refUmN3gData) &&
        Objects.equals(this.refCondData, pccRule.refCondData) &&
        Objects.equals(this.addrPreserInd, pccRule.addrPreserInd);
  }

  @Override
  public int hashCode() {
    return Objects.hash(flowInfos, appId, contVer, pccRuleId, precedence, afSigProtocol, appReloc, refQosData, refTcData, refChgData, refChgN3gData, refUmData, refUmN3gData, refCondData, addrPreserInd);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PccRule {\n");
    
    sb.append("    flowInfos: ").append(toIndentedString(flowInfos)).append("\n");
    sb.append("    appId: ").append(toIndentedString(appId)).append("\n");
    sb.append("    contVer: ").append(toIndentedString(contVer)).append("\n");
    sb.append("    pccRuleId: ").append(toIndentedString(pccRuleId)).append("\n");
    sb.append("    precedence: ").append(toIndentedString(precedence)).append("\n");
    sb.append("    afSigProtocol: ").append(toIndentedString(afSigProtocol)).append("\n");
    sb.append("    appReloc: ").append(toIndentedString(appReloc)).append("\n");
    sb.append("    refQosData: ").append(toIndentedString(refQosData)).append("\n");
    sb.append("    refTcData: ").append(toIndentedString(refTcData)).append("\n");
    sb.append("    refChgData: ").append(toIndentedString(refChgData)).append("\n");
    sb.append("    refChgN3gData: ").append(toIndentedString(refChgN3gData)).append("\n");
    sb.append("    refUmData: ").append(toIndentedString(refUmData)).append("\n");
    sb.append("    refUmN3gData: ").append(toIndentedString(refUmN3gData)).append("\n");
    sb.append("    refCondData: ").append(toIndentedString(refCondData)).append("\n");
    sb.append("    addrPreserInd: ").append(toIndentedString(addrPreserInd)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

