package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonValue;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Gets or Sets SteerModeValue
 */
public enum SteerModeValue {
  
  ACTIVE_STANDBY("ACTIVE_STANDBY"),
  
  LOAD_BALANCING("LOAD_BALANCING"),
  
  SMALLEST_DELAY("SMALLEST_DELAY"),
  
  PRIORITY_BASED("PRIORITY_BASED");

  private String value;

  SteerModeValue(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static SteerModeValue fromValue(String value) {
    for (SteerModeValue b : SteerModeValue.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    throw new IllegalArgumentException("Unexpected value '" + value + "'");
  }
}

