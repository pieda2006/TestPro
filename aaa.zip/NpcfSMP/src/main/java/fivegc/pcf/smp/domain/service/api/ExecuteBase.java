package fivegc.pcf.smp.domain.service.api;

import java.util.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class ExecuteBase {

    public final static int REQUEST = 0;
    public final static int ACTION = 1;
    public final static int DISTRIBUTION = 2;
    public final static int ANSWER = 3;
    public final static int OPERATION = 4;

    protected int operationType;
    protected ArrayList<ExecuteBase> executeArray = null;
    protected JsonNode operateJson = null;
   
    private static final Logger log = LoggerFactory.getLogger(ExecuteBase.class);

 
    public ExecuteBase(){
        executeArray = new ArrayList<ExecuteBase>();
    }
    public void setOperationType(int opeType){
        operationType =opeType;
    }

    void executeAction(JsonNode reqJson, ObjectNode ansJson, ObjectNode distJson, JsonNode actionJson, JsonNode operationJson) {
    }

    void setExecuteObj(ExecuteBase execute){
        executeArray.add(execute);
    }

    int getIntFromJson(JsonNode inputJson, int kind, JsonNode reqJson, JsonNode actionJson, ObjectNode distJson, ObjectNode ansJson, JsonNode operationJson){
        JsonNode opeJson = null;
 
        switch (kind) {
            case REQUEST:
                opeJson = reqJson;
                break;
            case ACTION:
                opeJson = actionJson;
                break;
            case DISTRIBUTION:
                opeJson = distJson;
                break;
            case ANSWER:
                opeJson = ansJson;
                break;
            case OPERATION:
                opeJson = operationJson;
                break;
            default:
                log.error("Invalid Buffer kind");
                return 0; //仮設定
        }
 
        for(int count = 0; inputJson.has(count); count++){
            opeJson = opeJson.path(inputJson.get(count).asText());
        }


        if(opeJson.isInt()){
            return opeJson.asInt();
        } else if(opeJson.isTextual()){
            return Integer.parseInt((String)opeJson.asText());
        }
        return 0;
    }

    String getStringFromJson(JsonNode inputJson, int kind, JsonNode reqJson, JsonNode actionJson, ObjectNode distJson, ObjectNode ansJson, JsonNode operationJson){
        String retString = null;
        JsonNode opeJson = null;

        switch (kind) {
            case REQUEST:
                opeJson = reqJson;
                break;
            case ACTION:
                opeJson = actionJson;
                break;
            case DISTRIBUTION:
                opeJson = distJson;
                break;
            case ANSWER:
                opeJson = ansJson;
                break;
            case OPERATION:
                opeJson = operationJson;
                break;
            default:
                log.error("Invalid Buffer kind");
                return null;
        }
        
        for(int count = 0; inputJson.has(count); count++){
            opeJson = opeJson.path(inputJson.get(count).asText());
        }
        if(opeJson.isInt()){
            retString = Integer.toString(opeJson.asInt());
        } else if(opeJson.isTextual()){
            retString = opeJson.asText();
        } else if(opeJson.isObject()){
            retString = opeJson.toString();
        }
        
        return retString;
    }

    JsonNode getObjectFromJson(JsonNode inputJson, int kind, JsonNode reqJson, JsonNode actionJson, ObjectNode distJson, ObjectNode ansJson, JsonNode operationJson){

        String retString = null;
        JsonNode opeJson = null;
        ObjectMapper objectmapper = new ObjectMapper();
        int retint;
        Object opetree = null;

        switch (kind) {
            case REQUEST:
                opeJson = reqJson;
                break;
            case ACTION:
                opeJson = actionJson;
                break;
            case DISTRIBUTION:
                opeJson = distJson;
                break;
            case ANSWER:
                opeJson = ansJson;
                break;
            case OPERATION:
                opeJson = operationJson;
                break;
            default:
                log.error("Invalid Buffer kind");
                return null;
        }

        for(int count = 0; inputJson.has(count); count++){
            opeJson = opeJson.path(inputJson.get(count).asText());
        }

        return opeJson;
    }

    void setResultObject(int result, int kind, JsonNode inputJson, ObjectNode distJson, ObjectNode ansJson){
        JsonNodeFactory factory = JsonNodeFactory.instance;
        setResultObject(factory.numberNode(result), kind, inputJson, distJson, ansJson);
    }

    void setResultObject(String result, int kind, JsonNode inputJson, ObjectNode distJson, ObjectNode ansJson){
        JsonNodeFactory factory = JsonNodeFactory.instance;
        setResultObject(factory.textNode(result), kind, inputJson, distJson, ansJson);
    }

    void setResultObject(Boolean result, int kind, JsonNode inputJson, ObjectNode distJson, ObjectNode ansJson){
        JsonNodeFactory factory = JsonNodeFactory.instance;
        setResultObject(factory.booleanNode(result), kind, inputJson, distJson, ansJson);
    }

    void setResultObject(JsonNode result, int kind, JsonNode inputJson, ObjectNode distJson, ObjectNode ansJson){
        ObjectNode opeJson = null;
        ObjectNode nextOpeJson = null;
        JsonNode jsonNode = null;
        
        switch (kind) {
            case DISTRIBUTION:
                opeJson = distJson;
                break;
            case ANSWER:
                opeJson = ansJson;
                break;
            default:
                log.error("Invalid Buffer kind");
                return;
        }
        int count = 0; 
        for(count = 0; inputJson.has(count); count++){
            if(count != 0){
            	if(nextOpeJson == null){
            	    nextOpeJson = opeJson.putObject(inputJson.get(count-1).asText());
            	}
            	opeJson = nextOpeJson;
            }
            jsonNode = opeJson.path(inputJson.get(count).asText());
            if(!jsonNode.isMissingNode()){
                if(jsonNode instanceof ObjectNode){
            	    nextOpeJson = (ObjectNode)jsonNode;
                } else {
                    log.error("It is not an ObjectNode");
                    return;
                }
            } else {
               nextOpeJson = null; 
            }
        }
        if(nextOpeJson == null){
        	opeJson.put(inputJson.get(count-1).asText(),result);
        } else {
        	opeJson.replace(inputJson.get(count-1).asText(),result);
        }
    }
    /**
     * Operation動作用の設定の保持。
     * @author	ikeda_tss
     * @version sprint02
     * @since sprint02
     * @param JsonNode operationjson オペレーション実行時に必要なJsonデータ
     * @return 無
     */
     
    public void setParameterFromJson(JsonNode operationjson){
        operateJson = operationjson;
    }
    
}
