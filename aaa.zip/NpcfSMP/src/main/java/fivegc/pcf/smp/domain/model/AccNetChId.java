package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * AccNetChId
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class AccNetChId   {
  @JsonProperty("accNetChaIdValue")
  private Integer accNetChaIdValue;

  @JsonProperty("refPccRuleIds")
  @Valid
  private List<String> refPccRuleIds = null;

  @JsonProperty("sessionChScope")
  private Boolean sessionChScope;

  public AccNetChId accNetChaIdValue(Integer accNetChaIdValue) {
    this.accNetChaIdValue = accNetChaIdValue;
    return this;
  }

  /**
   * Get accNetChaIdValue
   * minimum: 0
   * @return accNetChaIdValue
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Min(0)
  public Integer getAccNetChaIdValue() {
    return accNetChaIdValue;
  }

  public void setAccNetChaIdValue(Integer accNetChaIdValue) {
    this.accNetChaIdValue = accNetChaIdValue;
  }

  public AccNetChId refPccRuleIds(List<String> refPccRuleIds) {
    this.refPccRuleIds = refPccRuleIds;
    return this;
  }

  public AccNetChId addRefPccRuleIdsItem(String refPccRuleIdsItem) {
    if (this.refPccRuleIds == null) {
      this.refPccRuleIds = new ArrayList<>();
    }
    this.refPccRuleIds.add(refPccRuleIdsItem);
    return this;
  }

  /**
   * Contains the identifier of the PCC rule(s) associated to the provided Access Network Charging Identifier.
   * @return refPccRuleIds
  */
  @ApiModelProperty(value = "Contains the identifier of the PCC rule(s) associated to the provided Access Network Charging Identifier.")

@Size(min=1) 
  public List<String> getRefPccRuleIds() {
    return refPccRuleIds;
  }

  public void setRefPccRuleIds(List<String> refPccRuleIds) {
    this.refPccRuleIds = refPccRuleIds;
  }

  public AccNetChId sessionChScope(Boolean sessionChScope) {
    this.sessionChScope = sessionChScope;
    return this;
  }

  /**
   * When it is included and set to true, indicates the Access Network Charging Identifier applies to the whole PDU Session
   * @return sessionChScope
  */
  @ApiModelProperty(value = "When it is included and set to true, indicates the Access Network Charging Identifier applies to the whole PDU Session")


  public Boolean getSessionChScope() {
    return sessionChScope;
  }

  public void setSessionChScope(Boolean sessionChScope) {
    this.sessionChScope = sessionChScope;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AccNetChId accNetChId = (AccNetChId) o;
    return Objects.equals(this.accNetChaIdValue, accNetChId.accNetChaIdValue) &&
        Objects.equals(this.refPccRuleIds, accNetChId.refPccRuleIds) &&
        Objects.equals(this.sessionChScope, accNetChId.sessionChScope);
  }

  @Override
  public int hashCode() {
    return Objects.hash(accNetChaIdValue, refPccRuleIds, sessionChScope);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AccNetChId {\n");
    
    sb.append("    accNetChaIdValue: ").append(toIndentedString(accNetChaIdValue)).append("\n");
    sb.append("    refPccRuleIds: ").append(toIndentedString(refPccRuleIds)).append("\n");
    sb.append("    sessionChScope: ").append(toIndentedString(sessionChScope)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

