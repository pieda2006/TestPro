package fivegc.pcf.smp.domain.service.api;

import java.sql.ResultSet;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DataManager {

    public static final int OK = 0;
    public static final int NG = 1;

    private static DataManager myinstance = null;
    private static final Logger log = LoggerFactory.getLogger(DataManager.class);

    private String url = "jdbc:mysql://localhost:11200/PCF";
    private String user = "root";
    private String pass = "my-secret-pw";
    private String table = "CONFIG";
    //private DataBaseAccesser database = null;
    private JsonNode configValue = null;

    public static DataManager getInstance(){
        if(myinstance == null){
            myinstance = new DataManager();
        }
        return myinstance;
    }

    public DataManager() {
        //DBアクセス
        DbAccessController.PreparationAccess();

        String sql = "select * from " + table + ";";

        try {
            DbAccessController.execDbAccess(sql);
            ResultSet result = DbAccessController.getResultSet();

            boolean boolvalue = result.next();
            ObjectMapper objmapper = new ObjectMapper();
            configValue = objmapper.readTree(result.getString(2));

            log.debug("Config : " + configValue.toString());

        } catch(Exception e) {
            log.error("### execDbAccess Exception ###" , e );
            configValue = null;
        }
    }

    public JsonNode getConfigValue(){
        return configValue;
    } 

    public void ConnectionClose() {
        DbAccessController.smfConnectionClose();
    }

    public ResultSet getData(String table, String pramName, String keyValue){
        String sql = "select * from " + table + " where " + pramName + " = '" + keyValue + "';" ;

        try {
            DbAccessController.execDbAccess(sql);
        } catch(Exception e) {
              log.error("### execDbAccess Exception ###" , e );
        }
        return DbAccessController.getResultSet();
    }
    public ResultSet getData(String table, String pramName, int keyValue){
        String sql = "select * from " + table + " where " + pramName + " = " + keyValue + ";" ;
        try {
            DbAccessController.execDbAccess(sql);
        } catch(Exception e) {
            log.error("### execDbAccess Exception ###" , e );
        }
        return DbAccessController.getResultSet();
    }
    public ResultSet getData(String table){
        String sql = "select * from " + table + ";" ;
        try {
            DbAccessController.execDbAccess(sql);
        } catch(Exception e) {
            log.error("### execDbAccess Exception ###" , e );
        }
        return DbAccessController.getResultSet();
    }
    public int setData(String table, String paramName, String keyValue, String setData){
        String sql = "insert into " + table + "(" + paramName + ", VALUE) values('" + keyValue + "', '" + setData + "');";
        try {
            DbAccessController.execDbAccess(sql);
        } catch(Exception e) {
            log.error("### execDbAccess Exception ###" , e );
        }
        return OK;
    }
    public int setData(String table, String paramName, int keyValue, String setData){
        String sql = "insert into " + table + "(" + paramName + ",VALUE) values(" + keyValue + ", '" + setData + "');";
        try {
            DbAccessController.execDbAccess(sql);
        } catch(Exception e) {
            log.error("### execDbAccess Exception ###" , e );
        }
        return OK;
    }
    public int upData(String table, String paramName, String keyValue, String setData){
        String sql = "update " + table + " set VALUE='" + setData + "' where " + paramName + "='" + keyValue + "';";
        try {
            DbAccessController.execDbAccess(sql);
        } catch(Exception e) {
            log.error("### execDbAccess Exception ###" , e );
        }
        return OK;
    }
    public int upData(String table, String paramName, int keyValue, String setData){
        String sql = "update " + table + " set VALUE='" + setData + "' where " + paramName + "=" + keyValue + ";";
        try {
            DbAccessController.execDbAccess(sql);
        } catch(Exception e) {
            log.error("### execDbAccess Exception ###" , e );
        }
        return OK;
    }
    public int delData(String table, String paramName, String keyValue){
        String sql = "delete from " + table + " where " + paramName + "='" + keyValue + "';";
        try {
            DbAccessController.execDbAccess(sql);
        } catch(Exception e) {
            log.error("### execDbAccess Exception ###" , e );
        }
        return OK;
    }
    public int delData(String table, String paramName, int keyValue){
        String sql = "delete from " + table + " where " + paramName + "=" + keyValue + ";";
        try {
            DbAccessController.execDbAccess(sql);
        } catch(Exception e) {
            log.error("### execDbAccess Exception ###" , e );
        }
        return OK;
    }
}
