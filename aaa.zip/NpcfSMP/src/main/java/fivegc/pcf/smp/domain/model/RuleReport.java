package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import fivegc.pcf.smp.domain.model.FailureCode;
import fivegc.pcf.smp.domain.model.RanNasRelCause;
import fivegc.pcf.smp.domain.model.RuleStatus;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RuleReport
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class RuleReport   {
  @JsonProperty("pccRuleIds")
  @Valid
  private List<String> pccRuleIds = new ArrayList<>();

  @JsonProperty("ruleStatus")
  private RuleStatus ruleStatus;

  @JsonProperty("contVers")
  @Valid
  private List<Integer> contVers = null;

  @JsonProperty("failureCode")
  private FailureCode failureCode;

  /**
   * Gets or Sets finUnitAct
   */
  public enum FinUnitActEnum {
    TERMINATE("TERMINATE"),
    
    REDIRECT("REDIRECT"),
    
    RESTRICT_ACCESS("RESTRICT_ACCESS");

    private String value;

    FinUnitActEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static FinUnitActEnum fromValue(String value) {
      for (FinUnitActEnum b : FinUnitActEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("finUnitAct")
  private FinUnitActEnum finUnitAct;

  @JsonProperty("ranNasRelCauses")
  @Valid
  private List<RanNasRelCause> ranNasRelCauses = null;

  public RuleReport pccRuleIds(List<String> pccRuleIds) {
    this.pccRuleIds = pccRuleIds;
    return this;
  }

  public RuleReport addPccRuleIdsItem(String pccRuleIdsItem) {
    this.pccRuleIds.add(pccRuleIdsItem);
    return this;
  }

  /**
   * Contains the identifier of the affected PCC rule(s).
   * @return pccRuleIds
  */
  @ApiModelProperty(required = true, value = "Contains the identifier of the affected PCC rule(s).")
  @NotNull

@Size(min=1) 
  public List<String> getPccRuleIds() {
    return pccRuleIds;
  }

  public void setPccRuleIds(List<String> pccRuleIds) {
    this.pccRuleIds = pccRuleIds;
  }

  public RuleReport ruleStatus(RuleStatus ruleStatus) {
    this.ruleStatus = ruleStatus;
    return this;
  }

  /**
   * Get ruleStatus
   * @return ruleStatus
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public RuleStatus getRuleStatus() {
    return ruleStatus;
  }

  public void setRuleStatus(RuleStatus ruleStatus) {
    this.ruleStatus = ruleStatus;
  }

  public RuleReport contVers(List<Integer> contVers) {
    this.contVers = contVers;
    return this;
  }

  public RuleReport addContVersItem(Integer contVersItem) {
    if (this.contVers == null) {
      this.contVers = new ArrayList<>();
    }
    this.contVers.add(contVersItem);
    return this;
  }

  /**
   * Indicates the version of a PCC rule.
   * @return contVers
  */
  @ApiModelProperty(value = "Indicates the version of a PCC rule.")

@Size(min=1) 
  public List<Integer> getContVers() {
    return contVers;
  }

  public void setContVers(List<Integer> contVers) {
    this.contVers = contVers;
  }

  public RuleReport failureCode(FailureCode failureCode) {
    this.failureCode = failureCode;
    return this;
  }

  /**
   * Get failureCode
   * @return failureCode
  */
  @ApiModelProperty(value = "")

  @Valid

  public FailureCode getFailureCode() {
    return failureCode;
  }

  public void setFailureCode(FailureCode failureCode) {
    this.failureCode = failureCode;
  }

  public RuleReport finUnitAct(FinUnitActEnum finUnitAct) {
    this.finUnitAct = finUnitAct;
    return this;
  }

  /**
   * Get finUnitAct
   * @return finUnitAct
  */
  @ApiModelProperty(value = "")


  public FinUnitActEnum getFinUnitAct() {
    return finUnitAct;
  }

  public void setFinUnitAct(FinUnitActEnum finUnitAct) {
    this.finUnitAct = finUnitAct;
  }

  public RuleReport ranNasRelCauses(List<RanNasRelCause> ranNasRelCauses) {
    this.ranNasRelCauses = ranNasRelCauses;
    return this;
  }

  public RuleReport addRanNasRelCausesItem(RanNasRelCause ranNasRelCausesItem) {
    if (this.ranNasRelCauses == null) {
      this.ranNasRelCauses = new ArrayList<>();
    }
    this.ranNasRelCauses.add(ranNasRelCausesItem);
    return this;
  }

  /**
   * indicates the RAN or NAS release cause code information.
   * @return ranNasRelCauses
  */
  @ApiModelProperty(value = "indicates the RAN or NAS release cause code information.")

  @Valid
@Size(min=1) 
  public List<RanNasRelCause> getRanNasRelCauses() {
    return ranNasRelCauses;
  }

  public void setRanNasRelCauses(List<RanNasRelCause> ranNasRelCauses) {
    this.ranNasRelCauses = ranNasRelCauses;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RuleReport ruleReport = (RuleReport) o;
    return Objects.equals(this.pccRuleIds, ruleReport.pccRuleIds) &&
        Objects.equals(this.ruleStatus, ruleReport.ruleStatus) &&
        Objects.equals(this.contVers, ruleReport.contVers) &&
        Objects.equals(this.failureCode, ruleReport.failureCode) &&
        Objects.equals(this.finUnitAct, ruleReport.finUnitAct) &&
        Objects.equals(this.ranNasRelCauses, ruleReport.ranNasRelCauses);
  }

  @Override
  public int hashCode() {
    return Objects.hash(pccRuleIds, ruleStatus, contVers, failureCode, finUnitAct, ranNasRelCauses);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RuleReport {\n");
    
    sb.append("    pccRuleIds: ").append(toIndentedString(pccRuleIds)).append("\n");
    sb.append("    ruleStatus: ").append(toIndentedString(ruleStatus)).append("\n");
    sb.append("    contVers: ").append(toIndentedString(contVers)).append("\n");
    sb.append("    failureCode: ").append(toIndentedString(failureCode)).append("\n");
    sb.append("    finUnitAct: ").append(toIndentedString(finUnitAct)).append("\n");
    sb.append("    ranNasRelCauses: ").append(toIndentedString(ranNasRelCauses)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

