package fivegc.pcf.smp.domain.service.api;


import java.util.HashMap;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.nio.charset.StandardCharsets;
import java.sql.ResultSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

import org.springframework.stereotype.Repository;
import org.springframework.context.annotation.Scope;

@Scope("prototype")
@Repository
class ExecuteDBAccess extends DataAcsessBase{

    private static final Logger log = LoggerFactory.getLogger(ExecuteDBAccess.class);

    void executeAction(JsonNode reqJson, ObjectNode ansJson, ObjectNode distJson, JsonNode actionJson, JsonNode operationJson){

        DataManager datamanage =  DataManager.getInstance();

        JsonNode opeJson;
        Object opetree;
        String opetable = null;
        String opekey = null;
        String opedata = null;
        String opevalue = null;
        int opeintkey;

        ObjectMapper objectmap = new ObjectMapper();
        opetable = getStringFromJson(tableName, tableKind, reqJson, actionJson, distJson, ansJson, operationJson);
        opekey = getStringFromJson(key, keyKind, reqJson, actionJson, distJson, ansJson, operationJson);

        log.debug("value : " + value.toString());

        opevalue = getStringFromJson(value, valueKind, reqJson, actionJson, distJson, ansJson, operationJson);

        if(null == opevalue){
            log.error("opevalue : null");
            return;
        }

        log.debug("opevalue : " + opevalue.toString());

        if(operationType != GET && operationType != DELETE){
            opedata = getStringFromJson(dataJson, dataKind, reqJson, actionJson, distJson, ansJson, operationJson);
        }

        ResultSet resultSet = null;

        if(operationType == GET){
            if(keyType == INTKEY){
                resultSet = datamanage.getData(opetable, opekey, Integer.parseInt(opevalue));
            } else {
                resultSet = datamanage.getData(opetable, opekey, opevalue);
            }
            try {
                resultSet.next();

                ObjectMapper objectmapper = new ObjectMapper();
                JsonNode jsonresult = objectmapper.readTree(resultSet.getString(2));

                log.debug("jsonresult : " + jsonresult.toString());
                log.debug("dataJson : " + dataJson.toString());

                setResultObject(jsonresult, dataKind, dataJson ,distJson, ansJson);

                log.debug("ansJson : " + ansJson.toString());

            } catch (Exception e){
                log.error(e.toString());
            }

        } else if(operationType == INSERT){
            if(keyType == INTKEY){
                datamanage.setData(opetable, opekey, Integer.parseInt(opevalue), opedata);
            } else {
                datamanage.setData(opetable, opekey, opevalue, opedata);
            }
        } else if(operationType == UPDATE){
            if(keyType == INTKEY){
                datamanage.upData(opetable, opekey, Integer.parseInt(opevalue), opedata);
            } else {
                datamanage.upData(opetable, opekey, opevalue, opedata);
            }
        } else if(operationType == DELETE){
            if(keyType == INTKEY){
                datamanage.delData(opetable, opekey, Integer.parseInt(opevalue));
            } else {
                datamanage.delData(opetable, opekey, opevalue);
            }
        }

    }


}

