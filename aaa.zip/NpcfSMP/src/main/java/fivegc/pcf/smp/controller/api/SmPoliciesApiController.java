package fivegc.pcf.smp.controller.api;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.http.HttpHeaders;
import java.net.URI;

import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fivegc.pcf.smp.domain.model.SmPolicyDecision;
import fivegc.pcf.smp.domain.model.SmPolicyContextData;
import fivegc.pcf.smp.domain.service.api.ServiceControl;

import fivegc.pcf.smp.domain.model.InlineResponse400;
import fivegc.pcf.smp.domain.model.SmPolicyControl;
import fivegc.pcf.smp.domain.model.SmPolicyDeleteData;
import io.swagger.annotations.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.beans.factory.annotation.Autowired;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;

@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

@Controller
@RequestMapping("${openapi.npcfSMPolicyControl.base-path:/npcf-smpolicycontrol/v1}")
public class SmPoliciesApiController implements SmPoliciesApi {

    private final NativeWebRequest request;
    
    private static final Logger log = LoggerFactory.getLogger(SmPoliciesApiController.class);

    @org.springframework.beans.factory.annotation.Autowired
    public SmPoliciesApiController(NativeWebRequest request) {
        this.request = request;
    }

    @Override
    public Optional<NativeWebRequest> getRequest() {
        return Optional.ofNullable(request);
    }
    
    @Override
    public ResponseEntity<JsonNode> smPoliciesPost(@ApiParam(value = "" ,required=true )  @Valid @RequestBody JsonNode smPolicyContextData) {

        JsonNodeFactory factory = JsonNodeFactory.instance;
        ObjectNode reqJson = new ObjectNode(factory);
        reqJson.put("Request",smPolicyContextData);
        ServiceControl serviceCtl = ServiceControl.getInstance();
        JsonNode responseJson = serviceCtl.decideAction("/sm-policies",reqJson );
        String locationStr = responseJson.path("Header").path("LocationHeader").asText();

        URI locationURI = null;
        try {
            locationURI = new URI(locationStr);
        } catch (Exception e) {
            log.error(e.toString());
        }
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.setLocation(locationURI);
        return new ResponseEntity(responseJson.path("Response"),responseHeaders,HttpStatus.CREATED);

    }

    @Override
    public ResponseEntity<Void> smPoliciesSmPolicyIdDeletePost(@ApiParam(value = "Identifier of a policy association",required=true) @PathVariable("smPolicyId") String smPolicyId,@ApiParam(value = "" ,required=true )  @Valid @RequestBody JsonNode smPolicyDeleteData) {

        log.debug("====== Recieve Delete ======");

        JsonNodeFactory factory = JsonNodeFactory.instance;
        ObjectNode reqJson = new ObjectNode(factory);
        reqJson.put("Request",smPolicyDeleteData);
        reqJson.put("smPolicyId",smPolicyId);
        ServiceControl serviceCtl = ServiceControl.getInstance();
        JsonNode responseJson = serviceCtl.decideAction("/sm-policies/delete",reqJson );

        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }

}
