package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import fivegc.pcf.smp.domain.model.FlowDirection;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * PacketFilterInfo
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class PacketFilterInfo   {
  @JsonProperty("packFiltId")
  private String packFiltId;

  @JsonProperty("packFiltCont")
  private String packFiltCont;

  @JsonProperty("tosTrafficClass")
  private String tosTrafficClass;

  @JsonProperty("spi")
  private String spi;

  @JsonProperty("flowLabel")
  private String flowLabel;

  @JsonProperty("flowDirection")
  private FlowDirection flowDirection;

  public PacketFilterInfo packFiltId(String packFiltId) {
    this.packFiltId = packFiltId;
    return this;
  }

  /**
   * An identifier of packet filter.
   * @return packFiltId
  */
  @ApiModelProperty(value = "An identifier of packet filter.")


  public String getPackFiltId() {
    return packFiltId;
  }

  public void setPackFiltId(String packFiltId) {
    this.packFiltId = packFiltId;
  }

  public PacketFilterInfo packFiltCont(String packFiltCont) {
    this.packFiltCont = packFiltCont;
    return this;
  }

  /**
   * Defines a packet filter for an IP flow.Refer to subclause 5.3.54 of 3GPP TS 29.212 [23] for encoding.
   * @return packFiltCont
  */
  @ApiModelProperty(value = "Defines a packet filter for an IP flow.Refer to subclause 5.3.54 of 3GPP TS 29.212 [23] for encoding.")


  public String getPackFiltCont() {
    return packFiltCont;
  }

  public void setPackFiltCont(String packFiltCont) {
    this.packFiltCont = packFiltCont;
  }

  public PacketFilterInfo tosTrafficClass(String tosTrafficClass) {
    this.tosTrafficClass = tosTrafficClass;
    return this;
  }

  /**
   * Contains the Ipv4 Type-of-Service and mask field or the Ipv6 Traffic-Class field and mask field.
   * @return tosTrafficClass
  */
  @ApiModelProperty(value = "Contains the Ipv4 Type-of-Service and mask field or the Ipv6 Traffic-Class field and mask field.")


  public String getTosTrafficClass() {
    return tosTrafficClass;
  }

  public void setTosTrafficClass(String tosTrafficClass) {
    this.tosTrafficClass = tosTrafficClass;
  }

  public PacketFilterInfo spi(String spi) {
    this.spi = spi;
    return this;
  }

  /**
   * The security parameter index of the IPSec packet.
   * @return spi
  */
  @ApiModelProperty(value = "The security parameter index of the IPSec packet.")


  public String getSpi() {
    return spi;
  }

  public void setSpi(String spi) {
    this.spi = spi;
  }

  public PacketFilterInfo flowLabel(String flowLabel) {
    this.flowLabel = flowLabel;
    return this;
  }

  /**
   * The Ipv6 flow label header field.
   * @return flowLabel
  */
  @ApiModelProperty(value = "The Ipv6 flow label header field.")


  public String getFlowLabel() {
    return flowLabel;
  }

  public void setFlowLabel(String flowLabel) {
    this.flowLabel = flowLabel;
  }

  public PacketFilterInfo flowDirection(FlowDirection flowDirection) {
    this.flowDirection = flowDirection;
    return this;
  }

  /**
   * Get flowDirection
   * @return flowDirection
  */
  @ApiModelProperty(value = "")

  @Valid

  public FlowDirection getFlowDirection() {
    return flowDirection;
  }

  public void setFlowDirection(FlowDirection flowDirection) {
    this.flowDirection = flowDirection;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PacketFilterInfo packetFilterInfo = (PacketFilterInfo) o;
    return Objects.equals(this.packFiltId, packetFilterInfo.packFiltId) &&
        Objects.equals(this.packFiltCont, packetFilterInfo.packFiltCont) &&
        Objects.equals(this.tosTrafficClass, packetFilterInfo.tosTrafficClass) &&
        Objects.equals(this.spi, packetFilterInfo.spi) &&
        Objects.equals(this.flowLabel, packetFilterInfo.flowLabel) &&
        Objects.equals(this.flowDirection, packetFilterInfo.flowDirection);
  }

  @Override
  public int hashCode() {
    return Objects.hash(packFiltId, packFiltCont, tosTrafficClass, spi, flowLabel, flowDirection);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PacketFilterInfo {\n");
    
    sb.append("    packFiltId: ").append(toIndentedString(packFiltId)).append("\n");
    sb.append("    packFiltCont: ").append(toIndentedString(packFiltCont)).append("\n");
    sb.append("    tosTrafficClass: ").append(toIndentedString(tosTrafficClass)).append("\n");
    sb.append("    spi: ").append(toIndentedString(spi)).append("\n");
    sb.append("    flowLabel: ").append(toIndentedString(flowLabel)).append("\n");
    sb.append("    flowDirection: ").append(toIndentedString(flowDirection)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

