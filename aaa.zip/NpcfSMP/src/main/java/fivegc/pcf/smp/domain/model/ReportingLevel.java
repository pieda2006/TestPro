package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import io.swagger.annotations.ApiModel;
import com.fasterxml.jackson.annotation.JsonValue;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Possible values are - SER_ID_LEVEL: Indicates that the usage shall be reported on service id and rating group combination level. - RAT_GR_LEVEL: Indicates that the usage shall be reported on rating group level. - SPON_CON_LEVEL: Indicates that the usage shall be reported on sponsor identity and rating group combination level. 
 */
public enum ReportingLevel {
  
  SER_ID_LEVEL("SER_ID_LEVEL"),
  
  RAT_GR_LEVEL("RAT_GR_LEVEL"),
  
  SPON_CON_LEVEL("SPON_CON_LEVEL");

  private String value;

  ReportingLevel(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static ReportingLevel fromValue(String value) {
    for (ReportingLevel b : ReportingLevel.values()) {
      if (b.value.equals(value)) {
        return b;
      }
    }
    return null;
  }
}

