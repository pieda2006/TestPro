package fivegc.pcf.smp.domain.service.api;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
class ExecuteOperationJson extends ExecuteBase {

    private static final Logger log = LoggerFactory.getLogger(ExecuteOperationJson.class);
    private JsonNode paramName;
    private JsonNode paramValue;
    private int nameKind;
    private int valueKind;
    private int paramType;
    public final static int TYPEINT = 0;
    public final static int TYPESTRING = 1;
    public final static int TYPENULL = 2;
    public final static int TYPEOBJECT = 3;

    public ExecuteOperationJson(){
    }

    void executeAction(JsonNode reqJson, ObjectNode ansJson, ObjectNode distJson, JsonNode actionJson, JsonNode operationJson) {
        JsonNode dataObject = getObjectFromJson(paramName, nameKind, reqJson, actionJson, distJson, ansJson, operationJson);
        setResultObject(dataObject, valueKind, paramValue, distJson, ansJson);
    }

    public void setParameterFromJson(JsonNode operationjson){
        paramName = operationjson.path("ParamName");
        paramValue = operationjson.path("ParamValue");
        nameKind = operationjson.path("ParamKind").asInt();
        valueKind = operationjson.path("ValueKind").asInt();
        paramType = operationjson.path("ParamType").asInt();
    }
}
