package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import fivegc.pcf.smp.domain.model.RedirectInformation;
import fivegc.pcf.smp.domain.model.SteeringFunctionality;
import fivegc.pcf.smp.domain.model.SteeringMode;
import fivegc.pcf.smp.domain.model.TrafficControlDataRouteToLocs;
import fivegc.pcf.smp.domain.model.UpPathChgEvent;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * TrafficControlData
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class TrafficControlData   {
  @JsonProperty("tcId")
  private String tcId;

  /**
   * Gets or Sets flowStatus
   */
  public enum FlowStatusEnum {
    ENABLED_UPLINK("ENABLED-UPLINK"),
    
    ENABLED_DOWNLINK("ENABLED-DOWNLINK"),
    
    ENABLED("ENABLED"),
    
    DISABLED("DISABLED"),
    
    REMOVED("REMOVED");

    private String value;

    FlowStatusEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static FlowStatusEnum fromValue(String value) {
      for (FlowStatusEnum b : FlowStatusEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("flowStatus")
  private FlowStatusEnum flowStatus;

  @JsonProperty("redirectInfo")
  @Valid
  private List<RedirectInformation> redirectInfo = null;

  @JsonProperty("muteNotif")
  private Boolean muteNotif;

  @JsonProperty("trafficSteeringPolIdDl")
  private JsonNullable<String> trafficSteeringPolIdDl = JsonNullable.undefined();

  @JsonProperty("trafficSteeringPolIdUl")
  private JsonNullable<String> trafficSteeringPolIdUl = JsonNullable.undefined();

  @JsonProperty("routeToLocs")
  @Valid
  private List<TrafficControlDataRouteToLocs> routeToLocs = null;

  @JsonProperty("upPathChgEvent")
  private JsonNullable<UpPathChgEvent> upPathChgEvent = JsonNullable.undefined();

  @JsonProperty("steerFun")
  private SteeringFunctionality steerFun;

  @JsonProperty("steerModeDl")
  private SteeringMode steerModeDl = null;

  @JsonProperty("steerModeUl")
  private SteeringMode steerModeUl = null;

  public TrafficControlData tcId(String tcId) {
    this.tcId = tcId;
    return this;
  }

  /**
   * Univocally identifies the traffic control policy data within a PDU session.
   * @return tcId
  */
  @ApiModelProperty(required = true, value = "Univocally identifies the traffic control policy data within a PDU session.")
  @NotNull


  public String getTcId() {
    return tcId;
  }

  public void setTcId(String tcId) {
    this.tcId = tcId;
  }

  public TrafficControlData flowStatus(FlowStatusEnum flowStatus) {
    this.flowStatus = flowStatus;
    return this;
  }

  /**
   * Get flowStatus
   * @return flowStatus
  */
  @ApiModelProperty(value = "")


  public FlowStatusEnum getFlowStatus() {
    return flowStatus;
  }

  public void setFlowStatus(FlowStatusEnum flowStatus) {
    this.flowStatus = flowStatus;
  }

  public TrafficControlData redirectInfo(List<RedirectInformation> redirectInfo) {
    this.redirectInfo = redirectInfo;
    return this;
  }

  public TrafficControlData addRedirectInfoItem(RedirectInformation redirectInfoItem) {
    if (this.redirectInfo == null) {
      this.redirectInfo = new ArrayList<>();
    }
    this.redirectInfo.add(redirectInfoItem);
    return this;
  }

  /**
   * Get redirectInfo
   * @return redirectInfo
  */
  @ApiModelProperty(value = "")

  @Valid

  public List<RedirectInformation> getRedirectInfo() {
    return redirectInfo;
  }

  public void setRedirectInfo(List<RedirectInformation> redirectInfo) {
    this.redirectInfo = redirectInfo;
  }

  public TrafficControlData muteNotif(Boolean muteNotif) {
    this.muteNotif = muteNotif;
    return this;
  }

  /**
   * Indicates whether applicat'on's start or stop notification is to be muted.
   * @return muteNotif
  */
  @ApiModelProperty(value = "Indicates whether applicat'on's start or stop notification is to be muted.")


  public Boolean getMuteNotif() {
    return muteNotif;
  }

  public void setMuteNotif(Boolean muteNotif) {
    this.muteNotif = muteNotif;
  }

  public TrafficControlData trafficSteeringPolIdDl(String trafficSteeringPolIdDl) {
    this.trafficSteeringPolIdDl = JsonNullable.of(trafficSteeringPolIdDl);
    return this;
  }

  /**
   * Reference to a pre-configured traffic steering policy for downlink traffic at the SMF.
   * @return trafficSteeringPolIdDl
  */
  @ApiModelProperty(value = "Reference to a pre-configured traffic steering policy for downlink traffic at the SMF.")


  public JsonNullable<String> getTrafficSteeringPolIdDl() {
    return trafficSteeringPolIdDl;
  }

  public void setTrafficSteeringPolIdDl(JsonNullable<String> trafficSteeringPolIdDl) {
    this.trafficSteeringPolIdDl = trafficSteeringPolIdDl;
  }

  public TrafficControlData trafficSteeringPolIdUl(String trafficSteeringPolIdUl) {
    this.trafficSteeringPolIdUl = JsonNullable.of(trafficSteeringPolIdUl);
    return this;
  }

  /**
   * Reference to a pre-configured traffic steering policy for uplink traffic at the SMF.
   * @return trafficSteeringPolIdUl
  */
  @ApiModelProperty(value = "Reference to a pre-configured traffic steering policy for uplink traffic at the SMF.")


  public JsonNullable<String> getTrafficSteeringPolIdUl() {
    return trafficSteeringPolIdUl;
  }

  public void setTrafficSteeringPolIdUl(JsonNullable<String> trafficSteeringPolIdUl) {
    this.trafficSteeringPolIdUl = trafficSteeringPolIdUl;
  }

  public TrafficControlData routeToLocs(List<TrafficControlDataRouteToLocs> routeToLocs) {
    this.routeToLocs = routeToLocs;
    return this;
  }

  public TrafficControlData addRouteToLocsItem(TrafficControlDataRouteToLocs routeToLocsItem) {
    if (this.routeToLocs == null) {
      this.routeToLocs = new ArrayList<>();
    }
    this.routeToLocs.add(routeToLocsItem);
    return this;
  }

  /**
   * A list of location which the traffic shall be routed to for the AF request
   * @return routeToLocs
  */
  @ApiModelProperty(value = "A list of location which the traffic shall be routed to for the AF request")

  @Valid
@Size(min=1) 
  public List<TrafficControlDataRouteToLocs> getRouteToLocs() {
    return routeToLocs;
  }

  public void setRouteToLocs(List<TrafficControlDataRouteToLocs> routeToLocs) {
    this.routeToLocs = routeToLocs;
  }

  public TrafficControlData upPathChgEvent(UpPathChgEvent upPathChgEvent) {
    this.upPathChgEvent = JsonNullable.of(upPathChgEvent);
    return this;
  }

  /**
   * Get upPathChgEvent
   * @return upPathChgEvent
  */
  @ApiModelProperty(value = "")

  @Valid

  public JsonNullable<UpPathChgEvent> getUpPathChgEvent() {
    return upPathChgEvent;
  }

  public void setUpPathChgEvent(JsonNullable<UpPathChgEvent> upPathChgEvent) {
    this.upPathChgEvent = upPathChgEvent;
  }

  public TrafficControlData steerFun(SteeringFunctionality steerFun) {
    this.steerFun = steerFun;
    return this;
  }

  /**
   * Get steerFun
   * @return steerFun
  */
  @ApiModelProperty(value = "")

  @Valid

  public SteeringFunctionality getSteerFun() {
    return steerFun;
  }

  public void setSteerFun(SteeringFunctionality steerFun) {
    this.steerFun = steerFun;
  }

  public TrafficControlData steerModeDl(SteeringMode steerModeDl) {
    this.steerModeDl = steerModeDl;
    return this;
  }

  /**
   * Get steerModeDl
   * @return steerModeDl
  */
  @ApiModelProperty(value = "")

  @Valid

  public SteeringMode getSteerModeDl() {
    return steerModeDl;
  }

  public void setSteerModeDl(SteeringMode steerModeDl) {
    this.steerModeDl = steerModeDl;
  }

  public TrafficControlData steerModeUl(SteeringMode steerModeUl) {
    this.steerModeUl = steerModeUl;
    return this;
  }

  /**
   * Get steerModeUl
   * @return steerModeUl
  */
  @ApiModelProperty(value = "")

  @Valid

  public SteeringMode getSteerModeUl() {
    return steerModeUl;
  }

  public void setSteerModeUl(SteeringMode steerModeUl) {
    this.steerModeUl = steerModeUl;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TrafficControlData trafficControlData = (TrafficControlData) o;
    return Objects.equals(this.tcId, trafficControlData.tcId) &&
        Objects.equals(this.flowStatus, trafficControlData.flowStatus) &&
        Objects.equals(this.redirectInfo, trafficControlData.redirectInfo) &&
        Objects.equals(this.muteNotif, trafficControlData.muteNotif) &&
        Objects.equals(this.trafficSteeringPolIdDl, trafficControlData.trafficSteeringPolIdDl) &&
        Objects.equals(this.trafficSteeringPolIdUl, trafficControlData.trafficSteeringPolIdUl) &&
        Objects.equals(this.routeToLocs, trafficControlData.routeToLocs) &&
        Objects.equals(this.upPathChgEvent, trafficControlData.upPathChgEvent) &&
        Objects.equals(this.steerFun, trafficControlData.steerFun) &&
        Objects.equals(this.steerModeDl, trafficControlData.steerModeDl) &&
        Objects.equals(this.steerModeUl, trafficControlData.steerModeUl);
  }

  @Override
  public int hashCode() {
    return Objects.hash(tcId, flowStatus, redirectInfo, muteNotif, trafficSteeringPolIdDl, trafficSteeringPolIdUl, routeToLocs, upPathChgEvent, steerFun, steerModeDl, steerModeUl);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TrafficControlData {\n");
    
    sb.append("    tcId: ").append(toIndentedString(tcId)).append("\n");
    sb.append("    flowStatus: ").append(toIndentedString(flowStatus)).append("\n");
    sb.append("    redirectInfo: ").append(toIndentedString(redirectInfo)).append("\n");
    sb.append("    muteNotif: ").append(toIndentedString(muteNotif)).append("\n");
    sb.append("    trafficSteeringPolIdDl: ").append(toIndentedString(trafficSteeringPolIdDl)).append("\n");
    sb.append("    trafficSteeringPolIdUl: ").append(toIndentedString(trafficSteeringPolIdUl)).append("\n");
    sb.append("    routeToLocs: ").append(toIndentedString(routeToLocs)).append("\n");
    sb.append("    upPathChgEvent: ").append(toIndentedString(upPathChgEvent)).append("\n");
    sb.append("    steerFun: ").append(toIndentedString(steerFun)).append("\n");
    sb.append("    steerModeDl: ").append(toIndentedString(steerModeDl)).append("\n");
    sb.append("    steerModeUl: ").append(toIndentedString(steerModeUl)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

