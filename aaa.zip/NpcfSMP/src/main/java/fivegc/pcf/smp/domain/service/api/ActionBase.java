package fivegc.pcf.smp.domain.service.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class ActionBase {

    private static final Logger log = LoggerFactory.getLogger(ActionBase.class);
    private ArrayList<ExecuteBase> executeArray = null;
    private JsonNode actionJson = null;
    private JsonNode operationJson = null;
    private int actionType;

    /*** Constructer ***/

    public ActionBase(){
        executeArray = new ArrayList<ExecuteBase>();
    }
    public ActionBase(ActionBase copyObj){
        if(copyObj != null){
            ArrayList<ExecuteBase> executeObj = copyObj.getExecuteObj();
            setActionType(copyObj.getActionType());
            setExecuteObj(executeObj);
            setOperationJson(copyObj.getOperationJson());
        } else {
            executeArray = new ArrayList<ExecuteBase>();
        }
    }
    public ArrayList<ExecuteBase> getExecuteObj(){
        return executeArray;
    }
    public void setActionType(int type){
        actionType = type;
    }
    public int getActionType(){
        return actionType;
    }
    public void setExecuteObj(ArrayList<ExecuteBase> objArray){
        executeArray = objArray;
    }
    public void setActionJson(JsonNode inputJson){
        actionJson = inputJson;
    }
    public void setOperation(ExecuteBase operation){
        executeArray.add(operation);
    }

    public void setOperationJson(JsonNode inputJson){
        operationJson = inputJson;
    }

    public JsonNode getOperationJson(){
        return operationJson;
    }

    void executeAction(JsonNode reqJson, ObjectNode ansJson, ObjectNode distJson){
        for(int count = 0; count < executeArray.size(); count++){
            executeArray.get(count).executeAction(reqJson, ansJson, distJson, actionJson, operationJson);
        }
    }
}
