package fivegc.pcf.smp.domain.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * QosNotificationControlInfo
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2019-08-26T13:44:56.218+09:00[Asia/Tokyo]")

public class QosNotificationControlInfo   {
  @JsonProperty("refPccRuleIds")
  @Valid
  private List<String> refPccRuleIds = new ArrayList<>();

  /**
   * Gets or Sets notifType
   */
  public enum NotifTypeEnum {
    GUARANTEED("GUARANTEED"),
    
    NOT_GUARANTEED("NOT_GUARANTEED");

    private String value;

    NotifTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static NotifTypeEnum fromValue(String value) {
      for (NotifTypeEnum b : NotifTypeEnum.values()) {
        if (b.value.equals(value)) {
          return b;
        }
      }
      throw new IllegalArgumentException("Unexpected value '" + value + "'");
    }
  }

  @JsonProperty("notifType")
  private NotifTypeEnum notifType;

  @JsonProperty("contVer")
  private Integer contVer;

  public QosNotificationControlInfo refPccRuleIds(List<String> refPccRuleIds) {
    this.refPccRuleIds = refPccRuleIds;
    return this;
  }

  public QosNotificationControlInfo addRefPccRuleIdsItem(String refPccRuleIdsItem) {
    this.refPccRuleIds.add(refPccRuleIdsItem);
    return this;
  }

  /**
   * An array of PCC rule id references to the PCC rules associated with the QoS notification control info.
   * @return refPccRuleIds
  */
  @ApiModelProperty(required = true, value = "An array of PCC rule id references to the PCC rules associated with the QoS notification control info.")
  @NotNull

@Size(min=1) 
  public List<String> getRefPccRuleIds() {
    return refPccRuleIds;
  }

  public void setRefPccRuleIds(List<String> refPccRuleIds) {
    this.refPccRuleIds = refPccRuleIds;
  }

  public QosNotificationControlInfo notifType(NotifTypeEnum notifType) {
    this.notifType = notifType;
    return this;
  }

  /**
   * Get notifType
   * @return notifType
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public NotifTypeEnum getNotifType() {
    return notifType;
  }

  public void setNotifType(NotifTypeEnum notifType) {
    this.notifType = notifType;
  }

  public QosNotificationControlInfo contVer(Integer contVer) {
    this.contVer = contVer;
    return this;
  }

  /**
   * Represents the content version of some content.
   * @return contVer
  */
  @ApiModelProperty(value = "Represents the content version of some content.")


  public Integer getContVer() {
    return contVer;
  }

  public void setContVer(Integer contVer) {
    this.contVer = contVer;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    QosNotificationControlInfo qosNotificationControlInfo = (QosNotificationControlInfo) o;
    return Objects.equals(this.refPccRuleIds, qosNotificationControlInfo.refPccRuleIds) &&
        Objects.equals(this.notifType, qosNotificationControlInfo.notifType) &&
        Objects.equals(this.contVer, qosNotificationControlInfo.contVer);
  }

  @Override
  public int hashCode() {
    return Objects.hash(refPccRuleIds, notifType, contVer);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class QosNotificationControlInfo {\n");
    
    sb.append("    refPccRuleIds: ").append(toIndentedString(refPccRuleIds)).append("\n");
    sb.append("    notifType: ").append(toIndentedString(notifType)).append("\n");
    sb.append("    contVer: ").append(toIndentedString(contVer)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

