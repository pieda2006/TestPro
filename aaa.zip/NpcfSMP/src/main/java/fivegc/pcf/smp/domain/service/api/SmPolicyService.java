package fivegc.pcf.smp.domain.service.api;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;

import fivegc.pcf.smp.domain.model.SmPolicyDecision;
import fivegc.pcf.smp.domain.model.SessionRule;
import fivegc.pcf.smp.domain.model.SmPolicyContextData;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Scope("prototype")
@Service
public class SmPolicyService {

    private static final Logger log = LoggerFactory.getLogger(SmPolicyService.class);

    public SmPolicyDecision decisionPolicy(SmPolicyContextData smPolicyContextData) {

        SmPolicyDecision smPolicyDecIns = new SmPolicyDecision();
        SessionRule sessionRuleIns = new SessionRule();

        if(smPolicyContextData.getPduSessionId() == 0){
            sessionRuleIns.setSessRuleId("TEST_SES_RULEID_01");
        } else {
            sessionRuleIns.setSessRuleId("TEST_SES_RULEID_02");
        }
        
        smPolicyDecIns.putSessRulesItem("sessRules",sessionRuleIns);
 
       return smPolicyDecIns;
    }


}
