JSONEditor.defaults.templates.swig = function() {
  return window.swig;
};
