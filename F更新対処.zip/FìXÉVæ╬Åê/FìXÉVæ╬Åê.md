# F更新対処内容
## 旧ファイル運用中
![001.drawio](./001.jpg)
図1. F更新前のリソース配備
<div style="page-break-before:always"></div>

## Operatorのバージョンアップ
![002.drawio](./002.jpg)
図2. Operatorバージョンアップ

- 起動済Podに関しては制御可能だと思うのでPod再起動無しで制御可能なはず
- Pairset version設定なしの場合は、<b>Podとのversion不一致を検出したとしてもF更新として扱わない</b>【operator機能変更】
<div style="page-break-before:always"></div>

## Pairsetのバージョンアップ
![003.drawio](./003.jpg)
図3. Pairsetのバージョンアップ

- Pairsetのversion up時にSBY側のDeploymentは引継ぎ対象から外す【シェルの変更】
- Deploymentが一つなくなっているのでPodが消えるため、Operatorが新ファイルを起動する
- Deploymentとの併用になるのでACT/SBY両方が旧バージョンになった際にPod生成/削除を繰り返す可能性あり
<div style="page-break-before:always"></div>

## 系切り替え実施
![004.drawio](./004.jpg)
図4. 系切り替え

- OperatorがPod起動後に新ファイルをACT系として系切り替えを実施
<div style="page-break-before:always"></div>

## ファイル確定コマンド投入

- 図4.と同様
- 旧バージョンのPod情報をPairsetに保持していないため、新ファイルVerに更新されず、Pod再起動が繰り返される
  →<font color=red>ファイル更新状態且つ旧VerのPod情報を保持しない場合にPod削除をスキップすると状態遷移がうまくいかなくなることがないかを要確認。</font>
<div style="page-break-before:always"></div>

## Rolling Update実施

![005.drawio](./005.jpg)
図5. Rolling Update

- 旧ファイルのDeploymentが完全になくなるため、新VerでPodを立ち上げる

# その他
- 作業ディレクトリ
  D:\Desktop\F更新対応\F更新対処