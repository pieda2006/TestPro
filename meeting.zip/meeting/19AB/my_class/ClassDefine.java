package javax.servlet;
public class ClassDefine {
    public String topic_info ="topic_info";
    public String next_id = "next_id";
    public String user_info = "user_info";
    public String topic_kind = "topic_kind";
    public String topic_state = "topic_state";
    public String lock_table = "lock_table";
    public String topic_plan = "topic_plan";
    public String topic_report = "topic_report";
    public String query = "query";
    public String userpass = "userpass";
    public String tag = "tag";
    public String file_dir = "/home/work/webapps/meeting/PDF_File/";
    public String file_dir_part1 = "/home/work/webapps/meeting/";
    public String file_dir_part2 = "/PDF_File/";
    public String bbs_dir = "/home/work/webapps/meeting/BBS/";
    public String bbs_dir_part1 = "/home/work/webapps/meeting/";
    public String bbs_dir_part2 = "/BBS/";
    public String bbs_htbbs_dir = "/home/work/webapps/meeting/BBS/htbbs";
    public String bbs_htbbs_dir_part1 = "/home/work/webapps/meeting/";
    public String bbs_htbbs_dir_part2 = "/BBS/htbbs";
    public String file_htbbs_dir = "/home/work/webapps/meeting/PDF_File/htbbs";
    public String file_htbbs_dir_part1 = "/home/work/webapps/meeting/";
    public String file_htbbs_dir_part2 = "/PDF_File/htbbs";
}
