package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.nec.corestudy.pcf.model.FlowInformation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * PccRule
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class PccRule   {

  
    

    
  
  @JsonProperty("flowInfos")
  
  
  
  
  
  @Valid
  private List<FlowInformation> flowInfos = null;
  
  

  
    

    
  
  @JsonProperty("appId")
  
  
  
  
  
  
  private String appId = null;
  

  
    

    
  
  @JsonProperty("pccRuleId")
  
  
  
  
  
  
  private String pccRuleId = null;
  

  
    

    
  
  @JsonProperty("precedence")
  
  
  
  
  
  
  private Integer precedence = null;
  

  
    

    
  
  @JsonProperty("refQosData")
  
  
  
  
  
  @Valid
  private List<String> refQosData = null;
  
  

  
    

    
  
  @JsonProperty("refTcData")
  
  
  
  
  
  @Valid
  private List<String> refTcData = null;
  
  

  
    

    
  
  @JsonProperty("refChgData")
  
  
  
  
  
  @Valid
  private List<String> refChgData = null;
  
  

  
    

    
  
  @JsonProperty("refUmData")
  
  
  
  
  
  @Valid
  private List<String> refUmData = null;
  
  

  
    

    
  
  @JsonProperty("refCondData")
  
  
  
  
  
  
  private String refCondData = null;
  

  
  
  public PccRule flowInfos(List<FlowInformation> flowInfos) {
    this.flowInfos = flowInfos;
    return this;
  }
  

  public PccRule addFlowInfosItem(FlowInformation flowInfosItem) {
    
    if (this.flowInfos == null) {
      this.flowInfos = new ArrayList<FlowInformation>();
    }
    
    this.flowInfos.add(flowInfosItem);
    return this;
  }
  
  

  /**
  
   * An array of IP flow packet filter information.
  
  
  
  
   * @return flowInfos
  **/
 
  @ApiModelProperty(value = "An array of IP flow packet filter information.")

  @Valid

  public List<FlowInformation> getFlowInfos() {
    return flowInfos;
  }

  public void setFlowInfos(List<FlowInformation> flowInfos) {
    this.flowInfos = flowInfos;
  }

  
  public PccRule appId(String appId) {
    this.appId = appId;
    return this;
  }
  
  

  /**
  
   * A reference to the application detection filter configured at the UPF.
  
  
  
  
   * @return appId
  **/
 
  @ApiModelProperty(value = "A reference to the application detection filter configured at the UPF.")


  public String getAppId() {
    return appId;
  }

  public void setAppId(String appId) {
    this.appId = appId;
  }

  
  public PccRule pccRuleId(String pccRuleId) {
    this.pccRuleId = pccRuleId;
    return this;
  }
  
  

  /**
  
   * Univocally identifies the PCC rule within a PDU session.
  
  
  
  
   * @return pccRuleId
  **/
 
  @ApiModelProperty(required = true, value = "Univocally identifies the PCC rule within a PDU session.")

  @NotNull


  public String getPccRuleId() {
    return pccRuleId;
  }

  public void setPccRuleId(String pccRuleId) {
    this.pccRuleId = pccRuleId;
  }

  
  public PccRule precedence(Integer precedence) {
    this.precedence = precedence;
    return this;
  }
  
  

  /**
  
   * Determines the order in which this PCC rule is applied relative to other PCC rules within the same PDU session.
  
  
  
  
   * @return precedence
  **/
 
  @ApiModelProperty(value = "Determines the order in which this PCC rule is applied relative to other PCC rules within the same PDU session.")


  public Integer getPrecedence() {
    return precedence;
  }

  public void setPrecedence(Integer precedence) {
    this.precedence = precedence;
  }

  
  public PccRule refQosData(List<String> refQosData) {
    this.refQosData = refQosData;
    return this;
  }
  

  public PccRule addRefQosDataItem(String refQosDataItem) {
    
    if (this.refQosData == null) {
      this.refQosData = new ArrayList<String>();
    }
    
    this.refQosData.add(refQosDataItem);
    return this;
  }
  
  

  /**
  
   * A reference to the QoSData policy type decision type. It is the qosId described in subclause 5.6.2.8. (NOTE)
  
  
  
  
   * @return refQosData
  **/
 
  @ApiModelProperty(value = "A reference to the QoSData policy type decision type. It is the qosId described in subclause 5.6.2.8. (NOTE)")


  public List<String> getRefQosData() {
    return refQosData;
  }

  public void setRefQosData(List<String> refQosData) {
    this.refQosData = refQosData;
  }

  
  public PccRule refTcData(List<String> refTcData) {
    this.refTcData = refTcData;
    return this;
  }
  

  public PccRule addRefTcDataItem(String refTcDataItem) {
    
    if (this.refTcData == null) {
      this.refTcData = new ArrayList<String>();
    }
    
    this.refTcData.add(refTcDataItem);
    return this;
  }
  
  

  /**
  
   * A reference to the TrafficControlData policy decision type. It is the tcId described in subclause 5.6.2.10. (NOTE)
  
  
  
  
   * @return refTcData
  **/
 
  @ApiModelProperty(value = "A reference to the TrafficControlData policy decision type. It is the tcId described in subclause 5.6.2.10. (NOTE)")


  public List<String> getRefTcData() {
    return refTcData;
  }

  public void setRefTcData(List<String> refTcData) {
    this.refTcData = refTcData;
  }

  
  public PccRule refChgData(List<String> refChgData) {
    this.refChgData = refChgData;
    return this;
  }
  

  public PccRule addRefChgDataItem(String refChgDataItem) {
    
    if (this.refChgData == null) {
      this.refChgData = new ArrayList<String>();
    }
    
    this.refChgData.add(refChgDataItem);
    return this;
  }
  
  

  /**
  
   * A reference to the ChargingData policy decision type. It is the chgId described in subclause 5.6.2.11. (NOTE)
  
  
  
  
   * @return refChgData
  **/
 
  @ApiModelProperty(value = "A reference to the ChargingData policy decision type. It is the chgId described in subclause 5.6.2.11. (NOTE)")


  public List<String> getRefChgData() {
    return refChgData;
  }

  public void setRefChgData(List<String> refChgData) {
    this.refChgData = refChgData;
  }

  
  public PccRule refUmData(List<String> refUmData) {
    this.refUmData = refUmData;
    return this;
  }
  

  public PccRule addRefUmDataItem(String refUmDataItem) {
    
    if (this.refUmData == null) {
      this.refUmData = new ArrayList<String>();
    }
    
    this.refUmData.add(refUmDataItem);
    return this;
  }
  
  

  /**
  
   * A reference to UsageMonitoringData policy decision type. It is the umId described in subclause 5.6.2.12. (NOTE)
  
  
  
  
   * @return refUmData
  **/
 
  @ApiModelProperty(value = "A reference to UsageMonitoringData policy decision type. It is the umId described in subclause 5.6.2.12. (NOTE)")


  public List<String> getRefUmData() {
    return refUmData;
  }

  public void setRefUmData(List<String> refUmData) {
    this.refUmData = refUmData;
  }

  
  public PccRule refCondData(String refCondData) {
    this.refCondData = refCondData;
    return this;
  }
  
  

  /**
  
   * A reference to the condition data. It is the condId described in subclause 5.6.2.9.
  
  
  
  
   * @return refCondData
  **/
 
  @ApiModelProperty(value = "A reference to the condition data. It is the condId described in subclause 5.6.2.9.")


  public String getRefCondData() {
    return refCondData;
  }

  public void setRefCondData(String refCondData) {
    this.refCondData = refCondData;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PccRule pccRule = (PccRule) o;
    return Objects.equals(this.flowInfos, pccRule.flowInfos) &&
        Objects.equals(this.appId, pccRule.appId) &&
        Objects.equals(this.pccRuleId, pccRule.pccRuleId) &&
        Objects.equals(this.precedence, pccRule.precedence) &&
        Objects.equals(this.refQosData, pccRule.refQosData) &&
        Objects.equals(this.refTcData, pccRule.refTcData) &&
        Objects.equals(this.refChgData, pccRule.refChgData) &&
        Objects.equals(this.refUmData, pccRule.refUmData) &&
        Objects.equals(this.refCondData, pccRule.refCondData);
  }

  @Override
  public int hashCode() {
    return Objects.hash(flowInfos, appId, pccRuleId, precedence, refQosData, refTcData, refChgData, refUmData, refCondData);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PccRule {\n");
    
    sb.append("    flowInfos: ").append(toIndentedString(flowInfos)).append("\n");
    sb.append("    appId: ").append(toIndentedString(appId)).append("\n");
    sb.append("    pccRuleId: ").append(toIndentedString(pccRuleId)).append("\n");
    sb.append("    precedence: ").append(toIndentedString(precedence)).append("\n");
    sb.append("    refQosData: ").append(toIndentedString(refQosData)).append("\n");
    sb.append("    refTcData: ").append(toIndentedString(refTcData)).append("\n");
    sb.append("    refChgData: ").append(toIndentedString(refChgData)).append("\n");
    sb.append("    refUmData: ").append(toIndentedString(refUmData)).append("\n");
    sb.append("    refCondData: ").append(toIndentedString(refCondData)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




