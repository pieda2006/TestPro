package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.threeten.bp.OffsetDateTime;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * UsageMonitoringData
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class UsageMonitoringData   {

  
    

    
  
  @JsonProperty("umId")
  
  
  
  
  
  
  private String umId = null;
  

  
    

    
  
  @JsonProperty("volumeThreshold")
  
  
  
  
  
  
  private String volumeThreshold = null;
  

  
    

    
  
  @JsonProperty("timeThreshold")
  
  
  
  
  
  
  private Integer timeThreshold = null;
  

  
    

    
  
  @JsonProperty("monitoringTime")
  
  
  
  
  
  
  private OffsetDateTime monitoringTime = null;
  

  
    

    
  
  @JsonProperty("nextVolThreshold")
  
  
  
  
  
  
  private String nextVolThreshold = null;
  

  
    

    
  
  @JsonProperty("nextTimeThreshold")
  
  
  
  
  
  
  private Integer nextTimeThreshold = null;
  

  
    

    
  
  @JsonProperty("inactivityTime")
  
  
  
  
  
  
  private Integer inactivityTime = null;
  

  
  
  public UsageMonitoringData umId(String umId) {
    this.umId = umId;
    return this;
  }
  
  

  /**
  
   * Univocally identifies the usage monitoring policy data within a PDU session.
  
  
  
  
   * @return umId
  **/
 
  @ApiModelProperty(required = true, value = "Univocally identifies the usage monitoring policy data within a PDU session.")

  @NotNull


  public String getUmId() {
    return umId;
  }

  public void setUmId(String umId) {
    this.umId = umId;
  }

  
  public UsageMonitoringData volumeThreshold(String volumeThreshold) {
    this.volumeThreshold = volumeThreshold;
    return this;
  }
  
  

  /**
  
  
   * Get volumeThreshold
  
  
  
   * @return volumeThreshold
  **/
 
  @ApiModelProperty(value = "")


  public String getVolumeThreshold() {
    return volumeThreshold;
  }

  public void setVolumeThreshold(String volumeThreshold) {
    this.volumeThreshold = volumeThreshold;
  }

  
  public UsageMonitoringData timeThreshold(Integer timeThreshold) {
    this.timeThreshold = timeThreshold;
    return this;
  }
  
  

  /**
  
  
   * Get timeThreshold
  
  
  
   * @return timeThreshold
  **/
 
  @ApiModelProperty(value = "")


  public Integer getTimeThreshold() {
    return timeThreshold;
  }

  public void setTimeThreshold(Integer timeThreshold) {
    this.timeThreshold = timeThreshold;
  }

  
  public UsageMonitoringData monitoringTime(OffsetDateTime monitoringTime) {
    this.monitoringTime = monitoringTime;
    return this;
  }
  
  

  /**
  
  
   * Get monitoringTime
  
  
  
   * @return monitoringTime
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public OffsetDateTime getMonitoringTime() {
    return monitoringTime;
  }

  public void setMonitoringTime(OffsetDateTime monitoringTime) {
    this.monitoringTime = monitoringTime;
  }

  
  public UsageMonitoringData nextVolThreshold(String nextVolThreshold) {
    this.nextVolThreshold = nextVolThreshold;
    return this;
  }
  
  

  /**
  
  
   * Get nextVolThreshold
  
  
  
   * @return nextVolThreshold
  **/
 
  @ApiModelProperty(value = "")


  public String getNextVolThreshold() {
    return nextVolThreshold;
  }

  public void setNextVolThreshold(String nextVolThreshold) {
    this.nextVolThreshold = nextVolThreshold;
  }

  
  public UsageMonitoringData nextTimeThreshold(Integer nextTimeThreshold) {
    this.nextTimeThreshold = nextTimeThreshold;
    return this;
  }
  
  

  /**
  
  
   * Get nextTimeThreshold
  
  
  
   * @return nextTimeThreshold
  **/
 
  @ApiModelProperty(value = "")


  public Integer getNextTimeThreshold() {
    return nextTimeThreshold;
  }

  public void setNextTimeThreshold(Integer nextTimeThreshold) {
    this.nextTimeThreshold = nextTimeThreshold;
  }

  
  public UsageMonitoringData inactivityTime(Integer inactivityTime) {
    this.inactivityTime = inactivityTime;
    return this;
  }
  
  

  /**
  
  
   * Get inactivityTime
  
  
  
   * @return inactivityTime
  **/
 
  @ApiModelProperty(value = "")


  public Integer getInactivityTime() {
    return inactivityTime;
  }

  public void setInactivityTime(Integer inactivityTime) {
    this.inactivityTime = inactivityTime;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UsageMonitoringData usageMonitoringData = (UsageMonitoringData) o;
    return Objects.equals(this.umId, usageMonitoringData.umId) &&
        Objects.equals(this.volumeThreshold, usageMonitoringData.volumeThreshold) &&
        Objects.equals(this.timeThreshold, usageMonitoringData.timeThreshold) &&
        Objects.equals(this.monitoringTime, usageMonitoringData.monitoringTime) &&
        Objects.equals(this.nextVolThreshold, usageMonitoringData.nextVolThreshold) &&
        Objects.equals(this.nextTimeThreshold, usageMonitoringData.nextTimeThreshold) &&
        Objects.equals(this.inactivityTime, usageMonitoringData.inactivityTime);
  }

  @Override
  public int hashCode() {
    return Objects.hash(umId, volumeThreshold, timeThreshold, monitoringTime, nextVolThreshold, nextTimeThreshold, inactivityTime);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UsageMonitoringData {\n");
    
    sb.append("    umId: ").append(toIndentedString(umId)).append("\n");
    sb.append("    volumeThreshold: ").append(toIndentedString(volumeThreshold)).append("\n");
    sb.append("    timeThreshold: ").append(toIndentedString(timeThreshold)).append("\n");
    sb.append("    monitoringTime: ").append(toIndentedString(monitoringTime)).append("\n");
    sb.append("    nextVolThreshold: ").append(toIndentedString(nextVolThreshold)).append("\n");
    sb.append("    nextTimeThreshold: ").append(toIndentedString(nextTimeThreshold)).append("\n");
    sb.append("    inactivityTime: ").append(toIndentedString(inactivityTime)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




