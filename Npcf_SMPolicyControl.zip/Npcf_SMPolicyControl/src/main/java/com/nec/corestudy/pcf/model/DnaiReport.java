package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * DnaiReport
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class DnaiReport   {

  
    

    
  
  @JsonProperty("notificationUri")
  
  
  
  
  
  
  private String notificationUri = null;
  

  
    

    
  
  @JsonProperty("earlyNotification")
  
  
  
  
  
  
  private Boolean earlyNotification = null;
  

  
    

    
  
  @JsonProperty("lateNotification")
  
  
  
  
  
  
  private Boolean lateNotification = null;
  

  
  
  public DnaiReport notificationUri(String notificationUri) {
    this.notificationUri = notificationUri;
    return this;
  }
  
  

  /**
  
  
   * Get notificationUri
  
  
  
   * @return notificationUri
  **/
 
  @ApiModelProperty(required = true, value = "")

  @NotNull


  public String getNotificationUri() {
    return notificationUri;
  }

  public void setNotificationUri(String notificationUri) {
    this.notificationUri = notificationUri;
  }

  
  public DnaiReport earlyNotification(Boolean earlyNotification) {
    this.earlyNotification = earlyNotification;
    return this;
  }
  
  

  /**
  
   * When it is included and set to true, indicates the early notification is required.
  
  
  
  
   * @return earlyNotification
  **/
 
  @ApiModelProperty(value = "When it is included and set to true, indicates the early notification is required.")


  public Boolean isEarlyNotification() {
    return earlyNotification;
  }

  public void setEarlyNotification(Boolean earlyNotification) {
    this.earlyNotification = earlyNotification;
  }

  
  public DnaiReport lateNotification(Boolean lateNotification) {
    this.lateNotification = lateNotification;
    return this;
  }
  
  

  /**
  
   * When it is included and set to true, indicates the late notification is required.
  
  
  
  
   * @return lateNotification
  **/
 
  @ApiModelProperty(value = "When it is included and set to true, indicates the late notification is required.")


  public Boolean isLateNotification() {
    return lateNotification;
  }

  public void setLateNotification(Boolean lateNotification) {
    this.lateNotification = lateNotification;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DnaiReport dnaiReport = (DnaiReport) o;
    return Objects.equals(this.notificationUri, dnaiReport.notificationUri) &&
        Objects.equals(this.earlyNotification, dnaiReport.earlyNotification) &&
        Objects.equals(this.lateNotification, dnaiReport.lateNotification);
  }

  @Override
  public int hashCode() {
    return Objects.hash(notificationUri, earlyNotification, lateNotification);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DnaiReport {\n");
    
    sb.append("    notificationUri: ").append(toIndentedString(notificationUri)).append("\n");
    sb.append("    earlyNotification: ").append(toIndentedString(earlyNotification)).append("\n");
    sb.append("    lateNotification: ").append(toIndentedString(lateNotification)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




