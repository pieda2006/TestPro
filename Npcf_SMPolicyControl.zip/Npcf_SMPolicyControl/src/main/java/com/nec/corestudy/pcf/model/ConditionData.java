package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.threeten.bp.OffsetDateTime;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * ConditionData
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class ConditionData   {

  
    

    
  
  @JsonProperty("condId")
  
  
  
  
  
  
  private String condId = null;
  

  
    

    
  
  @JsonProperty("activationTime")
  
  
  
  
  
  
  private OffsetDateTime activationTime = null;
  

  
    

    
  
  @JsonProperty("deactivationTime")
  
  
  
  
  
  
  private OffsetDateTime deactivationTime = null;
  

  
  
  public ConditionData condId(String condId) {
    this.condId = condId;
    return this;
  }
  
  

  /**
  
   * Uniquely identifies the condition data within a PDU session.
  
  
  
  
   * @return condId
  **/
 
  @ApiModelProperty(required = true, value = "Uniquely identifies the condition data within a PDU session.")

  @NotNull


  public String getCondId() {
    return condId;
  }

  public void setCondId(String condId) {
    this.condId = condId;
  }

  
  public ConditionData activationTime(OffsetDateTime activationTime) {
    this.activationTime = activationTime;
    return this;
  }
  
  

  /**
  
  
   * Get activationTime
  
  
  
   * @return activationTime
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public OffsetDateTime getActivationTime() {
    return activationTime;
  }

  public void setActivationTime(OffsetDateTime activationTime) {
    this.activationTime = activationTime;
  }

  
  public ConditionData deactivationTime(OffsetDateTime deactivationTime) {
    this.deactivationTime = deactivationTime;
    return this;
  }
  
  

  /**
  
  
   * Get deactivationTime
  
  
  
   * @return deactivationTime
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public OffsetDateTime getDeactivationTime() {
    return deactivationTime;
  }

  public void setDeactivationTime(OffsetDateTime deactivationTime) {
    this.deactivationTime = deactivationTime;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConditionData conditionData = (ConditionData) o;
    return Objects.equals(this.condId, conditionData.condId) &&
        Objects.equals(this.activationTime, conditionData.activationTime) &&
        Objects.equals(this.deactivationTime, conditionData.deactivationTime);
  }

  @Override
  public int hashCode() {
    return Objects.hash(condId, activationTime, deactivationTime);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConditionData {\n");
    
    sb.append("    condId: ").append(toIndentedString(condId)).append("\n");
    sb.append("    activationTime: ").append(toIndentedString(activationTime)).append("\n");
    sb.append("    deactivationTime: ").append(toIndentedString(deactivationTime)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




