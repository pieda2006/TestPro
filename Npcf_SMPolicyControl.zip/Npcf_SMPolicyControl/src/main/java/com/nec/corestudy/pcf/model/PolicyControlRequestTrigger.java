package com.nec.corestudy.pcf.model;

import java.util.Objects;
import io.swagger.annotations.ApiModel;
import com.fasterxml.jackson.annotation.JsonValue;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










import com.fasterxml.jackson.annotation.JsonCreator;


/**
 * Possible values are This string provides forward-compatibility with future extensions to the enumeration but is not used to encode content defined in the present version of this API. - PLMN_CH: PLMN Change - RES_MO_RE: A request for resource modification has been received by the SMF. The SMF always reports to the PCF. - AC_TY_CH: Access Type Change - UE_IP_CH: UE IP address change. The SMF always reports to the PCF. - UE MAC_CH: A new UE MAC address is detected or a used UE MAC address is inactive for a specific period - AN_CH_COR: Access Network Charging Correlation Information - US_RE: The PDU Session or the Monitoring key specific resources consumed by a UE either reached the threshold or needs to be reported for other reasons. - APP_STA: The start of application traffic has been detected. - APP_STO: The stop of application traffic has been detected. - AN_INFO: Access Network Information report - CM_SES_FAIL: Credit management session failure - PS_DA_OFF: The SMF reports when the 3GPP PS Data Off status changes. The SMF always reports to the PCF. - DEF_QOS_CH: Default QoS Change. The SMF always reports to the PCF. - SE_AMBR_CH: Session AMBR Change. The SMF always reports to the PCF. - PCC_RMV: The SMF reports when the PCC rule is removed. The SMF always reports to the PCF. - QOS_STO: The SMF notify the PCF when receiving notification from RAN that QoS targets of the QoS Flow cannot be fulfilled - QOS_STA: The SMF notify the PCF when receiving notification from RAN that QoS targets of the QoS Flow can be fulfilled again - NO_CREDIT: Out of credit - PRA_CH: Change of UE presence in Presence Reporting Area - SAREA_CH: Location Change with respect to the Serving Area - SCNN_CH: Location Change with respect to the Serving CN node - ENF_PCC_RUL: Enforced PCC rule request where the SMF is performing a PCC rules request as instructed by the PCF. - RE_TIMEOUT: Indicates the SMF generated the request because there has been a PCC revalidation timeout 
 */
public enum PolicyControlRequestTrigger {
  
  
  
  PLMN_CH("PLMN_CH"),
  
  RES_MO_RE("RES_MO_RE"),
  
  AC_TY_CH("AC_TY_CH"),
  
  UE_IP_CH("UE_IP_CH"),
  
  UE_MAC_CH("UE MAC_CH"),
  
  AN_CH_COR("AN_CH_COR"),
  
  US_RE("US_RE"),
  
  APP_STA("APP_STA"),
  
  APP_STO("APP_STO"),
  
  AN_INFO("AN_INFO"),
  
  CM_SES_FAIL("CM_SES_FAIL"),
  
  PS_DA_OFF("PS_DA_OFF"),
  
  DEF_QOS_CH("DEF_QOS_CH"),
  
  SE_AMBR_CH("SE_AMBR_CH"),
  
  PCC_RMV("PCC_RMV"),
  
  QOS_STO("QOS_STO"),
  
  QOS_STA("QOS_STA"),
  
  NO_CREDIT("NO_CREDIT"),
  
  PRA_CH("PRA_CH"),
  
  SAREA_CH("SAREA_CH"),
  
  SCNN_CH("SCNN_CH"),
  
  ENF_PCC_RUL("ENF_PCC_RUL"),
  
  RE_TIMEOUT("RE_TIMEOUT");
  

  private String value;

  PolicyControlRequestTrigger(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static PolicyControlRequestTrigger fromValue(String text) {
    for (PolicyControlRequestTrigger b : PolicyControlRequestTrigger.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}





