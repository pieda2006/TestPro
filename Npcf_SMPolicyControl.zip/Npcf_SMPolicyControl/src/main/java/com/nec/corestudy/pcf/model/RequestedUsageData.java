package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * RequestedUsageData
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class RequestedUsageData   {

  
    

    
  
  @JsonProperty("refUmIds")
  
  
  
  
  
  @Valid
  private List<String> refUmIds = null;
  
  

  
    

    
  
  @JsonProperty("allUmIds")
  
  
  
  
  
  
  private Boolean allUmIds = null;
  

  
  
  public RequestedUsageData refUmIds(List<String> refUmIds) {
    this.refUmIds = refUmIds;
    return this;
  }
  

  public RequestedUsageData addRefUmIdsItem(String refUmIdsItem) {
    
    if (this.refUmIds == null) {
      this.refUmIds = new ArrayList<String>();
    }
    
    this.refUmIds.add(refUmIdsItem);
    return this;
  }
  
  

  /**
  
   * An array of usage monitoring data id references to the usage monitoring data instances for which the PCF is requesting a usage report. This attribute shall only be provided when allUmIds is not set to true.
  
  
  
  
   * @return refUmIds
  **/
 
  @ApiModelProperty(value = "An array of usage monitoring data id references to the usage monitoring data instances for which the PCF is requesting a usage report. This attribute shall only be provided when allUmIds is not set to true.")


  public List<String> getRefUmIds() {
    return refUmIds;
  }

  public void setRefUmIds(List<String> refUmIds) {
    this.refUmIds = refUmIds;
  }

  
  public RequestedUsageData allUmIds(Boolean allUmIds) {
    this.allUmIds = allUmIds;
    return this;
  }
  
  

  /**
  
   * Th ooleanean indicates whether requested usage data applies to all usage monitoring data instances. When it's not included, it means requested usage data shall only apply to the usage monitoring data instances referenced by the refUmIds attribute.
  
  
  
  
   * @return allUmIds
  **/
 
  @ApiModelProperty(value = "Th ooleanean indicates whether requested usage data applies to all usage monitoring data instances. When it's not included, it means requested usage data shall only apply to the usage monitoring data instances referenced by the refUmIds attribute.")


  public Boolean isAllUmIds() {
    return allUmIds;
  }

  public void setAllUmIds(Boolean allUmIds) {
    this.allUmIds = allUmIds;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RequestedUsageData requestedUsageData = (RequestedUsageData) o;
    return Objects.equals(this.refUmIds, requestedUsageData.refUmIds) &&
        Objects.equals(this.allUmIds, requestedUsageData.allUmIds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(refUmIds, allUmIds);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RequestedUsageData {\n");
    
    sb.append("    refUmIds: ").append(toIndentedString(refUmIds)).append("\n");
    sb.append("    allUmIds: ").append(toIndentedString(allUmIds)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




