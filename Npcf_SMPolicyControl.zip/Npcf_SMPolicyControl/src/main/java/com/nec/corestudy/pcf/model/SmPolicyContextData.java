package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.nec.corestudy.pcf.model.AccNetChId;
import com.nec.corestudy.pcf.model.AccessType;
import com.nec.corestudy.pcf.model.Ambr;
import com.nec.corestudy.pcf.model.NetworkId;
import com.nec.corestudy.pcf.model.RatType;
import com.nec.corestudy.pcf.model.UserLocation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * SmPolicyContextData
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class SmPolicyContextData   {

  
    

    
  
  @JsonProperty("accNetChId")
  
  
  
  
  
  
  private AccNetChId accNetChId = null;
  

  
    

    
  
  @JsonProperty("gpsi")
  
  
  
  
  
  
  private String gpsi = null;
  

  
    

    
  
  @JsonProperty("supi")
  
  
  
  
  
  
  private String supi = null;
  

  
    

    
  
  @JsonProperty("pduSessionId")
  
  
  
  
  
  
  private Integer pduSessionId = null;
  

  
    

    
  
  @JsonProperty("dnn")
  
  
  
  
  
  
  private String dnn = null;
  

  
    

    
  
  @JsonProperty("smPoliciesUpdateNotificationUrl")
  
  
  
  
  
  
  private String smPoliciesUpdateNotificationUrl = null;
  

  
    

    
  
  @JsonProperty("accessType")
  
  
  
  
  
  
  private AccessType accessType = null;
  

  
    

    
  
  @JsonProperty("ratType")
  
  
  
  
  
  
  private RatType ratType = null;
  

  
    

    
  
  @JsonProperty("servingNetwork")
  
  
  
  
  
  
  private NetworkId servingNetwork = null;
  

  
    

    
  
  @JsonProperty("userLocationInformation")
  
  
  
  
  
  
  private UserLocation userLocationInformation = null;
  

  
    

    
  
  @JsonProperty("ueTimeZone")
  
  
  
  
  
  
  private String ueTimeZone = null;
  

  
    

    
  
  @JsonProperty("pei")
  
  
  
  
  
  
  private String pei = null;
  

  
    

    
  
  @JsonProperty("ipv4Address")
  
  
  
  
  
  
  private String ipv4Address = null;
  

  
    

    
  
  @JsonProperty("ipv6AddressPrefix")
  
  
  
  
  
  
  private String ipv6AddressPrefix = null;
  

  
    

    
  
  @JsonProperty("subSessAmbr")
  
  
  
  
  
  
  private Ambr subSessAmbr = null;
  

  
    

    
  
  @JsonProperty("subscribedDefaultQosInformation")
  
  
  
  
  
  
  private String subscribedDefaultQosInformation = null;
  

  
    

    
  
  @JsonProperty("online")
  
  
  
  
  
  
  private Boolean online = null;
  

  
    

    
  
  @JsonProperty("offline")
  
  
  
  
  
  
  private Boolean offline = null;
  

  
    

    
  
  @JsonProperty("3gppPsDataOffStatus")
  
  
  
  
  
  
  private Boolean _3gppPsDataOffStatus = null;
  

  
    

    
  
  @JsonProperty("supportedFeatures")
  
  
  
  
  
  
  private String supportedFeatures = null;
  

  
  
  public SmPolicyContextData accNetChId(AccNetChId accNetChId) {
    this.accNetChId = accNetChId;
    return this;
  }
  
  

  /**
  
  
   * Get accNetChId
  
  
  
   * @return accNetChId
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public AccNetChId getAccNetChId() {
    return accNetChId;
  }

  public void setAccNetChId(AccNetChId accNetChId) {
    this.accNetChId = accNetChId;
  }

  
  public SmPolicyContextData gpsi(String gpsi) {
    this.gpsi = gpsi;
    return this;
  }
  
  

  /**
  
  
   * Get gpsi
  
  
  
   * @return gpsi
  **/
 
  @ApiModelProperty(value = "")


  public String getGpsi() {
    return gpsi;
  }

  public void setGpsi(String gpsi) {
    this.gpsi = gpsi;
  }

  
  public SmPolicyContextData supi(String supi) {
    this.supi = supi;
    return this;
  }
  
  

  /**
  
  
   * Get supi
  
  
  
   * @return supi
  **/
 
  @ApiModelProperty(required = true, value = "")

  @NotNull


  public String getSupi() {
    return supi;
  }

  public void setSupi(String supi) {
    this.supi = supi;
  }

  
  public SmPolicyContextData pduSessionId(Integer pduSessionId) {
    this.pduSessionId = pduSessionId;
    return this;
  }
  
  

  /**
  
  
   * Get pduSessionId
  
  
  
   * @return pduSessionId
  **/
 
  @ApiModelProperty(required = true, value = "")

  @NotNull


  public Integer getPduSessionId() {
    return pduSessionId;
  }

  public void setPduSessionId(Integer pduSessionId) {
    this.pduSessionId = pduSessionId;
  }

  
  public SmPolicyContextData dnn(String dnn) {
    this.dnn = dnn;
    return this;
  }
  
  

  /**
  
  
   * Get dnn
  
  
  
   * @return dnn
  **/
 
  @ApiModelProperty(required = true, value = "")

  @NotNull


  public String getDnn() {
    return dnn;
  }

  public void setDnn(String dnn) {
    this.dnn = dnn;
  }

  
  public SmPolicyContextData smPoliciesUpdateNotificationUrl(String smPoliciesUpdateNotificationUrl) {
    this.smPoliciesUpdateNotificationUrl = smPoliciesUpdateNotificationUrl;
    return this;
  }
  
  

  /**
  
  
   * Get smPoliciesUpdateNotificationUrl
  
  
  
   * @return smPoliciesUpdateNotificationUrl
  **/
 
  @ApiModelProperty(required = true, value = "")

  @NotNull


  public String getSmPoliciesUpdateNotificationUrl() {
    return smPoliciesUpdateNotificationUrl;
  }

  public void setSmPoliciesUpdateNotificationUrl(String smPoliciesUpdateNotificationUrl) {
    this.smPoliciesUpdateNotificationUrl = smPoliciesUpdateNotificationUrl;
  }

  
  public SmPolicyContextData accessType(AccessType accessType) {
    this.accessType = accessType;
    return this;
  }
  
  

  /**
  
  
   * Get accessType
  
  
  
   * @return accessType
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public AccessType getAccessType() {
    return accessType;
  }

  public void setAccessType(AccessType accessType) {
    this.accessType = accessType;
  }

  
  public SmPolicyContextData ratType(RatType ratType) {
    this.ratType = ratType;
    return this;
  }
  
  

  /**
  
  
   * Get ratType
  
  
  
   * @return ratType
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public RatType getRatType() {
    return ratType;
  }

  public void setRatType(RatType ratType) {
    this.ratType = ratType;
  }

  
  public SmPolicyContextData servingNetwork(NetworkId servingNetwork) {
    this.servingNetwork = servingNetwork;
    return this;
  }
  
  

  /**
  
  
   * Get servingNetwork
  
  
  
   * @return servingNetwork
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public NetworkId getServingNetwork() {
    return servingNetwork;
  }

  public void setServingNetwork(NetworkId servingNetwork) {
    this.servingNetwork = servingNetwork;
  }

  
  public SmPolicyContextData userLocationInformation(UserLocation userLocationInformation) {
    this.userLocationInformation = userLocationInformation;
    return this;
  }
  
  

  /**
  
  
   * Get userLocationInformation
  
  
  
   * @return userLocationInformation
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public UserLocation getUserLocationInformation() {
    return userLocationInformation;
  }

  public void setUserLocationInformation(UserLocation userLocationInformation) {
    this.userLocationInformation = userLocationInformation;
  }

  
  public SmPolicyContextData ueTimeZone(String ueTimeZone) {
    this.ueTimeZone = ueTimeZone;
    return this;
  }
  
  

  /**
  
  
   * Get ueTimeZone
  
  
  
   * @return ueTimeZone
  **/
 
  @ApiModelProperty(value = "")


  public String getUeTimeZone() {
    return ueTimeZone;
  }

  public void setUeTimeZone(String ueTimeZone) {
    this.ueTimeZone = ueTimeZone;
  }

  
  public SmPolicyContextData pei(String pei) {
    this.pei = pei;
    return this;
  }
  
  

  /**
  
  
   * Get pei
  
  
  
   * @return pei
  **/
 
  @ApiModelProperty(value = "")


  public String getPei() {
    return pei;
  }

  public void setPei(String pei) {
    this.pei = pei;
  }

  
  public SmPolicyContextData ipv4Address(String ipv4Address) {
    this.ipv4Address = ipv4Address;
    return this;
  }
  
  

  /**
  
  
   * Get ipv4Address
  
  
  
   * @return ipv4Address
  **/
 
  @ApiModelProperty(value = "")


  public String getIpv4Address() {
    return ipv4Address;
  }

  public void setIpv4Address(String ipv4Address) {
    this.ipv4Address = ipv4Address;
  }

  
  public SmPolicyContextData ipv6AddressPrefix(String ipv6AddressPrefix) {
    this.ipv6AddressPrefix = ipv6AddressPrefix;
    return this;
  }
  
  

  /**
  
  
   * Get ipv6AddressPrefix
  
  
  
   * @return ipv6AddressPrefix
  **/
 
  @ApiModelProperty(value = "")


  public String getIpv6AddressPrefix() {
    return ipv6AddressPrefix;
  }

  public void setIpv6AddressPrefix(String ipv6AddressPrefix) {
    this.ipv6AddressPrefix = ipv6AddressPrefix;
  }

  
  public SmPolicyContextData subSessAmbr(Ambr subSessAmbr) {
    this.subSessAmbr = subSessAmbr;
    return this;
  }
  
  

  /**
  
  
   * Get subSessAmbr
  
  
  
   * @return subSessAmbr
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public Ambr getSubSessAmbr() {
    return subSessAmbr;
  }

  public void setSubSessAmbr(Ambr subSessAmbr) {
    this.subSessAmbr = subSessAmbr;
  }

  
  public SmPolicyContextData subscribedDefaultQosInformation(String subscribedDefaultQosInformation) {
    this.subscribedDefaultQosInformation = subscribedDefaultQosInformation;
    return this;
  }
  
  

  /**
  
  
   * Get subscribedDefaultQosInformation
  
  
  
   * @return subscribedDefaultQosInformation
  **/
 
  @ApiModelProperty(value = "")


  public String getSubscribedDefaultQosInformation() {
    return subscribedDefaultQosInformation;
  }

  public void setSubscribedDefaultQosInformation(String subscribedDefaultQosInformation) {
    this.subscribedDefaultQosInformation = subscribedDefaultQosInformation;
  }

  
  public SmPolicyContextData online(Boolean online) {
    this.online = online;
    return this;
  }
  
  

  /**
  
   * If it is included and set to true, the online charging is applied to the PDU session.
  
  
  
  
   * @return online
  **/
 
  @ApiModelProperty(value = "If it is included and set to true, the online charging is applied to the PDU session.")


  public Boolean isOnline() {
    return online;
  }

  public void setOnline(Boolean online) {
    this.online = online;
  }

  
  public SmPolicyContextData offline(Boolean offline) {
    this.offline = offline;
    return this;
  }
  
  

  /**
  
   * If it is included and set to true, the offline charging is applied to the PDU session.
  
  
  
  
   * @return offline
  **/
 
  @ApiModelProperty(value = "If it is included and set to true, the offline charging is applied to the PDU session.")


  public Boolean isOffline() {
    return offline;
  }

  public void setOffline(Boolean offline) {
    this.offline = offline;
  }

  
  public SmPolicyContextData _3gppPsDataOffStatus(Boolean _3gppPsDataOffStatus) {
    this._3gppPsDataOffStatus = _3gppPsDataOffStatus;
    return this;
  }
  
  

  /**
  
   * If it is included and set to true, the 3GPP PS Data Off is activated by the UE.
  
  
  
  
   * @return _3gppPsDataOffStatus
  **/
 
  @ApiModelProperty(value = "If it is included and set to true, the 3GPP PS Data Off is activated by the UE.")


  public Boolean is3gppPsDataOffStatus() {
    return _3gppPsDataOffStatus;
  }

  public void set3gppPsDataOffStatus(Boolean _3gppPsDataOffStatus) {
    this._3gppPsDataOffStatus = _3gppPsDataOffStatus;
  }

  
  public SmPolicyContextData supportedFeatures(String supportedFeatures) {
    this.supportedFeatures = supportedFeatures;
    return this;
  }
  
  

  /**
  
  
   * Get supportedFeatures
  
  
  
   * @return supportedFeatures
  **/
 
  @ApiModelProperty(value = "")


  public String getSupportedFeatures() {
    return supportedFeatures;
  }

  public void setSupportedFeatures(String supportedFeatures) {
    this.supportedFeatures = supportedFeatures;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyContextData smPolicyContextData = (SmPolicyContextData) o;
    return Objects.equals(this.accNetChId, smPolicyContextData.accNetChId) &&
        Objects.equals(this.gpsi, smPolicyContextData.gpsi) &&
        Objects.equals(this.supi, smPolicyContextData.supi) &&
        Objects.equals(this.pduSessionId, smPolicyContextData.pduSessionId) &&
        Objects.equals(this.dnn, smPolicyContextData.dnn) &&
        Objects.equals(this.smPoliciesUpdateNotificationUrl, smPolicyContextData.smPoliciesUpdateNotificationUrl) &&
        Objects.equals(this.accessType, smPolicyContextData.accessType) &&
        Objects.equals(this.ratType, smPolicyContextData.ratType) &&
        Objects.equals(this.servingNetwork, smPolicyContextData.servingNetwork) &&
        Objects.equals(this.userLocationInformation, smPolicyContextData.userLocationInformation) &&
        Objects.equals(this.ueTimeZone, smPolicyContextData.ueTimeZone) &&
        Objects.equals(this.pei, smPolicyContextData.pei) &&
        Objects.equals(this.ipv4Address, smPolicyContextData.ipv4Address) &&
        Objects.equals(this.ipv6AddressPrefix, smPolicyContextData.ipv6AddressPrefix) &&
        Objects.equals(this.subSessAmbr, smPolicyContextData.subSessAmbr) &&
        Objects.equals(this.subscribedDefaultQosInformation, smPolicyContextData.subscribedDefaultQosInformation) &&
        Objects.equals(this.online, smPolicyContextData.online) &&
        Objects.equals(this.offline, smPolicyContextData.offline) &&
        Objects.equals(this._3gppPsDataOffStatus, smPolicyContextData._3gppPsDataOffStatus) &&
        Objects.equals(this.supportedFeatures, smPolicyContextData.supportedFeatures);
  }

  @Override
  public int hashCode() {
    return Objects.hash(accNetChId, gpsi, supi, pduSessionId, dnn, smPoliciesUpdateNotificationUrl, accessType, ratType, servingNetwork, userLocationInformation, ueTimeZone, pei, ipv4Address, ipv6AddressPrefix, subSessAmbr, subscribedDefaultQosInformation, online, offline, _3gppPsDataOffStatus, supportedFeatures);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyContextData {\n");
    
    sb.append("    accNetChId: ").append(toIndentedString(accNetChId)).append("\n");
    sb.append("    gpsi: ").append(toIndentedString(gpsi)).append("\n");
    sb.append("    supi: ").append(toIndentedString(supi)).append("\n");
    sb.append("    pduSessionId: ").append(toIndentedString(pduSessionId)).append("\n");
    sb.append("    dnn: ").append(toIndentedString(dnn)).append("\n");
    sb.append("    smPoliciesUpdateNotificationUrl: ").append(toIndentedString(smPoliciesUpdateNotificationUrl)).append("\n");
    sb.append("    accessType: ").append(toIndentedString(accessType)).append("\n");
    sb.append("    ratType: ").append(toIndentedString(ratType)).append("\n");
    sb.append("    servingNetwork: ").append(toIndentedString(servingNetwork)).append("\n");
    sb.append("    userLocationInformation: ").append(toIndentedString(userLocationInformation)).append("\n");
    sb.append("    ueTimeZone: ").append(toIndentedString(ueTimeZone)).append("\n");
    sb.append("    pei: ").append(toIndentedString(pei)).append("\n");
    sb.append("    ipv4Address: ").append(toIndentedString(ipv4Address)).append("\n");
    sb.append("    ipv6AddressPrefix: ").append(toIndentedString(ipv6AddressPrefix)).append("\n");
    sb.append("    subSessAmbr: ").append(toIndentedString(subSessAmbr)).append("\n");
    sb.append("    subscribedDefaultQosInformation: ").append(toIndentedString(subscribedDefaultQosInformation)).append("\n");
    sb.append("    online: ").append(toIndentedString(online)).append("\n");
    sb.append("    offline: ").append(toIndentedString(offline)).append("\n");
    sb.append("    _3gppPsDataOffStatus: ").append(toIndentedString(_3gppPsDataOffStatus)).append("\n");
    sb.append("    supportedFeatures: ").append(toIndentedString(supportedFeatures)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




