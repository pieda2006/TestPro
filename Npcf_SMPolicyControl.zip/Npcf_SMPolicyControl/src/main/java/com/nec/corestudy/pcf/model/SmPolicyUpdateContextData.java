package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.nec.corestudy.pcf.model.AccessType;
import com.nec.corestudy.pcf.model.AccuUsageReport;
import com.nec.corestudy.pcf.model.Ambr;
import com.nec.corestudy.pcf.model.AppDetectionInfo;
import com.nec.corestudy.pcf.model.NetworkId;
import com.nec.corestudy.pcf.model.PolicyControlRequestTrigger;
import com.nec.corestudy.pcf.model.RatType;
import com.nec.corestudy.pcf.model.UserLocation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * SmPolicyUpdateContextData
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class SmPolicyUpdateContextData   {

  
    

    
  
  @JsonProperty("repPolicyCtrlReqTriggers")
  
  
  
  
  
  @Valid
  private List<PolicyControlRequestTrigger> repPolicyCtrlReqTriggers = new ArrayList<PolicyControlRequestTrigger>();
  
  

  
    

    
  
  @JsonProperty("accessType")
  
  
  
  
  
  
  private AccessType accessType = null;
  

  
    

    
  
  @JsonProperty("ratType")
  
  
  
  
  
  
  private RatType ratType = null;
  

  
    

    
  
  @JsonProperty("servingNetwork")
  
  
  
  
  
  
  private NetworkId servingNetwork = null;
  

  
    

    
  
  @JsonProperty("userLocationInformation")
  
  
  
  
  
  
  private UserLocation userLocationInformation = null;
  

  
    

    
  
  @JsonProperty("ueTimeZone")
  
  
  
  
  
  
  private String ueTimeZone = null;
  

  
    

    
  
  @JsonProperty("pei")
  
  
  
  
  
  
  private String pei = null;
  

  
    

    
  
  @JsonProperty("ipv4Address")
  
  
  
  
  
  
  private String ipv4Address = null;
  

  
    

    
  
  @JsonProperty("ipv6AddressPrefix")
  
  
  
  
  
  
  private String ipv6AddressPrefix = null;
  

  
    

    
  
  @JsonProperty("relIpv6AddressPrefix")
  
  
  
  
  
  
  private String relIpv6AddressPrefix = null;
  

  
    

    
  
  @JsonProperty("subscribedSessionAmbr")
  
  
  
  
  
  
  private Ambr subscribedSessionAmbr = null;
  

  
    

    
  
  @JsonProperty("subscribedDefaultQosInformation")
  
  
  
  
  
  
  private String subscribedDefaultQosInformation = null;
  

  
    

    
  
  @JsonProperty("accuUsageReport")
  
  
  
  
  
  
  private AccuUsageReport accuUsageReport = null;
  

  
    

    
  
  @JsonProperty("3gppPsDataOffStatus")
  
  
  
  
  
  
  private Boolean _3gppPsDataOffStatus = null;
  

  
    

    
  
  @JsonProperty("appDetectionInfos")
  
  
  
  
  
  @Valid
  private List<AppDetectionInfo> appDetectionInfos = null;
  
  

  
  
  public SmPolicyUpdateContextData repPolicyCtrlReqTriggers(List<PolicyControlRequestTrigger> repPolicyCtrlReqTriggers) {
    this.repPolicyCtrlReqTriggers = repPolicyCtrlReqTriggers;
    return this;
  }
  

  public SmPolicyUpdateContextData addRepPolicyCtrlReqTriggersItem(PolicyControlRequestTrigger repPolicyCtrlReqTriggersItem) {
    
    this.repPolicyCtrlReqTriggers.add(repPolicyCtrlReqTriggersItem);
    return this;
  }
  
  

  /**
  
   * The policy control reqeust trigges which are met.
  
  
  
  
   * @return repPolicyCtrlReqTriggers
  **/
 
  @ApiModelProperty(required = true, value = "The policy control reqeust trigges which are met.")

  @NotNull

  @Valid
@Size(min=1) 
  public List<PolicyControlRequestTrigger> getRepPolicyCtrlReqTriggers() {
    return repPolicyCtrlReqTriggers;
  }

  public void setRepPolicyCtrlReqTriggers(List<PolicyControlRequestTrigger> repPolicyCtrlReqTriggers) {
    this.repPolicyCtrlReqTriggers = repPolicyCtrlReqTriggers;
  }

  
  public SmPolicyUpdateContextData accessType(AccessType accessType) {
    this.accessType = accessType;
    return this;
  }
  
  

  /**
  
  
   * Get accessType
  
  
  
   * @return accessType
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public AccessType getAccessType() {
    return accessType;
  }

  public void setAccessType(AccessType accessType) {
    this.accessType = accessType;
  }

  
  public SmPolicyUpdateContextData ratType(RatType ratType) {
    this.ratType = ratType;
    return this;
  }
  
  

  /**
  
  
   * Get ratType
  
  
  
   * @return ratType
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public RatType getRatType() {
    return ratType;
  }

  public void setRatType(RatType ratType) {
    this.ratType = ratType;
  }

  
  public SmPolicyUpdateContextData servingNetwork(NetworkId servingNetwork) {
    this.servingNetwork = servingNetwork;
    return this;
  }
  
  

  /**
  
  
   * Get servingNetwork
  
  
  
   * @return servingNetwork
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public NetworkId getServingNetwork() {
    return servingNetwork;
  }

  public void setServingNetwork(NetworkId servingNetwork) {
    this.servingNetwork = servingNetwork;
  }

  
  public SmPolicyUpdateContextData userLocationInformation(UserLocation userLocationInformation) {
    this.userLocationInformation = userLocationInformation;
    return this;
  }
  
  

  /**
  
  
   * Get userLocationInformation
  
  
  
   * @return userLocationInformation
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public UserLocation getUserLocationInformation() {
    return userLocationInformation;
  }

  public void setUserLocationInformation(UserLocation userLocationInformation) {
    this.userLocationInformation = userLocationInformation;
  }

  
  public SmPolicyUpdateContextData ueTimeZone(String ueTimeZone) {
    this.ueTimeZone = ueTimeZone;
    return this;
  }
  
  

  /**
  
  
   * Get ueTimeZone
  
  
  
   * @return ueTimeZone
  **/
 
  @ApiModelProperty(value = "")


  public String getUeTimeZone() {
    return ueTimeZone;
  }

  public void setUeTimeZone(String ueTimeZone) {
    this.ueTimeZone = ueTimeZone;
  }

  
  public SmPolicyUpdateContextData pei(String pei) {
    this.pei = pei;
    return this;
  }
  
  

  /**
  
  
   * Get pei
  
  
  
   * @return pei
  **/
 
  @ApiModelProperty(value = "")


  public String getPei() {
    return pei;
  }

  public void setPei(String pei) {
    this.pei = pei;
  }

  
  public SmPolicyUpdateContextData ipv4Address(String ipv4Address) {
    this.ipv4Address = ipv4Address;
    return this;
  }
  
  

  /**
  
  
   * Get ipv4Address
  
  
  
   * @return ipv4Address
  **/
 
  @ApiModelProperty(value = "")


  public String getIpv4Address() {
    return ipv4Address;
  }

  public void setIpv4Address(String ipv4Address) {
    this.ipv4Address = ipv4Address;
  }

  
  public SmPolicyUpdateContextData ipv6AddressPrefix(String ipv6AddressPrefix) {
    this.ipv6AddressPrefix = ipv6AddressPrefix;
    return this;
  }
  
  

  /**
  
  
   * Get ipv6AddressPrefix
  
  
  
   * @return ipv6AddressPrefix
  **/
 
  @ApiModelProperty(value = "")


  public String getIpv6AddressPrefix() {
    return ipv6AddressPrefix;
  }

  public void setIpv6AddressPrefix(String ipv6AddressPrefix) {
    this.ipv6AddressPrefix = ipv6AddressPrefix;
  }

  
  public SmPolicyUpdateContextData relIpv6AddressPrefix(String relIpv6AddressPrefix) {
    this.relIpv6AddressPrefix = relIpv6AddressPrefix;
    return this;
  }
  
  

  /**
  
  
   * Get relIpv6AddressPrefix
  
  
  
   * @return relIpv6AddressPrefix
  **/
 
  @ApiModelProperty(value = "")


  public String getRelIpv6AddressPrefix() {
    return relIpv6AddressPrefix;
  }

  public void setRelIpv6AddressPrefix(String relIpv6AddressPrefix) {
    this.relIpv6AddressPrefix = relIpv6AddressPrefix;
  }

  
  public SmPolicyUpdateContextData subscribedSessionAmbr(Ambr subscribedSessionAmbr) {
    this.subscribedSessionAmbr = subscribedSessionAmbr;
    return this;
  }
  
  

  /**
  
  
   * Get subscribedSessionAmbr
  
  
  
   * @return subscribedSessionAmbr
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public Ambr getSubscribedSessionAmbr() {
    return subscribedSessionAmbr;
  }

  public void setSubscribedSessionAmbr(Ambr subscribedSessionAmbr) {
    this.subscribedSessionAmbr = subscribedSessionAmbr;
  }

  
  public SmPolicyUpdateContextData subscribedDefaultQosInformation(String subscribedDefaultQosInformation) {
    this.subscribedDefaultQosInformation = subscribedDefaultQosInformation;
    return this;
  }
  
  

  /**
  
  
   * Get subscribedDefaultQosInformation
  
  
  
   * @return subscribedDefaultQosInformation
  **/
 
  @ApiModelProperty(value = "")


  public String getSubscribedDefaultQosInformation() {
    return subscribedDefaultQosInformation;
  }

  public void setSubscribedDefaultQosInformation(String subscribedDefaultQosInformation) {
    this.subscribedDefaultQosInformation = subscribedDefaultQosInformation;
  }

  
  public SmPolicyUpdateContextData accuUsageReport(AccuUsageReport accuUsageReport) {
    this.accuUsageReport = accuUsageReport;
    return this;
  }
  
  

  /**
  
  
   * Get accuUsageReport
  
  
  
   * @return accuUsageReport
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public AccuUsageReport getAccuUsageReport() {
    return accuUsageReport;
  }

  public void setAccuUsageReport(AccuUsageReport accuUsageReport) {
    this.accuUsageReport = accuUsageReport;
  }

  
  public SmPolicyUpdateContextData _3gppPsDataOffStatus(Boolean _3gppPsDataOffStatus) {
    this._3gppPsDataOffStatus = _3gppPsDataOffStatus;
    return this;
  }
  
  

  /**
  
   * If it is included and set to true, the 3GPP PS Data Off is activated by the UE.
  
  
  
  
   * @return _3gppPsDataOffStatus
  **/
 
  @ApiModelProperty(value = "If it is included and set to true, the 3GPP PS Data Off is activated by the UE.")


  public Boolean is3gppPsDataOffStatus() {
    return _3gppPsDataOffStatus;
  }

  public void set3gppPsDataOffStatus(Boolean _3gppPsDataOffStatus) {
    this._3gppPsDataOffStatus = _3gppPsDataOffStatus;
  }

  
  public SmPolicyUpdateContextData appDetectionInfos(List<AppDetectionInfo> appDetectionInfos) {
    this.appDetectionInfos = appDetectionInfos;
    return this;
  }
  

  public SmPolicyUpdateContextData addAppDetectionInfosItem(AppDetectionInfo appDetectionInfosItem) {
    
    if (this.appDetectionInfos == null) {
      this.appDetectionInfos = new ArrayList<AppDetectionInfo>();
    }
    
    this.appDetectionInfos.add(appDetectionInfosItem);
    return this;
  }
  
  

  /**
  
   * Report the start/stop of the application traffic and detected SDF descriptions if applicable.
  
  
  
  
   * @return appDetectionInfos
  **/
 
  @ApiModelProperty(value = "Report the start/stop of the application traffic and detected SDF descriptions if applicable.")

  @Valid

  public List<AppDetectionInfo> getAppDetectionInfos() {
    return appDetectionInfos;
  }

  public void setAppDetectionInfos(List<AppDetectionInfo> appDetectionInfos) {
    this.appDetectionInfos = appDetectionInfos;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyUpdateContextData smPolicyUpdateContextData = (SmPolicyUpdateContextData) o;
    return Objects.equals(this.repPolicyCtrlReqTriggers, smPolicyUpdateContextData.repPolicyCtrlReqTriggers) &&
        Objects.equals(this.accessType, smPolicyUpdateContextData.accessType) &&
        Objects.equals(this.ratType, smPolicyUpdateContextData.ratType) &&
        Objects.equals(this.servingNetwork, smPolicyUpdateContextData.servingNetwork) &&
        Objects.equals(this.userLocationInformation, smPolicyUpdateContextData.userLocationInformation) &&
        Objects.equals(this.ueTimeZone, smPolicyUpdateContextData.ueTimeZone) &&
        Objects.equals(this.pei, smPolicyUpdateContextData.pei) &&
        Objects.equals(this.ipv4Address, smPolicyUpdateContextData.ipv4Address) &&
        Objects.equals(this.ipv6AddressPrefix, smPolicyUpdateContextData.ipv6AddressPrefix) &&
        Objects.equals(this.relIpv6AddressPrefix, smPolicyUpdateContextData.relIpv6AddressPrefix) &&
        Objects.equals(this.subscribedSessionAmbr, smPolicyUpdateContextData.subscribedSessionAmbr) &&
        Objects.equals(this.subscribedDefaultQosInformation, smPolicyUpdateContextData.subscribedDefaultQosInformation) &&
        Objects.equals(this.accuUsageReport, smPolicyUpdateContextData.accuUsageReport) &&
        Objects.equals(this._3gppPsDataOffStatus, smPolicyUpdateContextData._3gppPsDataOffStatus) &&
        Objects.equals(this.appDetectionInfos, smPolicyUpdateContextData.appDetectionInfos);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repPolicyCtrlReqTriggers, accessType, ratType, servingNetwork, userLocationInformation, ueTimeZone, pei, ipv4Address, ipv6AddressPrefix, relIpv6AddressPrefix, subscribedSessionAmbr, subscribedDefaultQosInformation, accuUsageReport, _3gppPsDataOffStatus, appDetectionInfos);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyUpdateContextData {\n");
    
    sb.append("    repPolicyCtrlReqTriggers: ").append(toIndentedString(repPolicyCtrlReqTriggers)).append("\n");
    sb.append("    accessType: ").append(toIndentedString(accessType)).append("\n");
    sb.append("    ratType: ").append(toIndentedString(ratType)).append("\n");
    sb.append("    servingNetwork: ").append(toIndentedString(servingNetwork)).append("\n");
    sb.append("    userLocationInformation: ").append(toIndentedString(userLocationInformation)).append("\n");
    sb.append("    ueTimeZone: ").append(toIndentedString(ueTimeZone)).append("\n");
    sb.append("    pei: ").append(toIndentedString(pei)).append("\n");
    sb.append("    ipv4Address: ").append(toIndentedString(ipv4Address)).append("\n");
    sb.append("    ipv6AddressPrefix: ").append(toIndentedString(ipv6AddressPrefix)).append("\n");
    sb.append("    relIpv6AddressPrefix: ").append(toIndentedString(relIpv6AddressPrefix)).append("\n");
    sb.append("    subscribedSessionAmbr: ").append(toIndentedString(subscribedSessionAmbr)).append("\n");
    sb.append("    subscribedDefaultQosInformation: ").append(toIndentedString(subscribedDefaultQosInformation)).append("\n");
    sb.append("    accuUsageReport: ").append(toIndentedString(accuUsageReport)).append("\n");
    sb.append("    _3gppPsDataOffStatus: ").append(toIndentedString(_3gppPsDataOffStatus)).append("\n");
    sb.append("    appDetectionInfos: ").append(toIndentedString(appDetectionInfos)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




