package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.nec.corestudy.pcf.model.DnaiReport;
import com.nec.corestudy.pcf.model.RedirectInformation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * TrafficControlData
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class TrafficControlData   {

  
    

    
  
  @JsonProperty("tcId")
  
  
  
  
  
  
  private String tcId = null;
  

  
    

    
  
  @JsonProperty("flowAction")
  
  
  
  
  
  
  private String flowAction = null;
  

  
    

    
  
  @JsonProperty("redirectInfo")
  
  
  
  
  
  
  private RedirectInformation redirectInfo = null;
  

  
    

    
  
  @JsonProperty("muteNotif")
  
  
  
  
  
  
  private Boolean muteNotif = null;
  

  
    

    
  
  @JsonProperty("trafficSteeringPolIdDl")
  
  
  
  
  
  
  private String trafficSteeringPolIdDl = null;
  

  
    

    
  
  @JsonProperty("trafficSteeringPolIdUl")
  
  
  
  
  
  
  private String trafficSteeringPolIdUl = null;
  

  
    

    
  
  @JsonProperty("dnais")
  
  
  
  
  
  @Valid
  private List<String> dnais = null;
  
  

  
    

    
  
  @JsonProperty("dnaiReport")
  
  
  
  
  
  
  private DnaiReport dnaiReport = null;
  

  
  
  public TrafficControlData tcId(String tcId) {
    this.tcId = tcId;
    return this;
  }
  
  

  /**
  
   * Univocally identifies the traffic control policy data within a PDU session.
  
  
  
  
   * @return tcId
  **/
 
  @ApiModelProperty(required = true, value = "Univocally identifies the traffic control policy data within a PDU session.")

  @NotNull


  public String getTcId() {
    return tcId;
  }

  public void setTcId(String tcId) {
    this.tcId = tcId;
  }

  
  public TrafficControlData flowAction(String flowAction) {
    this.flowAction = flowAction;
    return this;
  }
  
  

  /**
  
  
   * Get flowAction
  
  
  
   * @return flowAction
  **/
 
  @ApiModelProperty(value = "")


  public String getFlowAction() {
    return flowAction;
  }

  public void setFlowAction(String flowAction) {
    this.flowAction = flowAction;
  }

  
  public TrafficControlData redirectInfo(RedirectInformation redirectInfo) {
    this.redirectInfo = redirectInfo;
    return this;
  }
  
  

  /**
  
  
   * Get redirectInfo
  
  
  
   * @return redirectInfo
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public RedirectInformation getRedirectInfo() {
    return redirectInfo;
  }

  public void setRedirectInfo(RedirectInformation redirectInfo) {
    this.redirectInfo = redirectInfo;
  }

  
  public TrafficControlData muteNotif(Boolean muteNotif) {
    this.muteNotif = muteNotif;
    return this;
  }
  
  

  /**
  
   * Indicates whether applicat'on's start or stop notification is to be muted.
  
  
  
  
   * @return muteNotif
  **/
 
  @ApiModelProperty(value = "Indicates whether applicat'on's start or stop notification is to be muted.")


  public Boolean isMuteNotif() {
    return muteNotif;
  }

  public void setMuteNotif(Boolean muteNotif) {
    this.muteNotif = muteNotif;
  }

  
  public TrafficControlData trafficSteeringPolIdDl(String trafficSteeringPolIdDl) {
    this.trafficSteeringPolIdDl = trafficSteeringPolIdDl;
    return this;
  }
  
  

  /**
  
   * Reference to a pre-configured traffic steering policy for downlink traffic at the SMF.
  
  
  
  
   * @return trafficSteeringPolIdDl
  **/
 
  @ApiModelProperty(value = "Reference to a pre-configured traffic steering policy for downlink traffic at the SMF.")


  public String getTrafficSteeringPolIdDl() {
    return trafficSteeringPolIdDl;
  }

  public void setTrafficSteeringPolIdDl(String trafficSteeringPolIdDl) {
    this.trafficSteeringPolIdDl = trafficSteeringPolIdDl;
  }

  
  public TrafficControlData trafficSteeringPolIdUl(String trafficSteeringPolIdUl) {
    this.trafficSteeringPolIdUl = trafficSteeringPolIdUl;
    return this;
  }
  
  

  /**
  
   * Reference to a pre-configured traffic steering policy for uplink traffic at the SMF.
  
  
  
  
   * @return trafficSteeringPolIdUl
  **/
 
  @ApiModelProperty(value = "Reference to a pre-configured traffic steering policy for uplink traffic at the SMF.")


  public String getTrafficSteeringPolIdUl() {
    return trafficSteeringPolIdUl;
  }

  public void setTrafficSteeringPolIdUl(String trafficSteeringPolIdUl) {
    this.trafficSteeringPolIdUl = trafficSteeringPolIdUl;
  }

  
  public TrafficControlData dnais(List<String> dnais) {
    this.dnais = dnais;
    return this;
  }
  

  public TrafficControlData addDnaisItem(String dnaisItem) {
    
    if (this.dnais == null) {
      this.dnais = new ArrayList<String>();
    }
    
    this.dnais.add(dnaisItem);
    return this;
  }
  
  

  /**
  
   * Identifier of the target Data Network Access
  
  
  
  
   * @return dnais
  **/
 
  @ApiModelProperty(value = "Identifier of the target Data Network Access")


  public List<String> getDnais() {
    return dnais;
  }

  public void setDnais(List<String> dnais) {
    this.dnais = dnais;
  }

  
  public TrafficControlData dnaiReport(DnaiReport dnaiReport) {
    this.dnaiReport = dnaiReport;
    return this;
  }
  
  

  /**
  
  
   * Get dnaiReport
  
  
  
   * @return dnaiReport
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public DnaiReport getDnaiReport() {
    return dnaiReport;
  }

  public void setDnaiReport(DnaiReport dnaiReport) {
    this.dnaiReport = dnaiReport;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TrafficControlData trafficControlData = (TrafficControlData) o;
    return Objects.equals(this.tcId, trafficControlData.tcId) &&
        Objects.equals(this.flowAction, trafficControlData.flowAction) &&
        Objects.equals(this.redirectInfo, trafficControlData.redirectInfo) &&
        Objects.equals(this.muteNotif, trafficControlData.muteNotif) &&
        Objects.equals(this.trafficSteeringPolIdDl, trafficControlData.trafficSteeringPolIdDl) &&
        Objects.equals(this.trafficSteeringPolIdUl, trafficControlData.trafficSteeringPolIdUl) &&
        Objects.equals(this.dnais, trafficControlData.dnais) &&
        Objects.equals(this.dnaiReport, trafficControlData.dnaiReport);
  }

  @Override
  public int hashCode() {
    return Objects.hash(tcId, flowAction, redirectInfo, muteNotif, trafficSteeringPolIdDl, trafficSteeringPolIdUl, dnais, dnaiReport);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TrafficControlData {\n");
    
    sb.append("    tcId: ").append(toIndentedString(tcId)).append("\n");
    sb.append("    flowAction: ").append(toIndentedString(flowAction)).append("\n");
    sb.append("    redirectInfo: ").append(toIndentedString(redirectInfo)).append("\n");
    sb.append("    muteNotif: ").append(toIndentedString(muteNotif)).append("\n");
    sb.append("    trafficSteeringPolIdDl: ").append(toIndentedString(trafficSteeringPolIdDl)).append("\n");
    sb.append("    trafficSteeringPolIdUl: ").append(toIndentedString(trafficSteeringPolIdUl)).append("\n");
    sb.append("    dnais: ").append(toIndentedString(dnais)).append("\n");
    sb.append("    dnaiReport: ").append(toIndentedString(dnaiReport)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




