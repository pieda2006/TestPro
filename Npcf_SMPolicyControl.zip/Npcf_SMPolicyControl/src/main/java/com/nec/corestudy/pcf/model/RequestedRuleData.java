package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.nec.corestudy.pcf.model.RequestedRuleDataType;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * RequestedRuleData
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class RequestedRuleData   {

  
    

    
  
  @JsonProperty("refPccRuleIds")
  
  
  
  
  
  @Valid
  private List<String> refPccRuleIds = new ArrayList<String>();
  
  

  
    

    
  
  @JsonProperty("reqData")
  
  
  
  
  
  @Valid
  private List<RequestedRuleDataType> reqData = new ArrayList<RequestedRuleDataType>();
  
  

  
  
  public RequestedRuleData refPccRuleIds(List<String> refPccRuleIds) {
    this.refPccRuleIds = refPccRuleIds;
    return this;
  }
  

  public RequestedRuleData addRefPccRuleIdsItem(String refPccRuleIdsItem) {
    
    this.refPccRuleIds.add(refPccRuleIdsItem);
    return this;
  }
  
  

  /**
  
   * An array of PCC rule id references to the PCC rules associated with the control data.
  
  
  
  
   * @return refPccRuleIds
  **/
 
  @ApiModelProperty(required = true, value = "An array of PCC rule id references to the PCC rules associated with the control data.")

  @NotNull

@Size(min=1) 
  public List<String> getRefPccRuleIds() {
    return refPccRuleIds;
  }

  public void setRefPccRuleIds(List<String> refPccRuleIds) {
    this.refPccRuleIds = refPccRuleIds;
  }

  
  public RequestedRuleData reqData(List<RequestedRuleDataType> reqData) {
    this.reqData = reqData;
    return this;
  }
  

  public RequestedRuleData addReqDataItem(RequestedRuleDataType reqDataItem) {
    
    this.reqData.add(reqDataItem);
    return this;
  }
  
  

  /**
  
   * Array of requested rule data type elements indicating what type of rule data is requested for the corresponding referenced PCC rules.
  
  
  
  
   * @return reqData
  **/
 
  @ApiModelProperty(required = true, value = "Array of requested rule data type elements indicating what type of rule data is requested for the corresponding referenced PCC rules.")

  @NotNull

  @Valid
@Size(min=1) 
  public List<RequestedRuleDataType> getReqData() {
    return reqData;
  }

  public void setReqData(List<RequestedRuleDataType> reqData) {
    this.reqData = reqData;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RequestedRuleData requestedRuleData = (RequestedRuleData) o;
    return Objects.equals(this.refPccRuleIds, requestedRuleData.refPccRuleIds) &&
        Objects.equals(this.reqData, requestedRuleData.reqData);
  }

  @Override
  public int hashCode() {
    return Objects.hash(refPccRuleIds, reqData);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RequestedRuleData {\n");
    
    sb.append("    refPccRuleIds: ").append(toIndentedString(refPccRuleIds)).append("\n");
    sb.append("    reqData: ").append(toIndentedString(reqData)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




