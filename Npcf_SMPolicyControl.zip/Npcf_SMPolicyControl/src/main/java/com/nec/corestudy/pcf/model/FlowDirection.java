package com.nec.corestudy.pcf.model;

import java.util.Objects;
import io.swagger.annotations.ApiModel;
import com.fasterxml.jackson.annotation.JsonValue;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










import com.fasterxml.jackson.annotation.JsonCreator;


/**
 * Possible values are This string provides forward-compatibility with future extensions to the enumeration but is not used to encode content defined in the present version of this API. - DOWNLINK: The corresponding filter applies for traffic to the UE. - UPLINK: The corresponding filter applies for traffic from the UE. - BIDIRECTIONAL: The corresponding filter applies for traffic both to and from the UE. 
 */
public enum FlowDirection {
  
  
  
  DOWNLINK("DOWNLINK"),
  
  UPLINK("UPLINK"),
  
  BIDIRECTIONAL("BIDIRECTIONAL");
  

  private String value;

  FlowDirection(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static FlowDirection fromValue(String text) {
    for (FlowDirection b : FlowDirection.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}





