package com.nec.corestudy.pcf.model;

import java.util.Objects;
import io.swagger.annotations.ApiModel;
import com.fasterxml.jackson.annotation.JsonValue;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










import com.fasterxml.jackson.annotation.JsonCreator;


/**
 * Possible values are This string provides forward-compatibility with future extensions to the enumeration but is not used to encode content defined in the present version of this API. - CH_ID: Indicates that the requested rule data is the charging identifier.  - MS_TIME_ZONE: Indicates that the requested access network info type is the UE's timezone. - USER_LOC_INFO: Indicates that the requested access network info type is the UE's location. 
 */
public enum RequestedRuleDataType {
  
  
  
  CH_ID("CH_ID"),
  
  MS_TIME_ZONE("MS_TIME_ZONE"),
  
  USER_LOC_INFO("USER_LOC_INFO");
  

  private String value;

  RequestedRuleDataType(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static RequestedRuleDataType fromValue(String text) {
    for (RequestedRuleDataType b : RequestedRuleDataType.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}





