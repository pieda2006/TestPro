package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.nec.corestudy.pcf.model.AccuUsageReport;
import com.nec.corestudy.pcf.model.UserLocation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * SmPolicyDeleteData
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class SmPolicyDeleteData   {

  
    

    
  
  @JsonProperty("userLocationInformation")
  
  
  
  
  
  
  private UserLocation userLocationInformation = null;
  

  
    

    
  
  @JsonProperty("ueTimeZone")
  
  
  
  
  
  
  private String ueTimeZone = null;
  

  
    

    
  
  @JsonProperty("accuUsageReports")
  
  
  
  
  
  @Valid
  private List<AccuUsageReport> accuUsageReports = null;
  
  

  
  
  public SmPolicyDeleteData userLocationInformation(UserLocation userLocationInformation) {
    this.userLocationInformation = userLocationInformation;
    return this;
  }
  
  

  /**
  
  
   * Get userLocationInformation
  
  
  
   * @return userLocationInformation
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public UserLocation getUserLocationInformation() {
    return userLocationInformation;
  }

  public void setUserLocationInformation(UserLocation userLocationInformation) {
    this.userLocationInformation = userLocationInformation;
  }

  
  public SmPolicyDeleteData ueTimeZone(String ueTimeZone) {
    this.ueTimeZone = ueTimeZone;
    return this;
  }
  
  

  /**
  
  
   * Get ueTimeZone
  
  
  
   * @return ueTimeZone
  **/
 
  @ApiModelProperty(value = "")


  public String getUeTimeZone() {
    return ueTimeZone;
  }

  public void setUeTimeZone(String ueTimeZone) {
    this.ueTimeZone = ueTimeZone;
  }

  
  public SmPolicyDeleteData accuUsageReports(List<AccuUsageReport> accuUsageReports) {
    this.accuUsageReports = accuUsageReports;
    return this;
  }
  

  public SmPolicyDeleteData addAccuUsageReportsItem(AccuUsageReport accuUsageReportsItem) {
    
    if (this.accuUsageReports == null) {
      this.accuUsageReports = new ArrayList<AccuUsageReport>();
    }
    
    this.accuUsageReports.add(accuUsageReportsItem);
    return this;
  }
  
  

  /**
  
   * Contains the usage report
  
  
  
  
   * @return accuUsageReports
  **/
 
  @ApiModelProperty(value = "Contains the usage report")

  @Valid

  public List<AccuUsageReport> getAccuUsageReports() {
    return accuUsageReports;
  }

  public void setAccuUsageReports(List<AccuUsageReport> accuUsageReports) {
    this.accuUsageReports = accuUsageReports;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyDeleteData smPolicyDeleteData = (SmPolicyDeleteData) o;
    return Objects.equals(this.userLocationInformation, smPolicyDeleteData.userLocationInformation) &&
        Objects.equals(this.ueTimeZone, smPolicyDeleteData.ueTimeZone) &&
        Objects.equals(this.accuUsageReports, smPolicyDeleteData.accuUsageReports);
  }

  @Override
  public int hashCode() {
    return Objects.hash(userLocationInformation, ueTimeZone, accuUsageReports);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyDeleteData {\n");
    
    sb.append("    userLocationInformation: ").append(toIndentedString(userLocationInformation)).append("\n");
    sb.append("    ueTimeZone: ").append(toIndentedString(ueTimeZone)).append("\n");
    sb.append("    accuUsageReports: ").append(toIndentedString(accuUsageReports)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




