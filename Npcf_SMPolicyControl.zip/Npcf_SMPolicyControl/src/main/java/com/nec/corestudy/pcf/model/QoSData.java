package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.nec.corestudy.pcf.model.Arp;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * QoSData
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class QoSData   {

  
    

    
  
  @JsonProperty("qosId")
  
  
  
  
  
  
  private String qosId = null;
  

  
    

    
  
  @JsonProperty("5qi")
  
  
  
  
  
  
  private Integer _5qi = null;
  

  
    

    
  
  @JsonProperty("maxbrUl")
  
  
  
  
  
  
  private String maxbrUl = null;
  

  
    

    
  
  @JsonProperty("maxbrDl")
  
  
  
  
  
  
  private String maxbrDl = null;
  

  
    

    
  
  @JsonProperty("gbrUl")
  
  
  
  
  
  
  private String gbrUl = null;
  

  
    

    
  
  @JsonProperty("gbrDL")
  
  
  
  
  
  
  private String gbrDL = null;
  

  
    

    
  
  @JsonProperty("arp")
  
  
  
  
  
  
  private Arp arp = null;
  

  
    

    
  
  @JsonProperty("qnc")
  
  
  
  
  
  
  private Boolean qnc = null;
  

  
    

    
  
  @JsonProperty("reflectiveQos")
  
  
  
  
  
  
  private Boolean reflectiveQos = null;
  

  
    

    
  
  @JsonProperty("maxPacketLossRate")
  
  
  
  
  
  
  private String maxPacketLossRate = null;
  

  
    

    
  
  @JsonProperty("defQosFlowIndication")
  
  
  
  
  
  
  private Boolean defQosFlowIndication = null;
  

  
  
  public QoSData qosId(String qosId) {
    this.qosId = qosId;
    return this;
  }
  
  

  /**
  
   * Univocally identifies the QoS control policy data within a PDU session.
  
  
  
  
   * @return qosId
  **/
 
  @ApiModelProperty(required = true, value = "Univocally identifies the QoS control policy data within a PDU session.")

  @NotNull


  public String getQosId() {
    return qosId;
  }

  public void setQosId(String qosId) {
    this.qosId = qosId;
  }

  
  public QoSData _5qi(Integer _5qi) {
    this._5qi = _5qi;
    return this;
  }
  
  

  /**
  
   * Identifier for the authorized QoS parameters for the service data flow.
  
  
  
  
   * @return _5qi
  **/
 
  @ApiModelProperty(required = true, value = "Identifier for the authorized QoS parameters for the service data flow.")

  @NotNull


  public Integer get5qi() {
    return _5qi;
  }

  public void set5qi(Integer _5qi) {
    this._5qi = _5qi;
  }

  
  public QoSData maxbrUl(String maxbrUl) {
    this.maxbrUl = maxbrUl;
    return this;
  }
  
  

  /**
  
  
   * Get maxbrUl
  
  
  
   * @return maxbrUl
  **/
 
  @ApiModelProperty(value = "")


  public String getMaxbrUl() {
    return maxbrUl;
  }

  public void setMaxbrUl(String maxbrUl) {
    this.maxbrUl = maxbrUl;
  }

  
  public QoSData maxbrDl(String maxbrDl) {
    this.maxbrDl = maxbrDl;
    return this;
  }
  
  

  /**
  
  
   * Get maxbrDl
  
  
  
   * @return maxbrDl
  **/
 
  @ApiModelProperty(value = "")


  public String getMaxbrDl() {
    return maxbrDl;
  }

  public void setMaxbrDl(String maxbrDl) {
    this.maxbrDl = maxbrDl;
  }

  
  public QoSData gbrUl(String gbrUl) {
    this.gbrUl = gbrUl;
    return this;
  }
  
  

  /**
  
  
   * Get gbrUl
  
  
  
   * @return gbrUl
  **/
 
  @ApiModelProperty(value = "")


  public String getGbrUl() {
    return gbrUl;
  }

  public void setGbrUl(String gbrUl) {
    this.gbrUl = gbrUl;
  }

  
  public QoSData gbrDL(String gbrDL) {
    this.gbrDL = gbrDL;
    return this;
  }
  
  

  /**
  
  
   * Get gbrDL
  
  
  
   * @return gbrDL
  **/
 
  @ApiModelProperty(value = "")


  public String getGbrDL() {
    return gbrDL;
  }

  public void setGbrDL(String gbrDL) {
    this.gbrDL = gbrDL;
  }

  
  public QoSData arp(Arp arp) {
    this.arp = arp;
    return this;
  }
  
  

  /**
  
  
   * Get arp
  
  
  
   * @return arp
  **/
 
  @ApiModelProperty(required = true, value = "")

  @NotNull

  @Valid

  public Arp getArp() {
    return arp;
  }

  public void setArp(Arp arp) {
    this.arp = arp;
  }

  
  public QoSData qnc(Boolean qnc) {
    this.qnc = qnc;
    return this;
  }
  
  

  /**
  
   * Indicates whether notifications are requested from 3GPP RAN when the GFBR can no longer (or again) be fulfilled for a QoS Flow during the lifetime of the QoS Flow.
  
  
  
  
   * @return qnc
  **/
 
  @ApiModelProperty(value = "Indicates whether notifications are requested from 3GPP RAN when the GFBR can no longer (or again) be fulfilled for a QoS Flow during the lifetime of the QoS Flow.")


  public Boolean isQnc() {
    return qnc;
  }

  public void setQnc(Boolean qnc) {
    this.qnc = qnc;
  }

  
  public QoSData reflectiveQos(Boolean reflectiveQos) {
    this.reflectiveQos = reflectiveQos;
    return this;
  }
  
  

  /**
  
   * Indicates whether the QoS information is reflective for the corresponding service data flow.
  
  
  
  
   * @return reflectiveQos
  **/
 
  @ApiModelProperty(value = "Indicates whether the QoS information is reflective for the corresponding service data flow.")


  public Boolean isReflectiveQos() {
    return reflectiveQos;
  }

  public void setReflectiveQos(Boolean reflectiveQos) {
    this.reflectiveQos = reflectiveQos;
  }

  
  public QoSData maxPacketLossRate(String maxPacketLossRate) {
    this.maxPacketLossRate = maxPacketLossRate;
    return this;
  }
  
  

  /**
  
  
   * Get maxPacketLossRate
  
  
  
   * @return maxPacketLossRate
  **/
 
  @ApiModelProperty(value = "")


  public String getMaxPacketLossRate() {
    return maxPacketLossRate;
  }

  public void setMaxPacketLossRate(String maxPacketLossRate) {
    this.maxPacketLossRate = maxPacketLossRate;
  }

  
  public QoSData defQosFlowIndication(Boolean defQosFlowIndication) {
    this.defQosFlowIndication = defQosFlowIndication;
    return this;
  }
  
  

  /**
  
   * Indicates that the dynamic PCC rule shall always have its binding with the QoS Flow associated with the default QoS rule
  
  
  
  
   * @return defQosFlowIndication
  **/
 
  @ApiModelProperty(value = "Indicates that the dynamic PCC rule shall always have its binding with the QoS Flow associated with the default QoS rule")


  public Boolean isDefQosFlowIndication() {
    return defQosFlowIndication;
  }

  public void setDefQosFlowIndication(Boolean defQosFlowIndication) {
    this.defQosFlowIndication = defQosFlowIndication;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    QoSData qoSData = (QoSData) o;
    return Objects.equals(this.qosId, qoSData.qosId) &&
        Objects.equals(this._5qi, qoSData._5qi) &&
        Objects.equals(this.maxbrUl, qoSData.maxbrUl) &&
        Objects.equals(this.maxbrDl, qoSData.maxbrDl) &&
        Objects.equals(this.gbrUl, qoSData.gbrUl) &&
        Objects.equals(this.gbrDL, qoSData.gbrDL) &&
        Objects.equals(this.arp, qoSData.arp) &&
        Objects.equals(this.qnc, qoSData.qnc) &&
        Objects.equals(this.reflectiveQos, qoSData.reflectiveQos) &&
        Objects.equals(this.maxPacketLossRate, qoSData.maxPacketLossRate) &&
        Objects.equals(this.defQosFlowIndication, qoSData.defQosFlowIndication);
  }

  @Override
  public int hashCode() {
    return Objects.hash(qosId, _5qi, maxbrUl, maxbrDl, gbrUl, gbrDL, arp, qnc, reflectiveQos, maxPacketLossRate, defQosFlowIndication);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class QoSData {\n");
    
    sb.append("    qosId: ").append(toIndentedString(qosId)).append("\n");
    sb.append("    _5qi: ").append(toIndentedString(_5qi)).append("\n");
    sb.append("    maxbrUl: ").append(toIndentedString(maxbrUl)).append("\n");
    sb.append("    maxbrDl: ").append(toIndentedString(maxbrDl)).append("\n");
    sb.append("    gbrUl: ").append(toIndentedString(gbrUl)).append("\n");
    sb.append("    gbrDL: ").append(toIndentedString(gbrDL)).append("\n");
    sb.append("    arp: ").append(toIndentedString(arp)).append("\n");
    sb.append("    qnc: ").append(toIndentedString(qnc)).append("\n");
    sb.append("    reflectiveQos: ").append(toIndentedString(reflectiveQos)).append("\n");
    sb.append("    maxPacketLossRate: ").append(toIndentedString(maxPacketLossRate)).append("\n");
    sb.append("    defQosFlowIndication: ").append(toIndentedString(defQosFlowIndication)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




