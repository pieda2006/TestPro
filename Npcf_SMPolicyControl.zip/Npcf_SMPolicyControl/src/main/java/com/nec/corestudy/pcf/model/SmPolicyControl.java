package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.nec.corestudy.pcf.model.SmPolicyContextData;
import com.nec.corestudy.pcf.model.SmPolicyDecision;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * SmPolicyControl
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class SmPolicyControl   {

  
    

    
  
  @JsonProperty("context")
  
  
  
  
  
  
  private SmPolicyContextData context = null;
  

  
    

    
  
  @JsonProperty("policy")
  
  
  
  
  
  
  private SmPolicyDecision policy = null;
  

  
  
  public SmPolicyControl context(SmPolicyContextData context) {
    this.context = context;
    return this;
  }
  
  

  /**
  
  
   * Get context
  
  
  
   * @return context
  **/
 
  @ApiModelProperty(required = true, value = "")

  @NotNull

  @Valid

  public SmPolicyContextData getContext() {
    return context;
  }

  public void setContext(SmPolicyContextData context) {
    this.context = context;
  }

  
  public SmPolicyControl policy(SmPolicyDecision policy) {
    this.policy = policy;
    return this;
  }
  
  

  /**
  
  
   * Get policy
  
  
  
   * @return policy
  **/
 
  @ApiModelProperty(required = true, value = "")

  @NotNull

  @Valid

  public SmPolicyDecision getPolicy() {
    return policy;
  }

  public void setPolicy(SmPolicyDecision policy) {
    this.policy = policy;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SmPolicyControl smPolicyControl = (SmPolicyControl) o;
    return Objects.equals(this.context, smPolicyControl.context) &&
        Objects.equals(this.policy, smPolicyControl.policy);
  }

  @Override
  public int hashCode() {
    return Objects.hash(context, policy);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SmPolicyControl {\n");
    
    sb.append("    context: ").append(toIndentedString(context)).append("\n");
    sb.append("    policy: ").append(toIndentedString(policy)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




