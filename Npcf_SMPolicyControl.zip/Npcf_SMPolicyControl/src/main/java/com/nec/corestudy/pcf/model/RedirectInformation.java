package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * RedirectInformation
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class RedirectInformation   {

  
    

    
  
  @JsonProperty("redirectSupport")
  
  
  
  
  
  
  private Boolean redirectSupport = null;
  

  
    

    
  
  @JsonProperty("redirectAddressType")
  
  
  
  
  
  
  private String redirectAddressType = null;
  

  
    

    
  
  @JsonProperty("redirectServerAddress")
  
  
  
  
  
  
  private String redirectServerAddress = null;
  

  
  
  public RedirectInformation redirectSupport(Boolean redirectSupport) {
    this.redirectSupport = redirectSupport;
    return this;
  }
  
  

  /**
  
   * Indicates the redirect is enable.
  
  
  
  
   * @return redirectSupport
  **/
 
  @ApiModelProperty(required = true, value = "Indicates the redirect is enable.")

  @NotNull


  public Boolean isRedirectSupport() {
    return redirectSupport;
  }

  public void setRedirectSupport(Boolean redirectSupport) {
    this.redirectSupport = redirectSupport;
  }

  
  public RedirectInformation redirectAddressType(String redirectAddressType) {
    this.redirectAddressType = redirectAddressType;
    return this;
  }
  
  

  /**
  
  
   * Get redirectAddressType
  
  
  
   * @return redirectAddressType
  **/
 
  @ApiModelProperty(value = "")


  public String getRedirectAddressType() {
    return redirectAddressType;
  }

  public void setRedirectAddressType(String redirectAddressType) {
    this.redirectAddressType = redirectAddressType;
  }

  
  public RedirectInformation redirectServerAddress(String redirectServerAddress) {
    this.redirectServerAddress = redirectServerAddress;
    return this;
  }
  
  

  /**
  
   * Indicates the address of the redirect server.
  
  
  
  
   * @return redirectServerAddress
  **/
 
  @ApiModelProperty(value = "Indicates the address of the redirect server.")


  public String getRedirectServerAddress() {
    return redirectServerAddress;
  }

  public void setRedirectServerAddress(String redirectServerAddress) {
    this.redirectServerAddress = redirectServerAddress;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RedirectInformation redirectInformation = (RedirectInformation) o;
    return Objects.equals(this.redirectSupport, redirectInformation.redirectSupport) &&
        Objects.equals(this.redirectAddressType, redirectInformation.redirectAddressType) &&
        Objects.equals(this.redirectServerAddress, redirectInformation.redirectServerAddress);
  }

  @Override
  public int hashCode() {
    return Objects.hash(redirectSupport, redirectAddressType, redirectServerAddress);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RedirectInformation {\n");
    
    sb.append("    redirectSupport: ").append(toIndentedString(redirectSupport)).append("\n");
    sb.append("    redirectAddressType: ").append(toIndentedString(redirectAddressType)).append("\n");
    sb.append("    redirectServerAddress: ").append(toIndentedString(redirectServerAddress)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




