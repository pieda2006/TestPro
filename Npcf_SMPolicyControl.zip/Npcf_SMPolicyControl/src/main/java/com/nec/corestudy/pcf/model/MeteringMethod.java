package com.nec.corestudy.pcf.model;

import java.util.Objects;
import io.swagger.annotations.ApiModel;
import com.fasterxml.jackson.annotation.JsonValue;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










import com.fasterxml.jackson.annotation.JsonCreator;


/**
 * Possible values are This string provides forward-compatibility with future extensions to the enumeration but is not used to encode content defined in the present version of this API. - DURATION: Indicates that the duration of the service data flow traffic shall be metered. - VOLUME: Indicates that volume of the service data flow traffic shall be metered. - DURATION_VOLUME: Indicates that the duration and the volume of the service data flow traffic shall be metered. - EVENT: Indicates that events of the service data flow traffic shall be metered. 
 */
public enum MeteringMethod {
  
  
  
  DURATION("DURATION"),
  
  VOLUME("VOLUME"),
  
  DURATION_VOLUME("DURATION_VOLUME"),
  
  EVENT("EVENT");
  

  private String value;

  MeteringMethod(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static MeteringMethod fromValue(String text) {
    for (MeteringMethod b : MeteringMethod.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}





