package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.nec.corestudy.pcf.model.Ambr;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * SessionRule
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class SessionRule   {

  
    

    
  
  @JsonProperty("authSessAmbr")
  
  
  
  
  
  
  private Ambr authSessAmbr = null;
  

  
    

    
  
  @JsonProperty("authDefaultQos")
  
  
  
  
  
  
  private String authDefaultQos = null;
  

  
    

    
  
  @JsonProperty("sessRuleId")
  
  
  
  
  
  
  private String sessRuleId = null;
  

  
    

    
  
  @JsonProperty("refUmData")
  
  
  
  
  
  
  private String refUmData = null;
  

  
    

    
  
  @JsonProperty("refCondData")
  
  
  
  
  
  
  private String refCondData = null;
  

  
  
  public SessionRule authSessAmbr(Ambr authSessAmbr) {
    this.authSessAmbr = authSessAmbr;
    return this;
  }
  
  

  /**
  
  
   * Get authSessAmbr
  
  
  
   * @return authSessAmbr
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public Ambr getAuthSessAmbr() {
    return authSessAmbr;
  }

  public void setAuthSessAmbr(Ambr authSessAmbr) {
    this.authSessAmbr = authSessAmbr;
  }

  
  public SessionRule authDefaultQos(String authDefaultQos) {
    this.authDefaultQos = authDefaultQos;
    return this;
  }
  
  

  /**
  
  
   * Get authDefaultQos
  
  
  
   * @return authDefaultQos
  **/
 
  @ApiModelProperty(value = "")


  public String getAuthDefaultQos() {
    return authDefaultQos;
  }

  public void setAuthDefaultQos(String authDefaultQos) {
    this.authDefaultQos = authDefaultQos;
  }

  
  public SessionRule sessRuleId(String sessRuleId) {
    this.sessRuleId = sessRuleId;
    return this;
  }
  
  

  /**
  
   * Univocally identifies the session rule within a PDU session.
  
  
  
  
   * @return sessRuleId
  **/
 
  @ApiModelProperty(required = true, value = "Univocally identifies the session rule within a PDU session.")

  @NotNull


  public String getSessRuleId() {
    return sessRuleId;
  }

  public void setSessRuleId(String sessRuleId) {
    this.sessRuleId = sessRuleId;
  }

  
  public SessionRule refUmData(String refUmData) {
    this.refUmData = refUmData;
    return this;
  }
  
  

  /**
  
   * A reference to UsageMonitoringData policy decision type. It is the umId described in subclause 5.6.2.12.
  
  
  
  
   * @return refUmData
  **/
 
  @ApiModelProperty(value = "A reference to UsageMonitoringData policy decision type. It is the umId described in subclause 5.6.2.12.")


  public String getRefUmData() {
    return refUmData;
  }

  public void setRefUmData(String refUmData) {
    this.refUmData = refUmData;
  }

  
  public SessionRule refCondData(String refCondData) {
    this.refCondData = refCondData;
    return this;
  }
  
  

  /**
  
   * A reference to the condition data. It is the condId described in subclause 5.6.2.9.
  
  
  
  
   * @return refCondData
  **/
 
  @ApiModelProperty(value = "A reference to the condition data. It is the condId described in subclause 5.6.2.9.")


  public String getRefCondData() {
    return refCondData;
  }

  public void setRefCondData(String refCondData) {
    this.refCondData = refCondData;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SessionRule sessionRule = (SessionRule) o;
    return Objects.equals(this.authSessAmbr, sessionRule.authSessAmbr) &&
        Objects.equals(this.authDefaultQos, sessionRule.authDefaultQos) &&
        Objects.equals(this.sessRuleId, sessionRule.sessRuleId) &&
        Objects.equals(this.refUmData, sessionRule.refUmData) &&
        Objects.equals(this.refCondData, sessionRule.refCondData);
  }

  @Override
  public int hashCode() {
    return Objects.hash(authSessAmbr, authDefaultQos, sessRuleId, refUmData, refCondData);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SessionRule {\n");
    
    sb.append("    authSessAmbr: ").append(toIndentedString(authSessAmbr)).append("\n");
    sb.append("    authDefaultQos: ").append(toIndentedString(authDefaultQos)).append("\n");
    sb.append("    sessRuleId: ").append(toIndentedString(sessRuleId)).append("\n");
    sb.append("    refUmData: ").append(toIndentedString(refUmData)).append("\n");
    sb.append("    refCondData: ").append(toIndentedString(refCondData)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




