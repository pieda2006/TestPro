package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * AccNetChId
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class AccNetChId   {

  
    

    
  
  @JsonProperty("accNetChaIdValue")
  
  
  
  
  
  
  private String accNetChaIdValue = null;
  

  
    

    
  
  @JsonProperty("pccRuleId")
  
  
  
  
  
  @Valid
  private List<String> pccRuleId = null;
  
  

  
    

    
  
  @JsonProperty("sessionChScope")
  
  
  
  
  
  
  private Boolean sessionChScope = null;
  

  
  
  public AccNetChId accNetChaIdValue(String accNetChaIdValue) {
    this.accNetChaIdValue = accNetChaIdValue;
    return this;
  }
  
  

  /**
  
   * Contains a charging identifier
  
  
  
  
   * @return accNetChaIdValue
  **/
 
  @ApiModelProperty(required = true, value = "Contains a charging identifier")

  @NotNull


  public String getAccNetChaIdValue() {
    return accNetChaIdValue;
  }

  public void setAccNetChaIdValue(String accNetChaIdValue) {
    this.accNetChaIdValue = accNetChaIdValue;
  }

  
  public AccNetChId pccRuleId(List<String> pccRuleId) {
    this.pccRuleId = pccRuleId;
    return this;
  }
  

  public AccNetChId addPccRuleIdItem(String pccRuleIdItem) {
    
    if (this.pccRuleId == null) {
      this.pccRuleId = new ArrayList<String>();
    }
    
    this.pccRuleId.add(pccRuleIdItem);
    return this;
  }
  
  

  /**
  
   * Contains the identifier of the PCC rule(s) associated to the provided Access Network Charging Identifier.
  
  
  
  
   * @return pccRuleId
  **/
 
  @ApiModelProperty(value = "Contains the identifier of the PCC rule(s) associated to the provided Access Network Charging Identifier.")


  public List<String> getPccRuleId() {
    return pccRuleId;
  }

  public void setPccRuleId(List<String> pccRuleId) {
    this.pccRuleId = pccRuleId;
  }

  
  public AccNetChId sessionChScope(Boolean sessionChScope) {
    this.sessionChScope = sessionChScope;
    return this;
  }
  
  

  /**
  
   * When it is included and set to true, indicates the Access Network Charging Identifier applies to the whole PDU Session
  
  
  
  
   * @return sessionChScope
  **/
 
  @ApiModelProperty(value = "When it is included and set to true, indicates the Access Network Charging Identifier applies to the whole PDU Session")


  public Boolean isSessionChScope() {
    return sessionChScope;
  }

  public void setSessionChScope(Boolean sessionChScope) {
    this.sessionChScope = sessionChScope;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AccNetChId accNetChId = (AccNetChId) o;
    return Objects.equals(this.accNetChaIdValue, accNetChId.accNetChaIdValue) &&
        Objects.equals(this.pccRuleId, accNetChId.pccRuleId) &&
        Objects.equals(this.sessionChScope, accNetChId.sessionChScope);
  }

  @Override
  public int hashCode() {
    return Objects.hash(accNetChaIdValue, pccRuleId, sessionChScope);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AccNetChId {\n");
    
    sb.append("    accNetChaIdValue: ").append(toIndentedString(accNetChaIdValue)).append("\n");
    sb.append("    pccRuleId: ").append(toIndentedString(pccRuleId)).append("\n");
    sb.append("    sessionChScope: ").append(toIndentedString(sessionChScope)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




