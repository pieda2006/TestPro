package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * QosCharacteristics
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class QosCharacteristics   {

  
    

    
  
  @JsonProperty("5qI")
  
  
  
  
  
  
  private Integer _5qI = null;
  

  
    

    
  
  @JsonProperty("resourceType")
  
  
  
  
  
  
  private Integer resourceType = null;
  

  
    

    
  
  @JsonProperty("priorityLevel")
  
  
  
  
  
  
  private Integer priorityLevel = null;
  

  
    

    
  
  @JsonProperty("packetDelayBudget")
  
  
  
  
  
  
  private Integer packetDelayBudget = null;
  

  
    

    
  
  @JsonProperty("packetErrorRate")
  
  
  
  
  
  
  private Integer packetErrorRate = null;
  

  
    

    
  
  @JsonProperty("averagingWindow")
  
  
  
  
  
  
  private String averagingWindow = null;
  

  
    

    
  
  @JsonProperty("maximumDataBurst Volume")
  
  
  
  
  
  
  private Integer maximumDataBurstVolume = null;
  

  
  
  public QosCharacteristics _5qI(Integer _5qI) {
    this._5qI = _5qI;
    return this;
  }
  
  

  /**
  
   * Identifier for the authorized QoS parameters for the service data flow. Applies to PCC rule and PDU session level.
  
  
  
  
   * @return _5qI
  **/
 
  @ApiModelProperty(required = true, value = "Identifier for the authorized QoS parameters for the service data flow. Applies to PCC rule and PDU session level.")

  @NotNull


  public Integer get5qI() {
    return _5qI;
  }

  public void set5qI(Integer _5qI) {
    this._5qI = _5qI;
  }

  
  public QosCharacteristics resourceType(Integer resourceType) {
    this.resourceType = resourceType;
    return this;
  }
  
  

  /**
  
  
   * Get resourceType
  
  
  
   * @return resourceType
  **/
 
  @ApiModelProperty(required = true, value = "")

  @NotNull


  public Integer getResourceType() {
    return resourceType;
  }

  public void setResourceType(Integer resourceType) {
    this.resourceType = resourceType;
  }

  
  public QosCharacteristics priorityLevel(Integer priorityLevel) {
    this.priorityLevel = priorityLevel;
    return this;
  }
  
  

  /**
  
  
   * Get priorityLevel
  
  
  
   * @return priorityLevel
  **/
 
  @ApiModelProperty(required = true, value = "")

  @NotNull


  public Integer getPriorityLevel() {
    return priorityLevel;
  }

  public void setPriorityLevel(Integer priorityLevel) {
    this.priorityLevel = priorityLevel;
  }

  
  public QosCharacteristics packetDelayBudget(Integer packetDelayBudget) {
    this.packetDelayBudget = packetDelayBudget;
    return this;
  }
  
  

  /**
  
  
   * Get packetDelayBudget
  
  
  
   * @return packetDelayBudget
  **/
 
  @ApiModelProperty(required = true, value = "")

  @NotNull


  public Integer getPacketDelayBudget() {
    return packetDelayBudget;
  }

  public void setPacketDelayBudget(Integer packetDelayBudget) {
    this.packetDelayBudget = packetDelayBudget;
  }

  
  public QosCharacteristics packetErrorRate(Integer packetErrorRate) {
    this.packetErrorRate = packetErrorRate;
    return this;
  }
  
  

  /**
  
  
   * Get packetErrorRate
  
  
  
   * @return packetErrorRate
  **/
 
  @ApiModelProperty(required = true, value = "")

  @NotNull


  public Integer getPacketErrorRate() {
    return packetErrorRate;
  }

  public void setPacketErrorRate(Integer packetErrorRate) {
    this.packetErrorRate = packetErrorRate;
  }

  
  public QosCharacteristics averagingWindow(String averagingWindow) {
    this.averagingWindow = averagingWindow;
    return this;
  }
  
  

  /**
  
  
   * Get averagingWindow
  
  
  
   * @return averagingWindow
  **/
 
  @ApiModelProperty(value = "")


  public String getAveragingWindow() {
    return averagingWindow;
  }

  public void setAveragingWindow(String averagingWindow) {
    this.averagingWindow = averagingWindow;
  }

  
  public QosCharacteristics maximumDataBurstVolume(Integer maximumDataBurstVolume) {
    this.maximumDataBurstVolume = maximumDataBurstVolume;
    return this;
  }
  
  

  /**
  
  
   * Get maximumDataBurstVolume
  
  
  
   * @return maximumDataBurstVolume
  **/
 
  @ApiModelProperty(value = "")


  public Integer getMaximumDataBurstVolume() {
    return maximumDataBurstVolume;
  }

  public void setMaximumDataBurstVolume(Integer maximumDataBurstVolume) {
    this.maximumDataBurstVolume = maximumDataBurstVolume;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    QosCharacteristics qosCharacteristics = (QosCharacteristics) o;
    return Objects.equals(this._5qI, qosCharacteristics._5qI) &&
        Objects.equals(this.resourceType, qosCharacteristics.resourceType) &&
        Objects.equals(this.priorityLevel, qosCharacteristics.priorityLevel) &&
        Objects.equals(this.packetDelayBudget, qosCharacteristics.packetDelayBudget) &&
        Objects.equals(this.packetErrorRate, qosCharacteristics.packetErrorRate) &&
        Objects.equals(this.averagingWindow, qosCharacteristics.averagingWindow) &&
        Objects.equals(this.maximumDataBurstVolume, qosCharacteristics.maximumDataBurstVolume);
  }

  @Override
  public int hashCode() {
    return Objects.hash(_5qI, resourceType, priorityLevel, packetDelayBudget, packetErrorRate, averagingWindow, maximumDataBurstVolume);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class QosCharacteristics {\n");
    
    sb.append("    _5qI: ").append(toIndentedString(_5qI)).append("\n");
    sb.append("    resourceType: ").append(toIndentedString(resourceType)).append("\n");
    sb.append("    priorityLevel: ").append(toIndentedString(priorityLevel)).append("\n");
    sb.append("    packetDelayBudget: ").append(toIndentedString(packetDelayBudget)).append("\n");
    sb.append("    packetErrorRate: ").append(toIndentedString(packetErrorRate)).append("\n");
    sb.append("    averagingWindow: ").append(toIndentedString(averagingWindow)).append("\n");
    sb.append("    maximumDataBurstVolume: ").append(toIndentedString(maximumDataBurstVolume)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




