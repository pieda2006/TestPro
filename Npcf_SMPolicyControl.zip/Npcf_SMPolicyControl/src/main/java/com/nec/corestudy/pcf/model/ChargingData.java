package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.nec.corestudy.pcf.model.MeteringMethod;
import com.nec.corestudy.pcf.model.ReportingLevel;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * ChargingData
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class ChargingData   {

  
    

    
  
  @JsonProperty("chgId")
  
  
  
  
  
  
  private String chgId = null;
  

  
    

    
  
  @JsonProperty("meteringMethod")
  
  
  
  
  
  
  private MeteringMethod meteringMethod = null;
  

  
    

    
  
  @JsonProperty("offline")
  
  
  
  
  
  
  private Boolean offline = null;
  

  
    

    
  
  @JsonProperty("online")
  
  
  
  
  
  
  private Boolean online = null;
  

  
    

    
  
  @JsonProperty("ratingGroup")
  
  
  
  
  
  
  private String ratingGroup = null;
  

  
    

    
  
  @JsonProperty("reportingLevel")
  
  
  
  
  
  
  private ReportingLevel reportingLevel = null;
  

  
    

    
  
  @JsonProperty("serviceId")
  
  
  
  
  
  
  private String serviceId = null;
  

  
    

    
  
  @JsonProperty("sponsorId")
  
  
  
  
  
  
  private String sponsorId = null;
  

  
    

    
  
  @JsonProperty("appSvcProvId")
  
  
  
  
  
  
  private String appSvcProvId = null;
  

  
    

    
  
  @JsonProperty("afChargingIdentifier")
  
  
  
  
  
  
  private String afChargingIdentifier = null;
  

  
    

    
  
  @JsonProperty("charingInformation")
  
  
  
  
  
  
  private String charingInformation = null;
  

  
  
  public ChargingData chgId(String chgId) {
    this.chgId = chgId;
    return this;
  }
  
  

  /**
  
   * Univocally identifies the charging control policy data within a PDU session.
  
  
  
  
   * @return chgId
  **/
 
  @ApiModelProperty(required = true, value = "Univocally identifies the charging control policy data within a PDU session.")

  @NotNull


  public String getChgId() {
    return chgId;
  }

  public void setChgId(String chgId) {
    this.chgId = chgId;
  }

  
  public ChargingData meteringMethod(MeteringMethod meteringMethod) {
    this.meteringMethod = meteringMethod;
    return this;
  }
  
  

  /**
  
  
   * Get meteringMethod
  
  
  
   * @return meteringMethod
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public MeteringMethod getMeteringMethod() {
    return meteringMethod;
  }

  public void setMeteringMethod(MeteringMethod meteringMethod) {
    this.meteringMethod = meteringMethod;
  }

  
  public ChargingData offline(Boolean offline) {
    this.offline = offline;
    return this;
  }
  
  

  /**
  
   * Indicates the online charging is applicable to the PDU session or PCC rule.
  
  
  
  
   * @return offline
  **/
 
  @ApiModelProperty(value = "Indicates the online charging is applicable to the PDU session or PCC rule.")


  public Boolean isOffline() {
    return offline;
  }

  public void setOffline(Boolean offline) {
    this.offline = offline;
  }

  
  public ChargingData online(Boolean online) {
    this.online = online;
    return this;
  }
  
  

  /**
  
   * Indicates the offline charging is applicable to the PDU session or PCC rule.
  
  
  
  
   * @return online
  **/
 
  @ApiModelProperty(value = "Indicates the offline charging is applicable to the PDU session or PCC rule.")


  public Boolean isOnline() {
    return online;
  }

  public void setOnline(Boolean online) {
    this.online = online;
  }

  
  public ChargingData ratingGroup(String ratingGroup) {
    this.ratingGroup = ratingGroup;
    return this;
  }
  
  

  /**
  
   * The charging key for the PCC rule used for rating purposes.
  
  
  
  
   * @return ratingGroup
  **/
 
  @ApiModelProperty(value = "The charging key for the PCC rule used for rating purposes.")


  public String getRatingGroup() {
    return ratingGroup;
  }

  public void setRatingGroup(String ratingGroup) {
    this.ratingGroup = ratingGroup;
  }

  
  public ChargingData reportingLevel(ReportingLevel reportingLevel) {
    this.reportingLevel = reportingLevel;
    return this;
  }
  
  

  /**
  
  
   * Get reportingLevel
  
  
  
   * @return reportingLevel
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public ReportingLevel getReportingLevel() {
    return reportingLevel;
  }

  public void setReportingLevel(ReportingLevel reportingLevel) {
    this.reportingLevel = reportingLevel;
  }

  
  public ChargingData serviceId(String serviceId) {
    this.serviceId = serviceId;
    return this;
  }
  
  

  /**
  
   * Indicates the identifier of the service or service component the service data flow in a PCC rule relates to.
  
  
  
  
   * @return serviceId
  **/
 
  @ApiModelProperty(value = "Indicates the identifier of the service or service component the service data flow in a PCC rule relates to.")


  public String getServiceId() {
    return serviceId;
  }

  public void setServiceId(String serviceId) {
    this.serviceId = serviceId;
  }

  
  public ChargingData sponsorId(String sponsorId) {
    this.sponsorId = sponsorId;
    return this;
  }
  
  

  /**
  
   * Indicates the sponsor identity.
  
  
  
  
   * @return sponsorId
  **/
 
  @ApiModelProperty(value = "Indicates the sponsor identity.")


  public String getSponsorId() {
    return sponsorId;
  }

  public void setSponsorId(String sponsorId) {
    this.sponsorId = sponsorId;
  }

  
  public ChargingData appSvcProvId(String appSvcProvId) {
    this.appSvcProvId = appSvcProvId;
    return this;
  }
  
  

  /**
  
   * Indicates the application service provider identity.
  
  
  
  
   * @return appSvcProvId
  **/
 
  @ApiModelProperty(value = "Indicates the application service provider identity.")


  public String getAppSvcProvId() {
    return appSvcProvId;
  }

  public void setAppSvcProvId(String appSvcProvId) {
    this.appSvcProvId = appSvcProvId;
  }

  
  public ChargingData afChargingIdentifier(String afChargingIdentifier) {
    this.afChargingIdentifier = afChargingIdentifier;
    return this;
  }
  
  

  /**
  
   * An identifier, provided from the AF, correlating the measurement for the Charging key/Service identifier values in this PCC rule with application level reports.
  
  
  
  
   * @return afChargingIdentifier
  **/
 
  @ApiModelProperty(value = "An identifier, provided from the AF, correlating the measurement for the Charging key/Service identifier values in this PCC rule with application level reports.")


  public String getAfChargingIdentifier() {
    return afChargingIdentifier;
  }

  public void setAfChargingIdentifier(String afChargingIdentifier) {
    this.afChargingIdentifier = afChargingIdentifier;
  }

  
  public ChargingData charingInformation(String charingInformation) {
    this.charingInformation = charingInformation;
    return this;
  }
  
  

  /**
  
  
   * Get charingInformation
  
  
  
   * @return charingInformation
  **/
 
  @ApiModelProperty(value = "")


  public String getCharingInformation() {
    return charingInformation;
  }

  public void setCharingInformation(String charingInformation) {
    this.charingInformation = charingInformation;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ChargingData chargingData = (ChargingData) o;
    return Objects.equals(this.chgId, chargingData.chgId) &&
        Objects.equals(this.meteringMethod, chargingData.meteringMethod) &&
        Objects.equals(this.offline, chargingData.offline) &&
        Objects.equals(this.online, chargingData.online) &&
        Objects.equals(this.ratingGroup, chargingData.ratingGroup) &&
        Objects.equals(this.reportingLevel, chargingData.reportingLevel) &&
        Objects.equals(this.serviceId, chargingData.serviceId) &&
        Objects.equals(this.sponsorId, chargingData.sponsorId) &&
        Objects.equals(this.appSvcProvId, chargingData.appSvcProvId) &&
        Objects.equals(this.afChargingIdentifier, chargingData.afChargingIdentifier) &&
        Objects.equals(this.charingInformation, chargingData.charingInformation);
  }

  @Override
  public int hashCode() {
    return Objects.hash(chgId, meteringMethod, offline, online, ratingGroup, reportingLevel, serviceId, sponsorId, appSvcProvId, afChargingIdentifier, charingInformation);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ChargingData {\n");
    
    sb.append("    chgId: ").append(toIndentedString(chgId)).append("\n");
    sb.append("    meteringMethod: ").append(toIndentedString(meteringMethod)).append("\n");
    sb.append("    offline: ").append(toIndentedString(offline)).append("\n");
    sb.append("    online: ").append(toIndentedString(online)).append("\n");
    sb.append("    ratingGroup: ").append(toIndentedString(ratingGroup)).append("\n");
    sb.append("    reportingLevel: ").append(toIndentedString(reportingLevel)).append("\n");
    sb.append("    serviceId: ").append(toIndentedString(serviceId)).append("\n");
    sb.append("    sponsorId: ").append(toIndentedString(sponsorId)).append("\n");
    sb.append("    appSvcProvId: ").append(toIndentedString(appSvcProvId)).append("\n");
    sb.append("    afChargingIdentifier: ").append(toIndentedString(afChargingIdentifier)).append("\n");
    sb.append("    charingInformation: ").append(toIndentedString(charingInformation)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




