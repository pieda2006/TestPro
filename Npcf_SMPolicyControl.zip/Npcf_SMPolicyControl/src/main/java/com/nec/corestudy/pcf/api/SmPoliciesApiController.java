package com.nec.corestudy.pcf.api;


import com.nec.corestudy.pcf.model.ProblemDetails;
import com.nec.corestudy.pcf.model.SmPolicyContextData;
import com.nec.corestudy.pcf.model.SmPolicyControl;
import com.nec.corestudy.pcf.model.SmPolicyDecision;
import com.nec.corestudy.pcf.model.SmPolicyDeleteData;
import com.nec.corestudy.pcf.model.SmPolicyUpdateContextData;



import com.fasterxml.jackson.databind.ObjectMapper;


import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

    
import javax.validation.constraints.*;
import javax.validation.Valid;
    


import javax.servlet.http.HttpServletRequest;
    


    


    
import java.io.IOException;
    
import java.util.List;
    


@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

@Controller

public class SmPoliciesApiController implements SmPoliciesApi {



    
    private static final Logger log = LoggerFactory.getLogger(SmPoliciesApiController.class);

    
    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public SmPoliciesApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }
    




    public ResponseEntity<Void> smPoliciesPost(@ApiParam(value = "" ,required=true )  @Valid @RequestBody SmPolicyContextData body) {
        
        
        String accept = request.getHeader("Accept");
        
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
        
        
        
        
    }


    public ResponseEntity<Void> smPoliciesSmPolicyIdDeletePost(@ApiParam(value = "" ,required=true )  @Valid @RequestBody SmPolicyDeleteData body,@ApiParam(value = "Identifier of a policy association",required=true) @PathVariable("smPolicyId") String smPolicyId) {
        
        
        String accept = request.getHeader("Accept");
        
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
        
        
        
        
    }


    public ResponseEntity<Void> smPoliciesSmPolicyIdGet(@ApiParam(value = "Identifier of a policy association",required=true) @PathVariable("smPolicyId") String smPolicyId) {
        
        
        String accept = request.getHeader("Accept");
        
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
        
        
        
        
    }


    public ResponseEntity<Void> smPoliciesSmPolicyIdUpdatePost(@ApiParam(value = "" ,required=true )  @Valid @RequestBody SmPolicyUpdateContextData body,@ApiParam(value = "Identifier of a policy association",required=true) @PathVariable("smPolicyId") String smPolicyId) {
        
        
        String accept = request.getHeader("Accept");
        
        return new ResponseEntity<Void>(HttpStatus.NOT_IMPLEMENTED);
        
        
        
        
    }



}

