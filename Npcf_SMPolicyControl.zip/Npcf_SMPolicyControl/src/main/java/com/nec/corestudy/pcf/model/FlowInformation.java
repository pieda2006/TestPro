package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.nec.corestudy.pcf.model.FlowDirection;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * FlowInformation
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class FlowInformation   {

  
    

    
  
  @JsonProperty("flowDescription")
  
  
  
  
  
  
  private String flowDescription = null;
  

  
    

    
  
  @JsonProperty("packetFilterUsage")
  
  
  
  
  
  
  private Boolean packetFilterUsage = null;
  

  
    

    
  
  @JsonProperty("tosTrafficClass")
  
  
  
  
  
  
  private String tosTrafficClass = null;
  

  
    

    
  
  @JsonProperty("spi")
  
  
  
  
  
  
  private String spi = null;
  

  
    

    
  
  @JsonProperty("flowLabel")
  
  
  
  
  
  
  private String flowLabel = null;
  

  
    

    
  
  @JsonProperty("flowDirection")
  
  
  
  
  
  
  private FlowDirection flowDirection = null;
  

  
    

    
  
  @JsonProperty("sourceMacAddress")
  
  
  
  
  
  
  private String sourceMacAddress = null;
  

  
    

    
  
  @JsonProperty("destinationMacAddress")
  
  
  
  
  
  
  private String destinationMacAddress = null;
  

  
    

    
  
  @JsonProperty("ethertype")
  
  
  
  
  
  
  private String ethertype = null;
  

  
    

    
  
  @JsonProperty("vid")
  
  
  
  
  
  
  private String vid = null;
  

  
    

    
  
  @JsonProperty("pcpdei")
  
  
  
  
  
  
  private String pcpdei = null;
  

  
  
  public FlowInformation flowDescription(String flowDescription) {
    this.flowDescription = flowDescription;
    return this;
  }
  
  

  /**
  
  
   * Get flowDescription
  
  
  
   * @return flowDescription
  **/
 
  @ApiModelProperty(value = "")


  public String getFlowDescription() {
    return flowDescription;
  }

  public void setFlowDescription(String flowDescription) {
    this.flowDescription = flowDescription;
  }

  
  public FlowInformation packetFilterUsage(Boolean packetFilterUsage) {
    this.packetFilterUsage = packetFilterUsage;
    return this;
  }
  
  

  /**
  
   * The packet shall be sent to the UE.
  
  
  
  
   * @return packetFilterUsage
  **/
 
  @ApiModelProperty(value = "The packet shall be sent to the UE.")


  public Boolean isPacketFilterUsage() {
    return packetFilterUsage;
  }

  public void setPacketFilterUsage(Boolean packetFilterUsage) {
    this.packetFilterUsage = packetFilterUsage;
  }

  
  public FlowInformation tosTrafficClass(String tosTrafficClass) {
    this.tosTrafficClass = tosTrafficClass;
    return this;
  }
  
  

  /**
  
   * Contains the Ipv4 Type-of-Service and mask field or the Ipv6 Traffic-Class field and mask field.
  
  
  
  
   * @return tosTrafficClass
  **/
 
  @ApiModelProperty(value = "Contains the Ipv4 Type-of-Service and mask field or the Ipv6 Traffic-Class field and mask field.")


  public String getTosTrafficClass() {
    return tosTrafficClass;
  }

  public void setTosTrafficClass(String tosTrafficClass) {
    this.tosTrafficClass = tosTrafficClass;
  }

  
  public FlowInformation spi(String spi) {
    this.spi = spi;
    return this;
  }
  
  

  /**
  
   * the security parameter index of the IPSec packet.
  
  
  
  
   * @return spi
  **/
 
  @ApiModelProperty(value = "the security parameter index of the IPSec packet.")


  public String getSpi() {
    return spi;
  }

  public void setSpi(String spi) {
    this.spi = spi;
  }

  
  public FlowInformation flowLabel(String flowLabel) {
    this.flowLabel = flowLabel;
    return this;
  }
  
  

  /**
  
   * the Ipv6 flow label header field.
  
  
  
  
   * @return flowLabel
  **/
 
  @ApiModelProperty(value = "the Ipv6 flow label header field.")


  public String getFlowLabel() {
    return flowLabel;
  }

  public void setFlowLabel(String flowLabel) {
    this.flowLabel = flowLabel;
  }

  
  public FlowInformation flowDirection(FlowDirection flowDirection) {
    this.flowDirection = flowDirection;
    return this;
  }
  
  

  /**
  
  
   * Get flowDirection
  
  
  
   * @return flowDirection
  **/
 
  @ApiModelProperty(value = "")

  @Valid

  public FlowDirection getFlowDirection() {
    return flowDirection;
  }

  public void setFlowDirection(FlowDirection flowDirection) {
    this.flowDirection = flowDirection;
  }

  
  public FlowInformation sourceMacAddress(String sourceMacAddress) {
    this.sourceMacAddress = sourceMacAddress;
    return this;
  }
  
  

  /**
  
   * Contains the source MAC address
  
  
  
  
   * @return sourceMacAddress
  **/
 
  @ApiModelProperty(value = "Contains the source MAC address")


  public String getSourceMacAddress() {
    return sourceMacAddress;
  }

  public void setSourceMacAddress(String sourceMacAddress) {
    this.sourceMacAddress = sourceMacAddress;
  }

  
  public FlowInformation destinationMacAddress(String destinationMacAddress) {
    this.destinationMacAddress = destinationMacAddress;
    return this;
  }
  
  

  /**
  
   * Contains the destination MAC address
  
  
  
  
   * @return destinationMacAddress
  **/
 
  @ApiModelProperty(value = "Contains the destination MAC address")


  public String getDestinationMacAddress() {
    return destinationMacAddress;
  }

  public void setDestinationMacAddress(String destinationMacAddress) {
    this.destinationMacAddress = destinationMacAddress;
  }

  
  public FlowInformation ethertype(String ethertype) {
    this.ethertype = ethertype;
    return this;
  }
  
  

  /**
  
  
   * Get ethertype
  
  
  
   * @return ethertype
  **/
 
  @ApiModelProperty(value = "")


  public String getEthertype() {
    return ethertype;
  }

  public void setEthertype(String ethertype) {
    this.ethertype = ethertype;
  }

  
  public FlowInformation vid(String vid) {
    this.vid = vid;
    return this;
  }
  
  

  /**
  
   * Contains the VID of C-TAG or S-TAG.
  
  
  
  
   * @return vid
  **/
 
  @ApiModelProperty(value = "Contains the VID of C-TAG or S-TAG.")


  public String getVid() {
    return vid;
  }

  public void setVid(String vid) {
    this.vid = vid;
  }

  
  public FlowInformation pcpdei(String pcpdei) {
    this.pcpdei = pcpdei;
    return this;
  }
  
  

  /**
  
   * Contains the PCP/DEI of C-TAG or S-TAG.
  
  
  
  
   * @return pcpdei
  **/
 
  @ApiModelProperty(value = "Contains the PCP/DEI of C-TAG or S-TAG.")


  public String getPcpdei() {
    return pcpdei;
  }

  public void setPcpdei(String pcpdei) {
    this.pcpdei = pcpdei;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FlowInformation flowInformation = (FlowInformation) o;
    return Objects.equals(this.flowDescription, flowInformation.flowDescription) &&
        Objects.equals(this.packetFilterUsage, flowInformation.packetFilterUsage) &&
        Objects.equals(this.tosTrafficClass, flowInformation.tosTrafficClass) &&
        Objects.equals(this.spi, flowInformation.spi) &&
        Objects.equals(this.flowLabel, flowInformation.flowLabel) &&
        Objects.equals(this.flowDirection, flowInformation.flowDirection) &&
        Objects.equals(this.sourceMacAddress, flowInformation.sourceMacAddress) &&
        Objects.equals(this.destinationMacAddress, flowInformation.destinationMacAddress) &&
        Objects.equals(this.ethertype, flowInformation.ethertype) &&
        Objects.equals(this.vid, flowInformation.vid) &&
        Objects.equals(this.pcpdei, flowInformation.pcpdei);
  }

  @Override
  public int hashCode() {
    return Objects.hash(flowDescription, packetFilterUsage, tosTrafficClass, spi, flowLabel, flowDirection, sourceMacAddress, destinationMacAddress, ethertype, vid, pcpdei);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FlowInformation {\n");
    
    sb.append("    flowDescription: ").append(toIndentedString(flowDescription)).append("\n");
    sb.append("    packetFilterUsage: ").append(toIndentedString(packetFilterUsage)).append("\n");
    sb.append("    tosTrafficClass: ").append(toIndentedString(tosTrafficClass)).append("\n");
    sb.append("    spi: ").append(toIndentedString(spi)).append("\n");
    sb.append("    flowLabel: ").append(toIndentedString(flowLabel)).append("\n");
    sb.append("    flowDirection: ").append(toIndentedString(flowDirection)).append("\n");
    sb.append("    sourceMacAddress: ").append(toIndentedString(sourceMacAddress)).append("\n");
    sb.append("    destinationMacAddress: ").append(toIndentedString(destinationMacAddress)).append("\n");
    sb.append("    ethertype: ").append(toIndentedString(ethertype)).append("\n");
    sb.append("    vid: ").append(toIndentedString(vid)).append("\n");
    sb.append("    pcpdei: ").append(toIndentedString(pcpdei)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




