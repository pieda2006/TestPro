package com.nec.corestudy.pcf.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.nec.corestudy.pcf.model.FlowInformation;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;



import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;










/**
 * AppDetectionInfo
 */
@Validated

@javax.annotation.Generated(value = "io.swagger.codegen.languages.java.SpringCodegen", date = "2018-07-31T19:16:13.164+09:00[Asia/Tokyo]")

public class AppDetectionInfo   {

  
    

    
  
  @JsonProperty("appId")
  
  
  
  
  
  
  private String appId = null;
  

  
    

    
  
  @JsonProperty("instanceId")
  
  
  
  
  
  
  private String instanceId = null;
  

  
    

    
  
  @JsonProperty("sdfDescriptions")
  
  
  
  
  
  @Valid
  private List<FlowInformation> sdfDescriptions = null;
  
  

  
  
  public AppDetectionInfo appId(String appId) {
    this.appId = appId;
    return this;
  }
  
  

  /**
  
   * A reference to the application detection filter configured at the UPF
  
  
  
  
   * @return appId
  **/
 
  @ApiModelProperty(required = true, value = "A reference to the application detection filter configured at the UPF")

  @NotNull


  public String getAppId() {
    return appId;
  }

  public void setAppId(String appId) {
    this.appId = appId;
  }

  
  public AppDetectionInfo instanceId(String instanceId) {
    this.instanceId = instanceId;
    return this;
  }
  
  

  /**
  
   * Identifier dynamically assigned by the SMF in order to allow correlation of application Start and Stop events to the specific service data flow description, if service data flow descriptions are deducible.
  
  
  
  
   * @return instanceId
  **/
 
  @ApiModelProperty(value = "Identifier dynamically assigned by the SMF in order to allow correlation of application Start and Stop events to the specific service data flow description, if service data flow descriptions are deducible.")


  public String getInstanceId() {
    return instanceId;
  }

  public void setInstanceId(String instanceId) {
    this.instanceId = instanceId;
  }

  
  public AppDetectionInfo sdfDescriptions(List<FlowInformation> sdfDescriptions) {
    this.sdfDescriptions = sdfDescriptions;
    return this;
  }
  

  public AppDetectionInfo addSdfDescriptionsItem(FlowInformation sdfDescriptionsItem) {
    
    if (this.sdfDescriptions == null) {
      this.sdfDescriptions = new ArrayList<FlowInformation>();
    }
    
    this.sdfDescriptions.add(sdfDescriptionsItem);
    return this;
  }
  
  

  /**
  
   * Contains the detected service data flow descriptions if they are deducible.
  
  
  
  
   * @return sdfDescriptions
  **/
 
  @ApiModelProperty(value = "Contains the detected service data flow descriptions if they are deducible.")

  @Valid

  public List<FlowInformation> getSdfDescriptions() {
    return sdfDescriptions;
  }

  public void setSdfDescriptions(List<FlowInformation> sdfDescriptions) {
    this.sdfDescriptions = sdfDescriptions;
  }

  

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AppDetectionInfo appDetectionInfo = (AppDetectionInfo) o;
    return Objects.equals(this.appId, appDetectionInfo.appId) &&
        Objects.equals(this.instanceId, appDetectionInfo.instanceId) &&
        Objects.equals(this.sdfDescriptions, appDetectionInfo.sdfDescriptions);
  }

  @Override
  public int hashCode() {
    return Objects.hash(appId, instanceId, sdfDescriptions);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AppDetectionInfo {\n");
    
    sb.append("    appId: ").append(toIndentedString(appId)).append("\n");
    sb.append("    instanceId: ").append(toIndentedString(instanceId)).append("\n");
    sb.append("    sdfDescriptions: ").append(toIndentedString(sdfDescriptions)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}




