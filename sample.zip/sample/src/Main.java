import java.util.HashMap;
import java.util.Map;
import org.apache.commons.beanutils.BeanUtils;
import org.modelmapper.ModelMapper;
import java.util.Set;

public class Main {
 
    public static void main(String[] args) {
        Main mainobj = new Main();
        mainobj.mainFunc();
    }
    public void mainFunc(){
       try {
          Object lTest = Class.forName("Test").newInstance();
          Class.forName("Test").getMethod("setNum",Class.forName("java.lang.Integer")).invoke(lTest, 3);
          System.out.println(Class.forName("Test").getMethod("getNum").invoke(lTest));
       } catch (Exception e) {
           System.out.println("Exception");
       }
    }

}

