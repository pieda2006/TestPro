public class Test {
    private Integer num;
    private String moji;

    public Integer getNum(){
        return num;
    }

    public String getMoji(){
        return moji;
    }

    public void setNum(Integer num){
        this.num = num;
    }

    public void setMoji(String moji){
        this.moji = moji;
    }
}
